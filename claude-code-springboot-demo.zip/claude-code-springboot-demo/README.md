# Claude Code + Spring Boot Demo (Repo-Ready)

This project is a **repo-ready starter** showing how to use **Claude Code** with a **Spring Boot 3 / Java 21** service using:

- `CLAUDE.md` for always-loaded project conventions
- `.claude/rules/` for path-scoped instructions
- `.claude/skills/` for reusable workflows
- `.claude/settings.json` for project-shared hooks and permissions
- GitHub Actions + `claude -p` for automated review
- Example hook scripts for formatting and audit logging

## Why this structure

- Keep `CLAUDE.md` concise because it loads into every session.
- Move file/folder-specific guidance into `.claude/rules/`.
- Move procedures into `.claude/skills/` so they load only when used.
- Use hooks for deterministic automation (for example: format after edits, audit tool use).

## Project layout

```text
claude-code-springboot-demo/
├── CLAUDE.md
├── .mcp.json
├── pom.xml
├── docker-compose.yml
├── .claude/
│   ├── settings.json
│   ├── rules/
│   └── skills/
├── scripts/
│   ├── hooks/
│   └── ci/
├── src/
│   ├── main/
│   └── test/
└── .github/workflows/
```

## Run locally

```bash
mvn clean test
mvn spring-boot:run
```

## Invoke Claude review from CLI

```bash
export ANTHROPIC_API_KEY=your_key_here
bash scripts/ci/review-pr.sh
```

## Notes on hooks

The sample `PostToolUse` hook is ready for formatting/auditing after edits.
The sample `PreToolUse` command hook in this repo is a lightweight validator/logger.
For **hard blocking** of sensitive actions, use the **Agent SDK hook callback** pattern shown in `examples/hooks_sdk_example.py` and align the exact return schema with the latest official hook reference.

## Example API calls

Create an order:

```bash
curl -X POST http://localhost:8080/api/orders   -H 'Content-Type: application/json'   -d '{"customerId":"cust-101","itemSku":"sku-123","quantity":2}'
```

Get an order:

```bash
curl http://localhost:8080/api/orders/1
```
