# Illustrative Agent SDK hook callback example for hard blocking.
# Align imports and callback signature with the latest Claude Agent SDK version/docs.

async def guard_sensitive_files(input_data, tool_use_id, context):
    file_path = ""
    if isinstance(input_data, dict):
        file_path = input_data.get("file_path") or input_data.get("path") or ""

    blocked_targets = [".env", "application-prod.yml", "secrets.properties"]

    if any(file_path.endswith(name) for name in blocked_targets):
        return {
            "permissionDecision": "deny",
            "message": f"Editing protected file is blocked by policy: {file_path}"
        }

    return {"permissionDecision": "allow"}
