---
pattern: "src/main/java/**/security/**|src/main/resources/application*.yml"
---

# Security Rules

- Do not hardcode secrets.
- Prefer environment variables or a secrets manager.
- Validate authorization at the boundary.
- Never commit real API keys or database passwords.
