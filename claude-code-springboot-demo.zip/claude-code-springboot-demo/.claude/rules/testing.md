---
pattern: "src/test/**|**/*Test.java"
---

# Testing Rules

- Use JUnit 5 + Mockito.
- Prefer focused unit tests for service logic.
- Use MockMvc for controller tests.
- Cover validation failures and edge cases.
