---
pattern: "src/main/java/**/repository/**|src/main/resources/db/migration/**"
---

# Database Access Rules

- Keep repository methods simple and intention-revealing.
- Prefer pagination on list queries.
- Avoid N+1 query patterns.
- Keep Flyway migrations forward-only and additive.
