---
pattern: "src/main/java/**/controller/**"
---

# API Controller Rules

- Use `@Valid` on request DTOs.
- Return DTOs, never entities.
- Use RESTful status codes.
- Keep controllers orchestration-only; move business logic to services.
- Add/update MockMvc tests when endpoints change.
