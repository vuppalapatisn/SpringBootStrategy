---
pattern: "src/main/java/**/service/**"
---

# Service Rules

- Keep service methods transactional only when needed.
- Enforce idempotency if retrying external actions is possible.
- Throw domain-specific exceptions instead of generic `RuntimeException`.
- Add unit tests for branching business logic.
