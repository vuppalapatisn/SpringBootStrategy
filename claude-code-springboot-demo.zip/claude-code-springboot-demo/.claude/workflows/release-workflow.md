# Release Workflow

1. Run /pr-review
2. Run security-review skill
3. Verify build and tests
4. Summarize release blockers
