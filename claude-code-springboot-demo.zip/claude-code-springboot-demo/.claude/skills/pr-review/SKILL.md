---
name: pr-review
description: Review the current diff for correctness, validation, missing tests, and security risks.
---

# PR Review

1. Read the current diff.
2. Identify correctness issues.
3. Identify missing validation or tests.
4. Flag risky configuration or secret handling.
5. Return a concise review grouped by severity.
