---
name: security-review
description: Review a Spring Boot change for secrets exposure, input validation gaps, auth mistakes, and risky config changes.
---

# Security Review

Check the diff or target files for:

1. Hardcoded secrets or credentials
2. Missing validation on inbound input
3. Overly permissive auth or missing boundary checks
4. Risky logging of sensitive data
5. Configuration mistakes in `application.yml`

Return:
- findings
- severity
- recommended fixes
- files impacted
