# Security Review Checklist

- [ ] No secrets in code or config
- [ ] Validation present on API inputs
- [ ] Sensitive logs avoided
- [ ] Auth boundaries reviewed
