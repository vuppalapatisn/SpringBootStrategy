# Endpoint Checklist

- [ ] Request DTO validated
- [ ] Response DTO created
- [ ] Service method added/updated
- [ ] Error handling updated
- [ ] Unit test added/updated
- [ ] Controller test added/updated
