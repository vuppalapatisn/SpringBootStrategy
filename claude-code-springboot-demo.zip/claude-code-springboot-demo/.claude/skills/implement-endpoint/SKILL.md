---
name: implement-endpoint
description: Create a production-grade Spring Boot REST endpoint with DTOs, service, validation, exception handling, and tests.
---

# Implement Endpoint

When invoked, do the following:

1. Identify the domain object and endpoint contract.
2. Create or update request and response DTOs.
3. Add or update controller method.
4. Add or update service method.
5. Add validation annotations and exception handling.
6. Add or adjust unit tests and controller tests.
7. Summarize changed files and assumptions.

## Constraints
- Never return entity objects directly.
- Keep controller thin.
- Follow existing package structure.
