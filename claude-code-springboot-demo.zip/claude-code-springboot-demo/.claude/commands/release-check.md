# Release Check

Run a final release readiness pass:

1. Review modified files
2. Run tests if available
3. Check risky config changes
4. Summarize go/no-go concerns
