# Orders Platform - Project Conventions

## Project Overview
Spring Boot 3 / Java 21 microservice for order creation and retrieval.

## Common Commands
- Build: `mvn clean install`
- Test: `mvn test`
- Run: `mvn spring-boot:run`
- Format: `mvn spotless:apply`

## Architecture
- Controller -> Service -> Repository
- DTOs for request/response
- Flyway for DB migrations
- Global exception handling via `@RestControllerAdvice`

## Global Rules
- Validate every incoming request.
- Never expose JPA entities directly from controllers.
- Keep controllers thin; business logic belongs in services.
- Add or update tests for business logic changes.
