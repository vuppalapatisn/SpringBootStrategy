package com.example.orders.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.orders.dto.OrderResponse;
import com.example.orders.service.OrderService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(OrderController.class)
class OrderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrderService orderService;

    @Test
    void createReturnsCreated() throws Exception {
        when(orderService.createOrder(any())).thenReturn(
            new OrderResponse(1L, "cust-101", "sku-123", 2, "CREATED")
        );

        mockMvc.perform(post("/api/orders")
                .contentType(MediaType.APPLICATION_JSON)
                .content('{"customerId":"cust-101","itemSku":"sku-123","quantity":2}'))
            .andExpect(status().isCreated())
            .andExpect(jsonPath('$.id').value(1));
    }

    @Test
    void getReturnsOrder() throws Exception {
        when(orderService.getOrder(1L)).thenReturn(
            new OrderResponse(1L, "cust-101", "sku-123", 2, "CREATED")
        );

        mockMvc.perform(get("/api/orders/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath('$.status').value("CREATED"));
    }
}
