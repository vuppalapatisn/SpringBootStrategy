package com.example.orders.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.example.orders.dto.CreateOrderRequest;
import com.example.orders.dto.OrderResponse;
import com.example.orders.model.Order;
import com.example.orders.repository.OrderRepository;
import org.junit.jupiter.api.Test;

class OrderServiceTest {

    @Test
    void createsOrder() {
        OrderRepository repository = mock(OrderRepository.class);
        OrderService service = new OrderService(repository);

        CreateOrderRequest request = new CreateOrderRequest();
        request.setCustomerId("cust-101");
        request.setItemSku("sku-123");
        request.setQuantity(2);

        when(repository.save(any(Order.class)))
            .thenAnswer(invocation -> {
                Order o = invocation.getArgument(0);
                o.setId(1L);
                return o;
            });

        OrderResponse response = service.createOrder(request);

        assertEquals(1L, response.id());
        assertEquals("cust-101", response.customerId());
        assertEquals("CREATED", response.status());
    }
}
