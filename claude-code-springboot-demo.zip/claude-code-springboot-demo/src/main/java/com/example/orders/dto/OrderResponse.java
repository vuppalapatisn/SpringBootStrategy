package com.example.orders.dto;

public record OrderResponse(Long id, String customerId, String itemSku, Integer quantity, String status) {}
