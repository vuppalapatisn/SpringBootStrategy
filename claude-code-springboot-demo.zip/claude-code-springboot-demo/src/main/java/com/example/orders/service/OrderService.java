package com.example.orders.service;

import com.example.orders.dto.CreateOrderRequest;
import com.example.orders.dto.OrderResponse;
import com.example.orders.model.Order;
import com.example.orders.repository.OrderRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    private final OrderRepository repository;

    public OrderService(OrderRepository repository) {
        this.repository = repository;
    }

    public OrderResponse createOrder(CreateOrderRequest request) {
        Order order = new Order(
            request.getCustomerId(),
            request.getItemSku(),
            request.getQuantity(),
            "CREATED"
        );

        Order saved = repository.save(order);

        return new OrderResponse(
            saved.getId(),
            saved.getCustomerId(),
            saved.getItemSku(),
            saved.getQuantity(),
            saved.getStatus()
        );
    }

    public OrderResponse getOrder(Long id) {
        Order order = repository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Order not found: " + id));

        return new OrderResponse(
            order.getId(),
            order.getCustomerId(),
            order.getItemSku(),
            order.getQuantity(),
            order.getStatus()
        );
    }
}
