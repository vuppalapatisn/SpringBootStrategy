package com.example.orders.model;

import jakarta.persistence.*;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_id", nullable = false)
    private String customerId;

    @Column(name = "item_sku", nullable = false)
    private String itemSku;

    @Column(nullable = false)
    private Integer quantity;

    @Column(nullable = false)
    private String status;

    public Order() {
    }

    public Order(String customerId, String itemSku, Integer quantity, String status) {
        this.customerId = customerId;
        this.itemSku = itemSku;
        this.quantity = quantity;
        this.status = status;
    }

    public Long getId() { return id; }
    public String getCustomerId() { return customerId; }
    public String getItemSku() { return itemSku; }
    public Integer getQuantity() { return quantity; }
    public String getStatus() { return status; }

    public void setId(Long id) { this.id = id; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }
    public void setItemSku(String itemSku) { this.itemSku = itemSku; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
    public void setStatus(String status) { this.status = status; }
}
