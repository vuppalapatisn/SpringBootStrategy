package com.example.orders.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class CreateOrderRequest {

    @NotBlank
    private String customerId;

    @NotBlank
    private String itemSku;

    @NotNull
    @Min(1)
    private Integer quantity;

    public String getCustomerId() { return customerId; }
    public String getItemSku() { return itemSku; }
    public Integer getQuantity() { return quantity; }

    public void setCustomerId(String customerId) { this.customerId = customerId; }
    public void setItemSku(String itemSku) { this.itemSku = itemSku; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
}
