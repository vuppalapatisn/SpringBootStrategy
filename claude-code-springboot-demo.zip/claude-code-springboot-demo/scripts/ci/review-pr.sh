#!/usr/bin/env bash
set -euo pipefail

claude --bare -p   "Review the current git diff for correctness, validation coverage, security risks, and missing tests. Return JSON."   --allowedTools "Read,Grep,Glob"   --output-format json
