#!/usr/bin/env python3
import json
import re
import sys

# Lightweight PreToolUse validator/logger.
# For hard blocking, adapt this to the exact latest return schema from the official hook reference
# or use the Agent SDK callback example under examples/.

try:
    payload = json.load(sys.stdin)
except Exception:
    payload = {}

text = json.dumps(payload)
blocked_patterns = [r'\.env', r'application-prod\.yml', r'secrets\.properties']
for pat in blocked_patterns:
    if re.search(pat, text):
        print(f"WARNING: sensitive target referenced: pattern={pat}", file=sys.stderr)
        break

sys.exit(0)
