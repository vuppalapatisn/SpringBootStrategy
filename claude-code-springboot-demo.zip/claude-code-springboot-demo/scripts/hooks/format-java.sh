#!/usr/bin/env bash
set -euo pipefail

payload="$(cat || true)"
if [[ -f "pom.xml" ]]; then
  mvn -q spotless:apply >/dev/null 2>&1 || true
fi
exit 0
