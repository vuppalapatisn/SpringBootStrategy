#!/usr/bin/env python3
import json
import os
from datetime import datetime, timezone
import sys

try:
    payload = json.load(sys.stdin)
except Exception:
    payload = {"note": "No JSON payload parsed on stdin"}

os.makedirs('.claude/audit', exist_ok=True)
with open('.claude/audit/tool-use.log', 'a', encoding='utf-8') as f:
    f.write(json.dumps({
        'ts': datetime.now(timezone.utc).isoformat(),
        'event': 'PostToolUse',
        'payload': payload
    }) + '
')
