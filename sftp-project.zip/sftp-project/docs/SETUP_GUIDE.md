# ═══════════════════════════════════════════════════════════════════════════════
# AZURE DEVOPS ADMIN SETUP GUIDE
# AWS Transfer Family SFTP — Complete Configuration
# ═══════════════════════════════════════════════════════════════════════════════
#
# AUDIENCE: DevOps administrators setting up this pipeline from scratch
# TIME:     ~2 hours for first-time setup
# ───────────────────────────────────────────────────────────────────────────────

# ═══════════════════════════════════════════════════════════════════════════════
# PART 1: PREREQUISITES
# ═══════════════════════════════════════════════════════════════════════════════

## 1.1 Required tools on your workstation
- Azure CLI:       https://docs.microsoft.com/en-us/cli/azure/install-azure-cli
- AWS CLI v2:      https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html
- Python 3.11+:    https://www.python.org/downloads/
- Docker:          https://docs.docker.com/get-docker/

## 1.2 Required accounts / access
- Azure DevOps organization with admin rights
- AWS accounts for dev, test, prod (separate accounts recommended)
- Checkmarx CxSAST account (or Checkmarx One)
- Anthropic API key: https://console.anthropic.com/
- Azure subscription (for deploying Claude agent as App Service)

# ═══════════════════════════════════════════════════════════════════════════════
# PART 2: AWS SETUP (per environment: dev / test / prod)
# ═══════════════════════════════════════════════════════════════════════════════

## 2.1 Create IAM user for Azure DevOps (do this in EACH AWS account)

# Log into AWS console → IAM → Users → Create user
# Username: azuredevops-sftp-deploy
# Access type: Programmatic access (access key)
#
# Attach this inline policy:
# (Save as iam-devops-policy.json)

{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "CloudFormationFull",
      "Effect": "Allow",
      "Action": [
        "cloudformation:*"
      ],
      "Resource": "*"
    },
    {
      "Sid": "S3ForCFN",
      "Effect": "Allow",
      "Action": [
        "s3:CreateBucket",
        "s3:DeleteBucket",
        "s3:PutBucketPolicy",
        "s3:PutBucketEncryption",
        "s3:PutBucketVersioning",
        "s3:PutBucketPublicAccessBlock",
        "s3:PutBucketObjectLockConfiguration",
        "s3:PutLifecycleConfiguration",
        "s3:PutBucketNotification",
        "s3:GetBucketLocation",
        "s3:HeadBucket",
        "s3:GetEncryptionConfiguration"
      ],
      "Resource": "*"
    },
    {
      "Sid": "IAMForSFTP",
      "Effect": "Allow",
      "Action": [
        "iam:CreateRole",
        "iam:DeleteRole",
        "iam:PutRolePolicy",
        "iam:DeleteRolePolicy",
        "iam:AttachRolePolicy",
        "iam:DetachRolePolicy",
        "iam:CreateManagedPolicy",
        "iam:DeleteManagedPolicy",
        "iam:GetRole",
        "iam:PassRole",
        "iam:TagRole",
        "iam:GetManagedPolicy"
      ],
      "Resource": "*"
    },
    {
      "Sid": "TransferFamilyFull",
      "Effect": "Allow",
      "Action": ["transfer:*"],
      "Resource": "*"
    },
    {
      "Sid": "KMSFull",
      "Effect": "Allow",
      "Action": ["kms:*"],
      "Resource": "*"
    },
    {
      "Sid": "CloudWatchLogs",
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:DeleteLogGroup",
        "logs:PutRetentionPolicy",
        "logs:DescribeLogGroups",
        "logs:AssociateKmsKey"
      ],
      "Resource": "*"
    },
    {
      "Sid": "SNSForAlerts",
      "Effect": "Allow",
      "Action": ["sns:*"],
      "Resource": "*"
    },
    {
      "Sid": "GuardDuty",
      "Effect": "Allow",
      "Action": ["guardduty:*"],
      "Resource": "*"
    },
    {
      "Sid": "CloudTrail",
      "Effect": "Allow",
      "Action": ["cloudtrail:*"],
      "Resource": "*"
    },
    {
      "Sid": "EC2ForVPC",
      "Effect": "Allow",
      "Action": [
        "ec2:CreateSecurityGroup",
        "ec2:DeleteSecurityGroup",
        "ec2:AuthorizeSecurityGroupIngress",
        "ec2:RevokeSecurityGroupIngress",
        "ec2:DescribeVpcs",
        "ec2:DescribeSubnets",
        "ec2:DescribeSecurityGroups"
      ],
      "Resource": "*"
    },
    {
      "Sid": "Route53Optional",
      "Effect": "Allow",
      "Action": [
        "route53:ChangeResourceRecordSets",
        "route53:GetHostedZone",
        "route53:ListResourceRecordSets"
      ],
      "Resource": "*"
    },
    {
      "Sid": "EventsForGuardDuty",
      "Effect": "Allow",
      "Action": ["events:*"],
      "Resource": "*"
    }
  ]
}

# After creating the user, note:
#   Access Key ID:     AKIAIOSFODNN7EXAMPLE
#   Secret Access Key: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
# (You'll need these for the service connection in step 3)


# ═══════════════════════════════════════════════════════════════════════════════
# PART 3: AZURE DEVOPS SERVICE CONNECTIONS
# ═══════════════════════════════════════════════════════════════════════════════

## 3.1 Install the AWS Toolkit for Azure DevOps
# 1. Go to: https://marketplace.visualstudio.com/items?itemName=AmazonWebServices.aws-vsts-tools
# 2. Click "Get it free"
# 3. Select your Azure DevOps organization → Install

## 3.2 Create AWS service connections (one per environment)
# Azure DevOps → Project Settings → Service connections → New service connection
# Type: AWS

# For DEV environment:
#   Connection name: aws-dev
#   Access Key ID:   (from step 2.1 dev account)
#   Secret Access Key: (from step 2.1 dev account)
#   Default Region:  us-east-1  (or your region)
#   ✓ Grant access permissions to all pipelines
#   → Verify and Save

# Repeat for TEST (name: aws-test) and PROD (name: aws-prod)

## 3.3 Create Checkmarx service connection
# Azure DevOps → Project Settings → Service connections → New service connection
# Type: Checkmarx (requires CxScanner extension — install from marketplace)
#   Connection name: CxSAST-ServiceConnection
#   Server URL:      https://your-cx-server.checkmarx.net
#   Username:        cx-scan-user
#   Password:        (CX password — mark as secret)
#   Team:            /CxServer/YourTeam
#   → Verify and Save


# ═══════════════════════════════════════════════════════════════════════════════
# PART 4: AZURE DEVOPS LIBRARY — VARIABLE GROUPS
# ═══════════════════════════════════════════════════════════════════════════════

## 4.1 Create variable groups
# Azure DevOps → Pipelines → Library → + Variable group

# Create these 4 groups (see docs/variable-groups.yaml for all values):
#   sftp-pipeline-common
#   sftp-pipeline-dev
#   sftp-pipeline-test
#   sftp-pipeline-prod

## 4.2 Link to Azure Key Vault (recommended for prod secrets)
# In the variable group → Link secrets from Azure Key Vault
# Add: CLAUDE_API_KEY, AGENT_API_KEY, CX_PASSWORD
# This requires an Azure service connection to your Key Vault.

## 4.3 Grant pipeline permissions
# For each variable group:
#   Pipeline permissions → + (add your pipeline) → Allow


# ═══════════════════════════════════════════════════════════════════════════════
# PART 5: CREATE THE PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════

## 5.1 Import the repository
# Azure DevOps → Repos → Import repository
# Source: your GitHub/ADO repo with the sftp-project files

## 5.2 Create the pipeline
# Azure DevOps → Pipelines → New Pipeline
# 1. Where is your code? → Azure Repos Git
# 2. Select your repository
# 3. Configure → Existing Azure Pipelines YAML file
# 4. Branch: main  |  Path: /pipeline/azure-pipelines.yml
# 5. → Continue → Save (don't run yet)

## 5.3 Set pipeline permissions
# Pipeline → Edit → ... (3 dots) → Triggers
# Set: Branch filters → main, develop, release/*
# Enable: Pull request validation

## 5.4 Create environments (for deployment approvals)
# Azure DevOps → Pipelines → Environments → New environment
#   Name: dev   → No approvals needed (check box: "None")
#   Name: test  → No approvals needed
#   Name: prod  → Approvals and checks:
#                   + Approvals → add your security/ops team
#                   + Business hours (optional)

## 5.5 Configure Checkmarx extension
# Marketplace → search "Checkmarx" → Install CxScanner extension
# After install, the CxScanner@2 task will be available.


# ═══════════════════════════════════════════════════════════════════════════════
# PART 6: DEPLOY THE CLAUDE AGENT SERVICE
# ═══════════════════════════════════════════════════════════════════════════════

## 6.1 Build the Docker image
cd mcp-agent/
docker build -t claude-sftp-agent:latest .

## 6.2 Option A: Deploy to Azure App Service (recommended)
# Create Azure Container Registry:
az acr create --name sftp-agent-registry --resource-group sftp-rg --sku Basic

# Push image:
az acr login --name sftp-agent-registry
docker tag claude-sftp-agent:latest sftp-agent-registry.azurecr.io/claude-agent:latest
docker push sftp-agent-registry.azurecr.io/claude-agent:latest

# Create App Service:
az appservice plan create --name sftp-agent-plan --resource-group sftp-rg --sku B1 --is-linux
az webapp create \
  --name sftp-claude-agent \
  --resource-group sftp-rg \
  --plan sftp-agent-plan \
  --deployment-container-image-name sftp-agent-registry.azurecr.io/claude-agent:latest

# Set environment variables:
az webapp config appsettings set \
  --name sftp-claude-agent \
  --resource-group sftp-rg \
  --settings \
    CLAUDE_API_KEY="sk-ant-YOUR_KEY" \
    AGENT_API_KEY="YOUR_RANDOM_SECRET" \
    WEBSITES_PORT=8080

# Get the URL:
az webapp show --name sftp-claude-agent --resource-group sftp-rg --query "defaultHostName" -o tsv
# → sftp-claude-agent.azurewebsites.net
# Update CLAUDE_AGENT_URL in variable group: https://sftp-claude-agent.azurewebsites.net

## 6.3 Option B: Run locally for testing
cd mcp-agent/
pip install -r requirements.txt
export CLAUDE_API_KEY="sk-ant-YOUR_KEY"
export AGENT_API_KEY="test-key"
uvicorn src.main:app --host 0.0.0.0 --port 8080 --reload
# Test: curl http://localhost:8080/health


# ═══════════════════════════════════════════════════════════════════════════════
# PART 7: UPDATE PARAMETER FILES
# ═══════════════════════════════════════════════════════════════════════════════

## 7.1 Edit cloudformation/parameters/dev.json
# Replace ALL REPLACE_WITH_* placeholders:
#   vpc-REPLACE_WITH_DEV_VPC_ID   → your dev VPC ID (e.g. vpc-0a1b2c3d4e5f67890)
#   subnet-REPLACE_1,subnet-REPLACE_2 → your subnet IDs
#   devops-alerts-dev@example.com → real email address

## 7.2 Same for test.json and prod.json

## 7.3 Validate locally before pushing:
pip install cfn-lint
cfn-lint cloudformation/templates/sftp-main.yaml
python3 scripts/validate/validate_parameters.py \
  --params-file cloudformation/parameters/dev.json \
  --template-file cloudformation/templates/sftp-main.yaml \
  --environment dev


# ═══════════════════════════════════════════════════════════════════════════════
# PART 8: FIRST DEPLOYMENT
# ═══════════════════════════════════════════════════════════════════════════════

## 8.1 Deploy to dev first
# Azure DevOps → Pipelines → Run pipeline
# Parameters:
#   targetEnvironment: dev
#   deployStack: true
#   destroyStack: false
# → Run

## 8.2 Verify deployment
# After pipeline succeeds:
# AWS Console → CloudFormation → myproject-dev-sftp → Outputs
# Copy SftpServerEndpoint value → test SFTP connection:
#   sftp -i your-private-key.pem sftp-rw-user01@<SftpServerEndpoint>

## 8.3 Deploy to test, then prod
# Repeat step 8.1 with targetEnvironment: test, then prod
# Prod requires manual approval — approvers receive email notification


# ═══════════════════════════════════════════════════════════════════════════════
# PART 9: CHECKMARX SCAN FAILURE — WHAT HAPPENS
# ═══════════════════════════════════════════════════════════════════════════════

## When Checkmarx fails:
# 1. CxScanner@2 task exits with code 1
# 2. condition: failed() triggers the "CallClaudeAgent" step
# 3. Claude agent receives the SARIF report via POST /api/fix-security
# 4. Agent calls Anthropic API for each finding → returns:
#      what_is_wrong: "The S3 bucket policy allows public access..."
#      how_to_fix:    "Add PublicAccessBlockConfiguration with all fields set to true..."
#      fixed_code:    (corrected YAML)
# 5. If auto-fixable: agent opens a PR named agent/cx-fix-{env}-{buildId}
# 6. PR description contains all errors + fixes in plain English
# 7. Pipeline artifact claude-remediation/claude-remediation-report.json contains full report
# 8. "Enforce security gate" step fails the pipeline build
#    → developer sees the error in the pipeline UI and the PR in Azure Repos

## To view the report:
# Pipeline run → Artifacts → claude-remediation → claude-remediation-report.json

## Common Checkmarx findings in CloudFormation + fixes:
# INSECURE_BUCKET_POLICY     → Add PublicAccessBlockConfiguration
# MISSING_ENCRYPTION         → Add BucketEncryption with KMS
# OVERLY_PERMISSIVE_IAM      → Scope Resource to specific ARNs
# HARDCODED_CREDENTIALS      → Move to Secrets Manager / Parameter Store
# UNRESTRICTED_PORT_22       → Add specific CIDR to SecurityGroupIngress
# MISSING_SSL_ENFORCEMENT    → Add bucket policy Deny on aws:SecureTransport=false


# ═══════════════════════════════════════════════════════════════════════════════
# PART 10: ADDING SFTP USERS
# ═══════════════════════════════════════════════════════════════════════════════

## User types and home directory pattern:
# readwrite:       /SftpBucketName/readwrite/username/
# readwritedelete: /SftpBucketName/readwritedelete/username/
# writeonly:       /SftpBucketName/writeonly/username/
# readonly:        /SftpBucketName/readonly/username/

## To add a new user:
# 1. Generate SSH key pair:
#    ssh-keygen -t ed25519 -f sftp-user-key -C "sftp-rw-user02"
#
# 2. Add to cloudformation/templates/sftp-users.yaml:
#    Copy an existing user block and change:
#      UserName, HomeDirectoryMappings target, Tags UserType
#
# 3. Add public key parameter to the Parameters section
#
# 4. Deploy sftp-users.yaml as a separate stack (or nested stack)
#
# 5. Send private key to user via secure channel (NOT email)
#
# SFTP connection string:
#   sftp -i ~/.ssh/sftp-user-key sftp-ro-user01@<SftpServerEndpoint>
