# AWS Transfer Family SFTP — Complete DevOps Project

AWS Transfer Family SFTP server backed by S3, deployed via Azure DevOps pipeline
with Checkmarx security scanning and Claude MCP agent for automated error correction.

## Architecture

```
Azure DevOps Pipeline
  ├── Validate stage    → cfn-lint, parameter validation, bucket/connection checks
  ├── SecurityScan      → Checkmarx SAST  ──[fail]──► Claude MCP Agent
  ├── Plan              → CloudFormation change set
  ├── ApprovalGate      → Manual approval (prod only)
  └── Deploy            → Execute change set + verify

AWS Infrastructure
  ├── Transfer Family SFTP (VPC endpoint, 4 user types)
  ├── S3 data bucket    → KMS encrypted, versioned, no public access
  ├── S3 logs bucket    → Object Lock GOVERNANCE (365d prod / 10d dev)
  ├── GuardDuty         → S3 + CloudTrail data sources, finding alerts
  ├── CloudTrail        → Multi-region (prod), S3 data events logged
  ├── CloudWatch Alarms → SFTP auth failure alerting
  └── SNS               → Email alerts for security events
```

## SFTP User Types

| Type | Read | Write | Delete | Home directory pattern |
|---|---|---|---|---|
| `readwrite` | ✅ | ✅ | ❌ | `/bucket/readwrite/username/` |
| `readwritedelete` | ✅ | ✅ | ✅ | `/bucket/readwritedelete/username/` |
| `writeonly` | ❌ | ✅ | ❌ | `/bucket/writeonly/username/` |
| `readonly` | ✅ | ❌ | ❌ | `/bucket/readonly/username/` |

## Log Retention

| Environment | Retention | S3 Object Lock Mode |
|---|---|---|
| prod | 365 days | GOVERNANCE |
| test | 30 days | GOVERNANCE |
| dev | 10 days | GOVERNANCE |

## Project Structure

```
sftp-project/
├── cloudformation/
│   ├── templates/
│   │   ├── sftp-main.yaml       # SFTP server, S3, IAM, GuardDuty, CloudTrail
│   │   └── sftp-users.yaml      # SFTP user definitions (4 user types)
│   └── parameters/
│       ├── dev.json
│       ├── test.json
│       └── prod.json
├── pipeline/
│   └── azure-pipelines.yml      # Complete CI/CD pipeline
├── scripts/
│   ├── validate/
│   │   ├── validate_parameters.py
│   │   ├── validate_buckets.py
│   │   └── validate_service_connections.py
│   └── deploy/
│       ├── describe_changeset.py
│       └── post_deploy_verify.py
├── mcp-agent/                   # Claude auto-remediation service
│   ├── src/
│   │   ├── main.py              # FastAPI app
│   │   ├── claude_client.py     # Anthropic API calls
│   │   ├── sarif_parser.py      # Checkmarx SARIF parsing
│   │   ├── ado_client.py        # Azure DevOps REST (create fix PR)
│   │   └── report.py            # Error report builder
│   ├── requirements.txt
│   └── Dockerfile
└── docs/
    ├── SETUP_GUIDE.md           # Step-by-step admin configuration
    └── variable-groups.yaml     # All variable group definitions
```

## Quick Start

1. Read `docs/SETUP_GUIDE.md` — complete step-by-step instructions
2. Fill in `cloudformation/parameters/dev.json` with your VPC/subnet IDs
3. Create variable groups in Azure DevOps (see `docs/variable-groups.yaml`)
4. Deploy the Claude agent: `cd mcp-agent && docker build -t claude-agent .`
5. Create the pipeline pointing to `pipeline/azure-pipelines.yml`
6. Run the pipeline with `targetEnvironment: dev`

## What Happens on Checkmarx Failure

1. `CxScanner@2` exits non-zero → pipeline `condition: failed()` triggers
2. SARIF report is POSTed to Claude agent at `CLAUDE_AGENT_URL/api/fix-security`
3. Claude analyses each finding and returns:
   - **What is wrong**: plain-English vulnerability explanation
   - **How to fix**: step-by-step remediation with code examples
   - **Fixed code**: corrected CloudFormation YAML (if auto-fixable)
4. Agent opens a fix PR in Azure Repos with full error details
5. Pipeline artifact `claude-remediation-report.json` contains the full report
6. Developer reviews the PR, verifies fixes, re-runs pipeline

## Security Features

- All S3 buckets: KMS encrypted, versioned, public access blocked, SSL-only policy
- SFTP: VPC endpoint only, security group scoped to allowed CIDRs
- IAM: least-privilege per user type, home directory scoped via logical mappings
- GuardDuty: enabled with S3 + CloudTrail data sources, 15-min finding frequency (prod)
- CloudTrail: S3 data events, log file validation, multi-region (prod only)
- Logs bucket: S3 Object Lock GOVERNANCE mode, separate from data bucket
- CloudWatch: SFTP auth failure alarm (threshold: 5 in prod, 20 in dev)
