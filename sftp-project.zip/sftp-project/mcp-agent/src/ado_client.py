"""
ado_client.py
Azure DevOps REST API client.
Gets file content from a repo and creates fix PRs.
"""
import httpx
import base64
import json
import logging
from typing import List, Dict, Optional

log = logging.getLogger("claude-agent.ado_client")

async def get_file_content(
    http:       httpx.AsyncClient,
    repo_url:   str,
    branch:     str,
    file_path:  str,
    ado_pat:    str
) -> str:
    """Fetch file content from Azure Repos via REST API."""
    auth = base64.b64encode(f":{ado_pat}".encode()).decode()
    headers = {"Authorization": f"Basic {auth}"}

    # ADO REST: GET items endpoint
    url = f"{repo_url}/items?path={file_path}&versionDescriptor.versionType=Branch&versionDescriptor.version={branch}&api-version=7.1"

    try:
        resp = await http.get(url, headers=headers)
        resp.raise_for_status()
        return resp.text
    except Exception as e:
        log.warning(f"Could not fetch {file_path} from {repo_url}: {e}")
        return ""

async def create_fix_pr(
    repo_url:    str,
    base_branch: str,
    build_id:    str,
    patches:     List[Dict],
    ado_pat:     str,
    org_url:     str,
    team_project:str,
    environment: str,
    fix_report:  list
) -> Optional[str]:
    """
    1. Get latest commit OID on base_branch
    2. Push patched files to a new fix branch
    3. Open a PR with a descriptive body showing errors + fixes
    Returns the PR URL.
    """
    auth    = base64.b64encode(f":{ado_pat}".encode()).decode()
    headers = {"Authorization": f"Basic {auth}", "Content-Type": "application/json"}
    fix_branch = f"agent/cx-fix-{environment}-{build_id}"

    async with httpx.AsyncClient(timeout=60) as http:
        # ── Get latest commit OID ──────────────────────────────────────────────
        refs_url = f"{repo_url}/refs?filter=heads/{base_branch}&api-version=7.1"
        refs_resp = await http.get(refs_url, headers=headers)
        refs_resp.raise_for_status()
        refs = refs_resp.json().get("value", [])
        if not refs:
            raise ValueError(f"Branch '{base_branch}' not found in {repo_url}")
        latest_oid = refs[0]["objectId"]

        # ── Create fix branch ──────────────────────────────────────────────────
        create_ref_url = f"{repo_url}/refs?api-version=7.1"
        await http.post(create_ref_url, headers=headers, json=[{
            "name":       f"refs/heads/{fix_branch}",
            "newObjectId": latest_oid,
            "oldObjectId": "0000000000000000000000000000000000000000"
        }])

        # ── Push patched files ─────────────────────────────────────────────────
        changes = []
        for patch in patches:
            content_b64 = base64.b64encode(patch["fixed_code"].encode()).decode()
            changes.append({
                "changeType": "edit",
                "item": {"path": f"/{patch['file_path']}"},
                "newContent": {
                    "content":     patch["fixed_code"],
                    "contentType": "rawtext"
                }
            })

        push_url = f"{repo_url}/pushes?api-version=7.1"
        push_body = {
            "refUpdates": [{"name": f"refs/heads/{fix_branch}", "oldObjectId": latest_oid}],
            "commits": [{
                "comment": f"fix(security): agent auto-remediation for {len(patches)} Checkmarx finding(s) [build {build_id}]",
                "changes": changes
            }]
        }
        push_resp = await http.post(push_url, headers=headers, json=push_body)
        push_resp.raise_for_status()

        # ── Build PR description ───────────────────────────────────────────────
        pr_desc = _build_pr_description(fix_report, build_id, environment)

        # ── Open PR ───────────────────────────────────────────────────────────
        pr_url_endpoint = f"{repo_url}/pullrequests?api-version=7.1"
        pr_body = {
            "title":         f"fix(security): Claude agent — Checkmarx auto-remediation [{environment}] build {build_id}",
            "description":   pr_desc,
            "sourceRefName": f"refs/heads/{fix_branch}",
            "targetRefName": f"refs/heads/{base_branch}",
            "labels":        [{"name": "security-autofix"}, {"name": "claude-agent"}],
            "reviewers":     []
        }
        pr_resp = await http.post(pr_url_endpoint, headers=headers, json=pr_body)
        pr_resp.raise_for_status()
        pr_data = pr_resp.json()
        pr_id   = pr_data.get("pullRequestId")
        return f"{repo_url}/pullrequests/{pr_id}"

def _build_pr_description(fix_report: list, build_id: str, env: str) -> str:
    lines = [
        f"## Claude MCP Security Fix Agent — Build {build_id} ({env})",
        "",
        "Checkmarx SAST scan detected security issues. "
        "This PR contains auto-generated fixes from the Claude security agent.",
        "",
        "---",
        ""
    ]
    for i, item in enumerate(fix_report, 1):
        finding = item.get("finding", {})
        lines += [
            f"### Finding {i}: `{finding.get('rule_id', 'UNKNOWN')}` "
            f"— **{finding.get('severity', 'medium').upper()}**",
            "",
            f"**File:** `{item.get('file_path', 'N/A')}` "
            f"line {item.get('line', '?')}",
            "",
            "#### What is wrong",
            item.get("what_is_wrong", "_No description_"),
            "",
            "#### How to fix",
            item.get("how_to_fix", "_No suggestion_"),
            "",
            f"**Auto-applied:** {'Yes' if item.get('auto_fixable') else 'No — manual review required'}",
            "",
            "---",
            ""
        ]
    lines += [
        "**Review this PR carefully before merging.**",
        "Run the pipeline on this branch to verify the fixes pass the Checkmarx scan.",
        ""
    ]
    return "\n".join(lines)
