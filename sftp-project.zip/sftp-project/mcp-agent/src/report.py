"""report.py — Builds the structured error+fix report returned by the agent API."""
from typing import List, Dict

def build_error_report(
    findings:   List[Dict],
    fix_report: List[Dict],
    patches:    List[Dict],
    environment: str
) -> list:
    """
    Builds a list of report items, each containing:
      - finding metadata
      - plain-English explanation of what went wrong
      - step-by-step how to fix it
      - whether a patch was auto-applied
    """
    patched_files = {p["file_path"] for p in patches}
    report = []

    for item in fix_report:
        finding = item.get("finding", {})
        report.append({
            "rule_id":              finding.get("rule_id", "UNKNOWN"),
            "rule_name":            finding.get("rule_name", ""),
            "severity":             finding.get("severity", "medium"),
            "file":                 item.get("file_path", ""),
            "line":                 item.get("line", 0),
            "environment":          environment,

            # Core error report fields
            "what_is_wrong":        item.get("what_is_wrong", "See Checkmarx report"),
            "how_to_fix":           item.get("how_to_fix", "Review manually"),
            "impact":               item.get("impact", ""),
            "severity_explanation": item.get("severity_explanation", ""),
            "references":           item.get("references", []),

            # Remediation status
            "auto_fixed":           item.get("file_path") in patched_files and item.get("auto_fixable", False),
            "patch_included_in_pr": item.get("file_path") in patched_files,

            # Fixed code preview (first 500 chars)
            "fixed_code_preview":   (item.get("fixed_code") or "")[:500] or None,
        })

    # Summary section
    high_count = sum(1 for f in findings if f.get("severity") == "high")
    med_count  = sum(1 for f in findings if f.get("severity") == "medium")

    report.append({
        "type":         "summary",
        "total":        len(findings),
        "high":         high_count,
        "medium":       med_count,
        "auto_fixed":   len(patches),
        "manual_needed":len(findings) - len(patches),
        "message": (
            f"Checkmarx found {len(findings)} issue(s) "
            f"({high_count} high, {med_count} medium). "
            f"{len(patches)} were auto-patched. "
            f"{len(findings)-len(patches)} require manual review."
        )
    })

    return report
