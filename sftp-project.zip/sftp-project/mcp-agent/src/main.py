"""
mcp-agent/src/main.py
Claude MCP Security Fix Agent
──────────────────────────────
FastAPI service that:
  1. Receives Checkmarx SARIF findings from Azure DevOps pipeline
  2. Calls Claude (Anthropic API) to analyse and suggest fixes
  3. Opens a fix PR in Azure Repos with corrected CloudFormation/IaC files
  4. Returns a detailed error report with what-was-wrong + how-to-fix
"""
from fastapi import FastAPI, HTTPException, Header, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional
import json
import os
import logging
import httpx
import asyncio
from datetime import datetime

from .sarif_parser import parse_sarif
from .claude_client import get_fix_suggestions
from .ado_client   import create_fix_pr, get_file_content
from .report       import build_error_report

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
log = logging.getLogger("claude-agent")

app = FastAPI(
    title="Claude MCP Security Fix Agent",
    description="Auto-remediation agent for Checkmarx SAST findings in CloudFormation templates",
    version="1.0.0"
)

CLAUDE_API_KEY  = os.environ.get("CLAUDE_API_KEY", "")
EXPECTED_API_KEY = os.environ.get("AGENT_API_KEY", "change-me-in-production")

# ── AUTH MIDDLEWARE ────────────────────────────────────────────────────────────
@app.middleware("http")
async def verify_api_key(request: Request, call_next):
    if request.url.path in ("/health", "/docs", "/openapi.json"):
        return await call_next(request)
    key = request.headers.get("x-api-key", "")
    if key != EXPECTED_API_KEY:
        return JSONResponse(status_code=401, content={"error": "Invalid API key"})
    return await call_next(request)

# ── MODELS ─────────────────────────────────────────────────────────────────────
class FixRequest(BaseModel):
    buildId:      str
    repoUrl:      str
    branch:       str
    environment:  str
    projectName:  str
    adoPat:       str
    orgUrl:       str
    teamProject:  str
    sarifContent: str          # raw SARIF JSON as string

class FixResponse(BaseModel):
    success:        bool
    buildId:        str
    totalFindings:  int
    autoFixed:      int
    prUrl:          Optional[str]
    report:         list        # per-finding: what-was-wrong + how-to-fix
    timestamp:      str

# ── ENDPOINTS ─────────────────────────────────────────────────────────────────
@app.get("/health")
async def health():
    return {"status": "ok", "service": "claude-mcp-agent"}

@app.post("/api/fix-security", response_model=FixResponse)
async def fix_security(req: FixRequest):
    log.info(f"Received fix request: buildId={req.buildId} env={req.environment}")

    # 1. Parse SARIF
    try:
        sarif_data = json.loads(req.sarifContent)
        findings = parse_sarif(sarif_data)
        log.info(f"Parsed {len(findings)} findings from SARIF")
    except Exception as e:
        log.error(f"SARIF parse error: {e}")
        raise HTTPException(status_code=400, detail=f"Invalid SARIF: {e}")

    if not findings:
        return FixResponse(
            success=True,
            buildId=req.buildId,
            totalFindings=0,
            autoFixed=0,
            prUrl=None,
            report=[{"message": "No findings in SARIF — nothing to fix"}],
            timestamp=datetime.utcnow().isoformat()
        )

    # 2. Get source files for affected findings
    patches    = []
    fix_report = []

    async with httpx.AsyncClient(timeout=300) as http:
        for finding in findings:
            log.info(f"Processing finding: {finding['rule_id']} in {finding['file_path']}")

            # Fetch source file from ADO
            source_code = ""
            try:
                source_code = await get_file_content(
                    http, req.repoUrl, req.branch,
                    finding["file_path"], req.adoPat
                )
            except Exception as e:
                log.warning(f"Could not fetch {finding['file_path']}: {e}")

            # Call Claude for fix suggestion
            suggestion = await get_fix_suggestions(
                http,
                finding     = finding,
                source_code = source_code,
                environment = req.environment,
                api_key     = CLAUDE_API_KEY
            )

            fix_report.append({
                "finding":       finding,
                "what_is_wrong": suggestion.get("what_is_wrong", ""),
                "how_to_fix":    suggestion.get("how_to_fix", ""),
                "fixed_code":    suggestion.get("fixed_code", ""),
                "severity":      finding.get("severity", ""),
                "file_path":     finding["file_path"],
                "line":          finding.get("line", 0),
                "auto_fixable":  suggestion.get("auto_fixable", False),
                "references":    suggestion.get("references", [])
            })

            if suggestion.get("auto_fixable") and suggestion.get("fixed_code"):
                patches.append({
                    "file_path":  finding["file_path"],
                    "fixed_code": suggestion["fixed_code"],
                    "rule_id":    finding["rule_id"]
                })

    # 3. Create fix PR if we have patches
    pr_url = None
    if patches:
        try:
            pr_url = await create_fix_pr(
                repo_url    = req.repoUrl,
                base_branch = req.branch,
                build_id    = req.buildId,
                patches     = patches,
                ado_pat     = req.adoPat,
                org_url     = req.orgUrl,
                team_project= req.teamProject,
                environment = req.environment,
                fix_report  = fix_report
            )
            log.info(f"Fix PR created: {pr_url}")
        except Exception as e:
            log.error(f"Failed to create PR: {e}")
            fix_report.append({
                "finding":       {"rule_id": "PR_CREATION"},
                "what_is_wrong": "Could not automatically open a fix PR",
                "how_to_fix":    f"Apply patches manually. Error: {e}",
                "auto_fixable":  False
            })

    # 4. Build full report
    full_report = build_error_report(findings, fix_report, patches, req.environment)

    return FixResponse(
        success     = True,
        buildId     = req.buildId,
        totalFindings = len(findings),
        autoFixed   = len(patches),
        prUrl       = pr_url,
        report      = full_report,
        timestamp   = datetime.utcnow().isoformat()
    )
