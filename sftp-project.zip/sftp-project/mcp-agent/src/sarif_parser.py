"""sarif_parser.py — parse Checkmarx SARIF output into finding dicts"""
from typing import List, Dict, Any

def parse_sarif(sarif: dict) -> List[Dict[str, Any]]:
    findings = []
    for run in sarif.get("runs", []):
        rules_map = {
            r["id"]: r for r in
            run.get("tool", {}).get("driver", {}).get("rules", [])
        }
        for result in run.get("results", []):
            rule_id  = result.get("ruleId", "UNKNOWN")
            rule_def = rules_map.get(rule_id, {})
            message  = result.get("message", {}).get("text", "")
            severity = _map_severity(result.get("level", "warning"))

            for loc in result.get("locations", []):
                phys = loc.get("physicalLocation", {})
                art  = phys.get("artifactLocation", {})
                reg  = phys.get("region", {})
                findings.append({
                    "rule_id":     rule_id,
                    "rule_name":   rule_def.get("name", rule_id),
                    "severity":    severity,
                    "message":     message,
                    "file_path":   art.get("uri", "unknown"),
                    "line":        reg.get("startLine", 0),
                    "description": rule_def.get("shortDescription", {}).get("text", ""),
                    "help_uri":    rule_def.get("helpUri", ""),
                })
    return findings

def _map_severity(level: str) -> str:
    return {"error": "high", "warning": "medium", "note": "low"}.get(level, "medium")
