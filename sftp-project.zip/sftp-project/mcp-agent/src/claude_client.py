"""
claude_client.py
Calls Anthropic Claude API to analyse a Checkmarx finding and return:
  - what_is_wrong:  plain-English explanation of the vulnerability
  - how_to_fix:     step-by-step remediation instructions
  - fixed_code:     corrected version of the file (if auto-fixable)
  - auto_fixable:   bool — can the agent apply this automatically?
  - references:     AWS docs / CWE links
"""
import json
import logging
import httpx
from typing import Optional

log = logging.getLogger("claude-agent.claude_client")

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
MODEL             = "claude-sonnet-4-6"

# Rules the agent will attempt to auto-patch
AUTO_FIXABLE_RULES = {
    "HARDCODED_CREDENTIALS",
    "HARDCODED_SECRET",
    "INSECURE_BUCKET_POLICY",
    "MISSING_ENCRYPTION",
    "PUBLIC_BUCKET_ACCESS",
    "OVERLY_PERMISSIVE_IAM",
    "MISSING_MFA_DELETE",
    "MISSING_VERSIONING",
    "MISSING_LOGGING",
    "INSECURE_SECURITY_GROUP",
    "UNRESTRICTED_PORT_22",
    "MISSING_SSL_ENFORCEMENT",
    "MISSING_KMS_ENCRYPTION",
    "LOG_INJECTION",
    "PATH_TRAVERSAL",
    "SQL_INJECTION",
    "REFLECTED_XSS",
}

SYSTEM_PROMPT = """You are a senior AWS security engineer and CloudFormation expert.
Your job is to:
1. Explain clearly WHAT is wrong (the vulnerability or misconfiguration)
2. Explain HOW to fix it (specific steps, best practices, AWS docs references)
3. Provide the corrected code if the file was provided
4. Assess whether this can be automatically patched

You understand:
- AWS CloudFormation templates (YAML and JSON)
- AWS IAM policies and least-privilege principles
- S3 bucket security (encryption, versioning, public access block)
- AWS Transfer Family SFTP security
- AWS GuardDuty, CloudTrail governance requirements
- CWE vulnerability classifications
- OWASP IaC Top 10

Always return ONLY a valid JSON object. No markdown, no prose outside JSON.
"""

async def get_fix_suggestions(
    http:        httpx.AsyncClient,
    finding:     dict,
    source_code: str,
    environment: str,
    api_key:     str
) -> dict:
    """
    Call Claude with a finding + source code.
    Returns dict with what_is_wrong, how_to_fix, fixed_code, auto_fixable, references.
    """
    rule_id   = finding.get("rule_id", "UNKNOWN")
    severity  = finding.get("severity", "medium")
    file_path = finding.get("file_path", "unknown")
    line_num  = finding.get("line", 0)
    message   = finding.get("message", "")

    auto_fixable_hint = rule_id.upper() in AUTO_FIXABLE_RULES

    source_section = ""
    if source_code:
        # Send relevant context (lines around the finding)
        lines = source_code.splitlines()
        start = max(0, line_num - 20)
        end   = min(len(lines), line_num + 20)
        snippet = "\n".join(
            f"{i+1:4d} {'>>>' if i+1==line_num else '   '} {l}"
            for i, l in enumerate(lines[start:end], start=start)
        )
        source_section = f"""

Source file (lines {start+1}-{end}, line {line_num} flagged with >>>):
```yaml
{snippet}
```

Full file for context:
```yaml
{source_code[:8000]}
```"""

    prompt = f"""Checkmarx SAST found a security issue. Analyse and provide a fix.

## Finding Details
- Rule ID:    {rule_id}
- Severity:   {severity}
- File:       {file_path}
- Line:       {line_num}
- Environment: {environment}
- Message:    {message}
{source_section}

## Instructions
Return ONLY this JSON (no markdown fences, no preamble):
{{
  "what_is_wrong": "Clear explanation of the vulnerability — what the risk is and why this code is insecure",
  "how_to_fix": "Step-by-step remediation instructions with specific code examples. Include AWS best practices.",
  "fixed_code": "Complete corrected file content (only if source was provided and fix is clear, else empty string)",
  "auto_fixable": {str(auto_fixable_hint).lower()},
  "severity_explanation": "Why this severity level was assigned",
  "impact": "What could an attacker do with this vulnerability",
  "references": [
    "https://docs.aws.amazon.com/...",
    "https://cwe.mitre.org/data/definitions/..."
  ]
}}"""

    try:
        resp = await http.post(
            ANTHROPIC_API_URL,
            headers={
                "x-api-key":         api_key,
                "anthropic-version": "2023-06-01",
                "content-type":      "application/json"
            },
            json={
                "model":      MODEL,
                "max_tokens": 4096,
                "system":     SYSTEM_PROMPT,
                "messages": [{"role": "user", "content": prompt}]
            }
        )
        resp.raise_for_status()
        data  = resp.json()
        text  = data["content"][0]["text"]

        # Strip any accidental markdown fences
        text = text.strip()
        if text.startswith("```"):
            text = text.split("```")[1]
            if text.startswith("json"):
                text = text[4:]
        if text.endswith("```"):
            text = text.rsplit("```", 1)[0]

        result = json.loads(text.strip())
        log.info(f"Claude suggestion received for {rule_id}: auto_fixable={result.get('auto_fixable')}")
        return result

    except json.JSONDecodeError as e:
        log.error(f"Claude returned non-JSON for {rule_id}: {e}")
        return _fallback_suggestion(rule_id, message, str(e))
    except httpx.HTTPStatusError as e:
        log.error(f"Anthropic API error {e.response.status_code}: {e.response.text}")
        return _fallback_suggestion(rule_id, message, f"API error: {e.response.status_code}")
    except Exception as e:
        log.error(f"Unexpected error calling Claude: {e}")
        return _fallback_suggestion(rule_id, message, str(e))

def _fallback_suggestion(rule_id: str, message: str, error: str) -> dict:
    """Return a safe fallback when Claude call fails."""
    return {
        "what_is_wrong":        f"Checkmarx flagged rule '{rule_id}': {message}",
        "how_to_fix":           (
            f"Claude auto-remediation was unavailable (error: {error}). "
            f"Review the Checkmarx report manually and consult AWS Security Hub "
            f"and the CWE database for remediation guidance."
        ),
        "fixed_code":           "",
        "auto_fixable":         False,
        "severity_explanation": "See Checkmarx report for severity details",
        "impact":               "Review Checkmarx report for impact analysis",
        "references":           [
            "https://docs.aws.amazon.com/securityhub/latest/userguide/",
            "https://cwe.mitre.org/"
        ],
        "error": error
    }
