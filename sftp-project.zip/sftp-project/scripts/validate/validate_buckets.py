#!/usr/bin/env python3
"""
validate_buckets.py
Validates S3 bucket naming conventions, environment tagging,
and checks for placeholder values before deployment.
"""
import argparse
import json
import re
import sys
import os

BUCKET_PATTERN = re.compile(r'^[a-z0-9][a-z0-9\-]{1,61}[a-z0-9]$')
ERRORS = []
WARNINGS = []

def err(msg: str):
    ERRORS.append(msg)
    print(f"  ❌  ERROR:   {msg}")

def warn(msg: str):
    WARNINGS.append(msg)
    print(f"  ⚠️   WARNING: {msg}")

def ok(msg: str):
    print(f"  ✅  OK:      {msg}")

def load_params(path: str) -> dict:
    with open(path) as f:
        raw = json.load(f)
    return {p["ParameterKey"]: p["ParameterValue"] for p in raw}

def validate_bucket(name: str, key: str, environment: str, project: str):
    print(f"\n  Checking {key}: '{name}'")

    if not name or name.startswith("REPLACE"):
        err(f"{key} is a placeholder or empty. Set a real bucket name.")
        return

    if not BUCKET_PATTERN.match(name):
        err(f"{key}='{name}' violates S3 naming rules. "
            f"Use 3-63 lowercase letters/numbers/hyphens, no leading/trailing hyphens.")
    else:
        ok(f"Format valid")

    if environment not in name:
        err(f"{key}='{name}' must contain the environment '{environment}' "
            f"to prevent accidental cross-environment operations.")
    else:
        ok(f"Environment '{environment}' present in name")

    if project and project not in name:
        warn(f"{key}='{name}' does not contain project name '{project}'. "
             f"Recommended: {project}-{environment}-sftp-*")

    if len(name) > 50:
        warn(f"{key}='{name}' is {len(name)} chars. Keep under 50 for readability.")
    else:
        ok(f"Length OK ({len(name)} chars)")

    # Check not globally ambiguous
    if re.match(r'^[a-z0-9]{3,}$', name) and len(name) < 10:
        warn(f"{key}='{name}' is very short and may already exist. Add project/env prefix.")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--params-file",  required=True)
    parser.add_argument("--environment",  required=True)
    parser.add_argument("--project",      default="")
    args = parser.parse_args()

    print(f"\n{'═'*55}")
    print(f"  Bucket Name Validation")
    print(f"  Environment: {args.environment}")
    print(f"{'═'*55}")

    params = load_params(args.params_file)

    sftp_bucket = params.get("SftpBucketName", "")
    logs_bucket = params.get("LogsBucketName", "")

    validate_bucket(sftp_bucket, "SftpBucketName", args.environment, args.project)
    validate_bucket(logs_bucket, "LogsBucketName", args.environment, args.project)

    # Buckets must be different
    if sftp_bucket and logs_bucket:
        print(f"\n  Checking bucket separation:")
        if sftp_bucket == logs_bucket:
            err("SftpBucketName and LogsBucketName must be DIFFERENT buckets. "
                "Storing logs in the same bucket as data violates governance requirements.")
        else:
            ok(f"Data and logs use separate buckets")

        # Naming convention check
        if not sftp_bucket.endswith("-data") and "sftp" not in sftp_bucket:
            warn(f"SftpBucketName should contain 'sftp' or end with '-data'. Got: '{sftp_bucket}'")

        if not any(x in logs_bucket for x in ["log", "audit", "trail"]):
            warn(f"LogsBucketName should contain 'log', 'audit', or 'trail'. Got: '{logs_bucket}'")

    print(f"\n{'═'*55}")
    if ERRORS:
        print(f"  ❌ {len(ERRORS)} error(s), {len(WARNINGS)} warning(s)")
        for e in ERRORS:
            print(f"     ERROR: {e}")
        sys.exit(1)
    elif WARNINGS:
        print(f"  ⚠️  0 errors, {len(WARNINGS)} warning(s) — continuing")
        sys.exit(0)
    else:
        print(f"  ✅ All bucket validations passed")
        sys.exit(0)

if __name__ == "__main__":
    main()
