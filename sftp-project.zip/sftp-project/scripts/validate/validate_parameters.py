#!/usr/bin/env python3
"""
validate_parameters.py
Validates CloudFormation parameter files against:
  - Required parameter presence
  - Environment-specific rules
  - Value format / allowed values
  - Produces JUnit XML for Azure DevOps test reporting
"""
import argparse
import json
import sys
import re
import os
from pathlib import Path
import xml.etree.ElementTree as ET
from datetime import datetime

# ── RULES ─────────────────────────────────────────────────────────────────────
REQUIRED_PARAMS = [
    "Environment", "ProjectName", "SftpBucketName", "LogsBucketName",
    "VpcId", "SubnetIds", "AllowedCidrBlocks", "NotificationEmail",
    "EnableGuardDuty", "EnableCloudTrail"
]

ALLOWED_ENVIRONMENTS = {"dev", "test", "prod"}

PROD_REQUIRED_PARAMS = [
    "SftpHostedZoneId", "SftpCustomHostname"
]

BUCKET_NAME_PATTERN = re.compile(r'^[a-z0-9][a-z0-9\-]{1,61}[a-z0-9]$')
VPC_ID_PATTERN      = re.compile(r'^vpc-[a-f0-9]{8,17}$')
EMAIL_PATTERN       = re.compile(r'^[^\s@]+@[^\s@]+\.[^\s@]+$')
CIDR_PATTERN        = re.compile(
    r'^(\d{1,3}\.){3}\d{1,3}/\d{1,2}$|^REPLACE_')

TEST_RESULTS = []

def record(name: str, passed: bool, msg: str = "", detail: str = ""):
    TEST_RESULTS.append({
        "name": name,
        "passed": passed,
        "message": msg,
        "detail": detail
    })
    icon = "✅" if passed else "❌"
    print(f"  {icon}  {name}: {msg}")
    if not passed and detail:
        print(f"       Detail: {detail}")

def load_params(path: str) -> dict:
    with open(path) as f:
        raw = json.load(f)
    return {p["ParameterKey"]: p["ParameterValue"] for p in raw}

def validate_required(params: dict, environment: str):
    print("\n── Required parameters ──")
    for key in REQUIRED_PARAMS:
        val = params.get(key, "")
        if not val:
            record(f"required/{key}", False, f"Missing or empty", f"Parameter '{key}' must be set")
        else:
            record(f"required/{key}", True, f"Present: '{val[:40]}'")

    if environment == "prod":
        print("\n── Prod-only required parameters ──")
        for key in PROD_REQUIRED_PARAMS:
            val = params.get(key, "")
            if not val:
                record(f"prod_required/{key}", False,
                       f"Missing for prod environment",
                       f"Parameter '{key}' is required in production")
            else:
                record(f"prod_required/{key}", True, f"Present: '{val[:40]}'")

def validate_environment(params: dict, env_arg: str):
    print("\n── Environment validation ──")
    env_param = params.get("Environment", "")

    # Environment param matches CLI argument
    if env_param != env_arg:
        record("environment/match", False,
               f"Mismatch: param='{env_param}' arg='{env_arg}'",
               "The Environment parameter must match the pipeline environment argument")
    else:
        record("environment/match", True, f"Consistent: {env_param}")

    # Allowed value
    if env_param not in ALLOWED_ENVIRONMENTS:
        record("environment/allowed_value", False,
               f"Invalid value '{env_param}'",
               f"Must be one of: {ALLOWED_ENVIRONMENTS}")
    else:
        record("environment/allowed_value", True, f"Valid: {env_param}")

def validate_bucket_names(params: dict, environment: str, project: str = None):
    print("\n── Bucket name validation ──")
    for key in ["SftpBucketName", "LogsBucketName"]:
        val = params.get(key, "")
        if not val:
            continue

        # Pattern check
        if not BUCKET_NAME_PATTERN.match(val):
            record(f"bucket/{key}/format", False,
                   f"Invalid format: '{val}'",
                   "Must be 3-63 chars, lowercase letters/numbers/hyphens, no leading/trailing hyphens")
        else:
            record(f"bucket/{key}/format", True, f"Format OK: '{val}'")

        # Environment in name (prevent cross-env accidents)
        if environment not in val:
            record(f"bucket/{key}/env_tag", False,
                   f"Environment '{environment}' not in bucket name '{val}'",
                   "Bucket names should contain the environment to prevent cross-environment accidents")
        else:
            record(f"bucket/{key}/env_tag", True, f"Environment '{environment}' found in name")

        # SFTP and logs buckets must be different
        sftp_name  = params.get("SftpBucketName", "")
        logs_name  = params.get("LogsBucketName", "")
        if sftp_name and logs_name and sftp_name == logs_name:
            record("bucket/different_buckets", False,
                   "SftpBucketName and LogsBucketName must be different",
                   "Logs must be stored in a separate bucket from SFTP data")
        elif sftp_name and logs_name:
            record("bucket/different_buckets", True, "SFTP data and logs use separate buckets")

def validate_network(params: dict):
    print("\n── Network parameter validation ──")

    # VPC ID
    vpc = params.get("VpcId", "")
    if vpc.startswith("REPLACE"):
        record("network/vpc_id", False,
               f"VpcId is a placeholder: '{vpc}'",
               "Replace REPLACE_WITH_*_VPC_ID with actual VPC ID")
    elif not VPC_ID_PATTERN.match(vpc):
        record("network/vpc_id", False,
               f"Invalid VPC ID format: '{vpc}'",
               "Must match vpc-[hex8-17]")
    else:
        record("network/vpc_id", True, f"Valid VPC ID: '{vpc}'")

    # Subnets
    subnets = params.get("SubnetIds", "")
    if subnets.startswith("REPLACE") or "REPLACE" in subnets:
        record("network/subnet_ids", False,
               "SubnetIds contains placeholder values",
               "Replace subnet-REPLACE_* with actual subnet IDs")
    else:
        subnet_list = [s.strip() for s in subnets.split(",")]
        valid = all(re.match(r'^subnet-[a-f0-9]{8,17}$', s) for s in subnet_list)
        if not valid:
            record("network/subnet_ids", False,
                   f"Invalid subnet ID format in: '{subnets}'",
                   "Must match subnet-[hex8-17]")
        else:
            record("network/subnet_ids", True,
                   f"{len(subnet_list)} subnet(s) specified")

    # CIDR blocks
    cidrs_raw = params.get("AllowedCidrBlocks", "")
    if "REPLACE" in cidrs_raw:
        record("network/cidr_blocks", False,
               "AllowedCidrBlocks contains placeholder",
               "Replace with actual CIDR ranges")
    else:
        cidrs = [c.strip() for c in cidrs_raw.split(",")]
        for cidr in cidrs:
            parts = cidr.split("/")
            if len(parts) == 2:
                prefix = int(parts[1])
                record(f"network/cidr/{cidr}", True, f"Valid CIDR: {cidr}")
            else:
                record(f"network/cidr/{cidr}", False,
                       f"Invalid CIDR: '{cidr}'",
                       "Must be in x.x.x.x/n format")

def validate_email(params: dict):
    print("\n── Email validation ──")
    email = params.get("NotificationEmail", "")
    if not email:
        record("email/notification", False, "NotificationEmail is empty")
    elif not EMAIL_PATTERN.match(email):
        record("email/notification", False,
               f"Invalid email format: '{email}'")
    else:
        record("email/notification", True, f"Valid email: '{email}'")

def validate_booleans(params: dict):
    print("\n── Boolean flags ──")
    for key in ["EnableGuardDuty", "EnableCloudTrail"]:
        val = params.get(key, "")
        if val.lower() not in ("true", "false"):
            record(f"boolean/{key}", False,
                   f"Invalid value '{val}'",
                   "Must be 'true' or 'false'")
        else:
            record(f"boolean/{key}", True, f"{key}={val}")

def write_junit_xml(output_path: str):
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    total    = len(TEST_RESULTS)
    failures = sum(1 for t in TEST_RESULTS if not t["passed"])

    suite = ET.Element("testsuite",
        name="CloudFormation Parameter Validation",
        tests=str(total),
        failures=str(failures),
        timestamp=datetime.utcnow().isoformat()
    )

    for t in TEST_RESULTS:
        case = ET.SubElement(suite, "testcase",
            name=t["name"],
            classname="parameter_validation"
        )
        if not t["passed"]:
            fail = ET.SubElement(case, "failure",
                message=t["message"],
                type="ValidationError"
            )
            fail.text = t.get("detail", "")

    tree = ET.ElementTree(suite)
    tree.write(output_path, encoding="utf-8", xml_declaration=True)
    print(f"\n📄 JUnit XML written to: {output_path}")

# ── MAIN ───────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--params-file",   required=True)
    parser.add_argument("--template-file", required=True)
    parser.add_argument("--environment",   required=True)
    parser.add_argument("--project",       default="")
    args = parser.parse_args()

    print(f"\n{'═'*55}")
    print(f"  Parameter Validation: {args.params_file}")
    print(f"  Environment: {args.environment}")
    print(f"{'═'*55}")

    params = load_params(args.params_file)

    validate_required(params, args.environment)
    validate_environment(params, args.environment)
    validate_bucket_names(params, args.environment, args.project)
    validate_network(params)
    validate_email(params)
    validate_booleans(params)

    os.makedirs("reports", exist_ok=True)
    write_junit_xml("reports/test-results.xml")

    failures = sum(1 for t in TEST_RESULTS if not t["passed"])
    total    = len(TEST_RESULTS)

    print(f"\n{'═'*55}")
    print(f"  Results: {total - failures}/{total} passed")
    if failures:
        print(f"  ❌ {failures} validation error(s) found")
        print(f"{'═'*55}\n")
        sys.exit(1)
    else:
        print(f"  ✅ All validations passed")
        print(f"{'═'*55}\n")
        sys.exit(0)

if __name__ == "__main__":
    main()
