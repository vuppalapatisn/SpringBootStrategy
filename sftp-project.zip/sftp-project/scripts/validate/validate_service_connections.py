#!/usr/bin/env python3
"""
validate_service_connections.py
Validates Azure DevOps AWS service connection and region settings
before attempting any CloudFormation deployment.
"""
import argparse
import subprocess
import sys
import json
import os

ERRORS   = []
WARNINGS = []

VALID_REGIONS = {
    "us-east-1", "us-east-2", "us-west-1", "us-west-2",
    "eu-west-1", "eu-west-2", "eu-west-3", "eu-central-1",
    "ap-southeast-1", "ap-southeast-2", "ap-northeast-1",
    "ca-central-1", "sa-east-1"
}

def err(msg: str):
    ERRORS.append(msg)
    print(f"  ❌  ERROR:   {msg}")

def warn(msg: str):
    WARNINGS.append(msg)
    print(f"  ⚠️   WARNING: {msg}")

def ok(msg: str):
    print(f"  ✅  OK:      {msg}")

def validate_region(region: str):
    print(f"\n── AWS Region ──")
    if not region:
        err("AWS_REGION is not set in the pipeline variable group")
        return

    if region not in VALID_REGIONS:
        warn(f"Region '{region}' is not in the known valid regions list. "
             f"If this is intentional, verify it supports Transfer Family.")
    else:
        ok(f"Region '{region}' is valid")

    # Transfer Family availability
    transfer_unavailable = {"us-gov-east-1", "cn-north-1", "cn-northwest-1"}
    if region in transfer_unavailable:
        err(f"AWS Transfer Family is NOT available in region '{region}'")

def validate_service_connection(conn_name: str, environment: str):
    print(f"\n── Service connection: '{conn_name}' ──")
    if not conn_name:
        err(f"AWS_SERVICE_CONNECTION variable is empty for environment '{environment}'. "
            f"Set it in the pipeline variable group 'sftp-pipeline-{environment}'.")
        return

    # Naming convention check
    if environment not in conn_name.lower() and not any(
            x in conn_name.lower() for x in ["aws", "amazon", "cloud"]
        ):
        warn(f"Service connection name '{conn_name}' doesn't include '{environment}' "
             f"or 'aws'. Recommended: aws-{environment} or aws-sftp-{environment}")
    else:
        ok(f"Service connection name '{conn_name}' looks valid")

    # Check it's not using a shared prod connection in non-prod
    if environment != "prod" and "prod" in conn_name.lower():
        err(f"CRITICAL: Service connection '{conn_name}' appears to be a production "
            f"connection but is being used in '{environment}' environment. "
            f"Use environment-specific service connections to prevent cross-environment risk.")
    else:
        ok(f"Service connection '{conn_name}' is not a cross-environment risk")

def validate_checkmarx_connection(cx_conn: str):
    print(f"\n── Checkmarx service connection ──")
    if not cx_conn:
        warn("CHECKMARX_SERVICE_CONNECTION is not set. "
             "Checkmarx scan will fail if CxScanner task is present. "
             "Set this in the 'sftp-pipeline-common' variable group.")
    else:
        ok(f"Checkmarx connection '{cx_conn}' is set")

def validate_claude_agent(agent_url: str):
    print(f"\n── Claude MCP agent ──")
    if not agent_url:
        warn("CLAUDE_AGENT_URL is not set. "
             "Auto-remediation on Checkmarx failures will be skipped. "
             "Set CLAUDE_AGENT_URL in the variable group to enable.")
    else:
        if not agent_url.startswith("https://"):
            err(f"CLAUDE_AGENT_URL='{agent_url}' must use HTTPS")
        else:
            ok(f"Claude agent URL is set and uses HTTPS")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--environment",         required=True)
    parser.add_argument("--aws-region",          required=True)
    parser.add_argument("--service-connection",  required=True)
    parser.add_argument("--cx-connection",       default=os.environ.get("CHECKMARX_SERVICE_CONNECTION", ""))
    parser.add_argument("--claude-agent-url",    default=os.environ.get("CLAUDE_AGENT_URL", ""))
    args = parser.parse_args()

    print(f"\n{'═'*55}")
    print(f"  Service Connection Validation")
    print(f"  Environment: {args.environment}")
    print(f"{'═'*55}")

    validate_region(args.aws_region)
    validate_service_connection(args.service_connection, args.environment)
    validate_checkmarx_connection(args.cx_connection)
    validate_claude_agent(args.claude_agent_url)

    # Prod extra checks
    if args.environment == "prod":
        print(f"\n── Production-specific checks ──")
        if "dev" in args.service_connection.lower() or "test" in args.service_connection.lower():
            err(f"CRITICAL: Service connection '{args.service_connection}' looks like "
                f"a non-prod connection being used for prod deployment. Abort.")
        else:
            ok("Service connection name does not suggest a non-prod account")

    print(f"\n{'═'*55}")
    if ERRORS:
        print(f"  ❌ {len(ERRORS)} error(s) found — deployment blocked")
        for e in ERRORS:
            print(f"     {e}")
        print(f"{'═'*55}\n")
        sys.exit(1)
    elif WARNINGS:
        print(f"  ⚠️  0 errors, {len(WARNINGS)} warnings — continuing with caution")
        sys.exit(0)
    else:
        print(f"  ✅ All service connection validations passed")
        sys.exit(0)

if __name__ == "__main__":
    main()
