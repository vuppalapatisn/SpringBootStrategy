#!/usr/bin/env python3
"""describe_changeset.py — waits for change set and prints a readable summary."""
import argparse, boto3, json, os, sys, time
from datetime import datetime

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--stack-name")
    p.add_argument("--changeset-name")
    p.add_argument("--region")
    p.add_argument("--output-file", default="reports/changeset.json")
    args = p.parse_args()

    cfn = boto3.client("cloudformation", region_name=args.region)
    os.makedirs("reports", exist_ok=True)

    # Wait for change set to be ready
    for _ in range(30):
        cs = cfn.describe_change_set(
            StackName=args.stack_name,
            ChangeSetName=args.changeset_name
        )
        status = cs["Status"]
        if status in ("CREATE_COMPLETE", "FAILED"):
            break
        print(f"  Change set status: {status} — waiting...")
        time.sleep(10)

    changes = cs.get("Changes", [])
    print(f"\n  Change set '{args.changeset_name}'")
    print(f"  Status:  {cs['Status']}")
    print(f"  Changes: {len(changes)}")
    for c in changes:
        rc = c.get("ResourceChange", {})
        print(f"    {rc.get('Action','?'):10s}  {rc.get('ResourceType','?'):40s}  {rc.get('LogicalResourceId','?')}")

    with open(args.output_file, "w") as f:
        json.dump({
            "stack_name":     args.stack_name,
            "changeset_name": args.changeset_name,
            "status":         cs["Status"],
            "timestamp":      datetime.utcnow().isoformat(),
            "changes":        changes
        }, f, indent=2, default=str)
    print(f"\n  📄 Saved: {args.output_file}")

    if cs["Status"] == "FAILED":
        print(f"  ❌  Change set FAILED: {cs.get('StatusReason','')}")
        sys.exit(1)

if __name__ == "__main__":
    main()
