#!/usr/bin/env python3
"""
post_deploy_verify.py
Verifies the CloudFormation stack deployed correctly by checking:
  - Stack status
  - SFTP server is online
  - S3 buckets exist and are accessible
  - Outputs are present
"""
import argparse
import boto3
import json
import sys
import os
from datetime import datetime

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stack-name",   required=True)
    parser.add_argument("--environment",  required=True)
    parser.add_argument("--region",       required=True)
    parser.add_argument("--output-file",  default="reports/post-deploy.json")
    args = parser.parse_args()

    os.makedirs("reports", exist_ok=True)
    errors  = []
    results = {}

    cfn    = boto3.client("cloudformation", region_name=args.region)
    s3     = boto3.client("s3",             region_name=args.region)
    xfer   = boto3.client("transfer",       region_name=args.region)

    print(f"\n{'═'*55}")
    print(f"  Post-Deploy Verification: {args.stack_name}")
    print(f"{'═'*55}")

    # ── Stack status ──────────────────────────────────────────────────────────
    try:
        stack = cfn.describe_stacks(StackName=args.stack_name)["Stacks"][0]
        status = stack["StackStatus"]
        if status in ("CREATE_COMPLETE", "UPDATE_COMPLETE"):
            print(f"  ✅  Stack status: {status}")
            results["stack_status"] = status
        else:
            msg = f"Stack status is '{status}' — expected *_COMPLETE"
            print(f"  ❌  {msg}")
            errors.append(msg)
            results["stack_status"] = status
        outputs = {o["OutputKey"]: o["OutputValue"] for o in stack.get("Outputs", [])}
        results["outputs"] = outputs
    except Exception as e:
        errors.append(f"Cannot describe stack: {e}")
        print(f"  ❌  Cannot describe stack: {e}")
        outputs = {}

    # ── SFTP Server ───────────────────────────────────────────────────────────
    server_id = outputs.get("SftpServerId", "")
    if server_id:
        try:
            srv = xfer.describe_server(ServerId=server_id)["Server"]
            state = srv["State"]
            if state == "ONLINE":
                print(f"  ✅  SFTP server {server_id}: {state}")
            else:
                msg = f"SFTP server {server_id} state is '{state}', expected ONLINE"
                print(f"  ⚠️   {msg}")
                errors.append(msg)
            results["sftp_server_state"] = state
        except Exception as e:
            errors.append(f"Cannot check SFTP server: {e}")
            print(f"  ❌  SFTP server check failed: {e}")
    else:
        print("  ⚠️   SftpServerId not in stack outputs — skipping server check")

    # ── S3 Buckets ────────────────────────────────────────────────────────────
    for out_key in ["SftpDataBucketName", "LogsBucketName"]:
        bucket = outputs.get(out_key, "")
        if bucket:
            try:
                s3.head_bucket(Bucket=bucket)
                print(f"  ✅  Bucket '{bucket}' exists and is accessible")
                results[f"bucket_{out_key}"] = "accessible"
            except Exception as e:
                msg = f"Bucket '{bucket}' not accessible: {e}"
                print(f"  ❌  {msg}")
                errors.append(msg)
                results[f"bucket_{out_key}"] = "error"

    # ── Summary ───────────────────────────────────────────────────────────────
    report = {
        "stack_name":  args.stack_name,
        "environment": args.environment,
        "timestamp":   datetime.utcnow().isoformat(),
        "errors":      errors,
        "results":     results
    }
    with open(args.output_file, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\n  📄 Report: {args.output_file}")

    print(f"\n{'═'*55}")
    if errors:
        print(f"  ❌ {len(errors)} post-deploy check(s) failed")
        sys.exit(1)
    else:
        print(f"  ✅ All post-deploy checks passed")
        sys.exit(0)

if __name__ == "__main__":
    main()
