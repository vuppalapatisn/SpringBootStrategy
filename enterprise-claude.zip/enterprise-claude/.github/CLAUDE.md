# CI/CD (.github/workflows)

## Pipeline rules
- Every PR must pass: `lint` → `test` → `build` → `security-scan` before merge.
- Never `continue-on-error: true` on security scan or test jobs.
- Cache: Maven deps via `actions/cache` keyed on `pom.xml` hash.
- Use pinned action versions with SHA, not floating tags: `actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683`.

## Secrets
- Secrets injected via GitHub Actions secrets — never in workflow YAML.
- Use OIDC for AWS auth (`aws-actions/configure-aws-credentials`) — never long-lived keys in CI.

## Job structure
```
jobs:
  lint       → checkstyle + spotbugs
  test       → unit tests (fast, no Docker)
  build      → mvn package, publish artifact
  scan       → Checkmarx / Trivy image scan
  deploy-dev → auto on develop merge
  deploy-test→ auto on release/* merge
  deploy-prod→ manual trigger only, requires approval
```

## Notifications
- Slack `#payments-deployments` on any prod deployment.
- Slack `#payments-alerts` on any pipeline failure on main/develop.
