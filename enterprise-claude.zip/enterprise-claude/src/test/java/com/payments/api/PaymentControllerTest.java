package com.payments.api.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payments.api.dto.request.CreatePaymentRequest;
import com.payments.domain.model.*;
import com.payments.domain.service.PaymentService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Controller unit tests — @WebMvcTest only, no full Spring context.
 * Four standard test cases per endpoint: happy path, validation failure,
 * auth failure, 404 / not-found.
 */
@WebMvcTest(PaymentController.class)
@DisplayName("PaymentController")
class PaymentControllerTest {

    @Autowired MockMvc       mockMvc;
    @Autowired ObjectMapper  objectMapper;
    @MockBean  PaymentService paymentService;

    // ── POST /api/v1/payments ─────────────────────────────────────────────────
    @Nested
    @DisplayName("POST /api/v1/payments — create payment")
    class CreatePayment {

        @Test
        @WithMockUser(roles = "PAYMENT_OPERATOR")
        @DisplayName("should return 201 with payment ID when request is valid")
        void happyPath() throws Exception {
            var request = validCreateRequest();
            var payment = stubPayment();

            given(paymentService.createPayment(any())).willReturn(payment);

            mockMvc.perform(post("/api/v1/payments")
                            .with(csrf())
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(request)))
                    .andExpect(status().isCreated())
                    .andExpect(header().exists("X-Payment-Id"))
                    .andExpect(jsonPath("$.data.id").isNotEmpty())
                    .andExpect(jsonPath("$.data.status").value("PENDING"));
        }

        @Test
        @WithMockUser(roles = "PAYMENT_OPERATOR")
        @DisplayName("should return 422 when amount is negative")
        void validationFailure_negativeAmount() throws Exception {
            var request = validCreateRequest();
            request.setAmount(new BigDecimal("-1.00"));

            mockMvc.perform(post("/api/v1/payments")
                            .with(csrf())
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(request)))
                    .andExpect(status().isUnprocessableEntity())
                    .andExpect(jsonPath("$.errors[0].field").value("amount"))
                    .andExpect(jsonPath("$.errors[0].message").isNotEmpty());
        }

        @Test
        @DisplayName("should return 401 when no authentication provided")
        void unauthenticated() throws Exception {
            mockMvc.perform(post("/api/v1/payments")
                            .with(csrf())
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{}"))
                    .andExpect(status().isUnauthorized());
        }

        @Test
        @WithMockUser(roles = "PAYMENT_VIEWER")   // wrong role
        @DisplayName("should return 403 when user lacks PAYMENT_OPERATOR role")
        void insufficientRole() throws Exception {
            var request = validCreateRequest();

            mockMvc.perform(post("/api/v1/payments")
                            .with(csrf())
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(request)))
                    .andExpect(status().isForbidden());
        }
    }

    // ── Fixtures ──────────────────────────────────────────────────────────────

    private CreatePaymentRequest validCreateRequest() {
        var req = new CreatePaymentRequest();
        req.setMerchantId(UUID.randomUUID().toString());
        req.setAmount(new BigDecimal("99.99"));
        req.setCurrency("GBP");
        // Note: masked card number for tests — not a real PAN
        req.setMaskedCard("****-****-****-4242");
        return req;
    }

    private Payment stubPayment() {
        return Payment.create(
                new PaymentId(UUID.randomUUID()),
                new MerchantId(UUID.randomUUID()),
                Money.of(new BigDecimal("99.99"), "GBP"),
                MaskedCardNumber.of("****-****-****-4242")
        );
    }
}
