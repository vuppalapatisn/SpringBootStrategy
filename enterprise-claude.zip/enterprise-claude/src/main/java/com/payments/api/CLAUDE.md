# API Layer

Spring MVC controllers + request/response DTOs + validation.

## Controllers
- Annotate with `@RestController` + `@RequestMapping("/api/v1/...")`.
- Return `ResponseEntity<ApiResponse<T>>` — never raw domain objects.
- All controller methods must declare `@Operation` (OpenAPI/Swagger).
- HTTP verbs: GET=read, POST=create, PUT=replace, PATCH=partial, DELETE=remove.

## Validation
- Use `@Valid` on every `@RequestBody`. Constraints go on the DTO, not the service.
- Custom validators in `validators/` — implement `ConstraintValidator<A, T>`.
- Card numbers: validate with Luhn before passing to domain.

## Error handling
- `GlobalExceptionHandler` handles everything — controllers never catch and swallow.
- Business errors → `ApiException(ErrorCode, HttpStatus)`.
- Validation errors → 422 Unprocessable Entity with field-level messages.

## Security
- All endpoints need `@PreAuthorize` unless explicitly public (document why).
- Rate limit headers must be set on every response: `X-RateLimit-Remaining`.

## Tests
- Unit test every controller method with `@WebMvcTest`.
- Use `MockMvc` — never start the full context for controller tests.
- Test: happy path, validation failure, auth failure, 404 — minimum four cases per endpoint.
