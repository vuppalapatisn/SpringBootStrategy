package com.payments.api.controllers;

import com.payments.api.dto.request.CreatePaymentRequest;
import com.payments.api.dto.request.RefundPaymentRequest;
import com.payments.api.dto.response.ApiResponse;
import com.payments.api.dto.response.PaymentResponse;
import com.payments.domain.service.PaymentService;
import com.payments.domain.model.PaymentId;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@Slf4j
@RestController
@RequestMapping("/api/v1/payments")
@RequiredArgsConstructor
@Tag(name = "Payments", description = "Payment processing operations")
@SecurityRequirement(name = "bearerAuth")
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping
    @PreAuthorize("hasRole('PAYMENT_OPERATOR')")
    @Operation(summary = "Create a new payment", description = "Initiates payment authorisation")
    public ResponseEntity<ApiResponse<PaymentResponse>> createPayment(
            @Valid @RequestBody CreatePaymentRequest request) {

        // Log entry — NEVER log card number, CVV, or full PAN
        log.info("Creating payment: merchantId={} amount={} currency={}",
                request.getMerchantId(), request.getAmount(), request.getCurrency());

        var payment  = paymentService.createPayment(request.toDomainCommand());
        var response = PaymentResponse.from(payment);

        log.info("Payment created: paymentId={} status={}", payment.getId(), payment.getStatus());
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .header("X-Payment-Id", payment.getId().toString())
                .body(ApiResponse.success(response));
    }

    @GetMapping("/{paymentId}")
    @PreAuthorize("hasAnyRole('PAYMENT_OPERATOR', 'PAYMENT_VIEWER')")
    @Operation(summary = "Get payment by ID")
    public ResponseEntity<ApiResponse<PaymentResponse>> getPayment(
            @PathVariable UUID paymentId) {

        log.debug("Fetching payment: paymentId={}", paymentId);
        var payment = paymentService.findById(new PaymentId(paymentId));
        return ResponseEntity.ok(ApiResponse.success(PaymentResponse.from(payment)));
    }

    @PostMapping("/{paymentId}/refund")
    @PreAuthorize("hasRole('PAYMENT_REFUND_OPERATOR')")
    @Operation(summary = "Refund a payment")
    public ResponseEntity<ApiResponse<PaymentResponse>> refundPayment(
            @PathVariable UUID paymentId,
            @Valid @RequestBody RefundPaymentRequest request) {

        log.info("Initiating refund: paymentId={} amount={}", paymentId, request.getAmount());
        var payment = paymentService.refund(new PaymentId(paymentId), request.toDomainCommand());
        return ResponseEntity.ok(ApiResponse.success(PaymentResponse.from(payment)));
    }
}
