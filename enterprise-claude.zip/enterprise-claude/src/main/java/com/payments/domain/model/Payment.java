package com.payments.domain.model;

import com.payments.domain.event.PaymentAuthorized;
import com.payments.domain.event.PaymentRefunded;
import com.payments.domain.exception.DomainException;
import com.payments.domain.exception.ErrorCode;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Currency;
import java.util.List;

/**
 * Payment aggregate root.
 *
 * Pure domain class — no JPA, no Spring, no framework dependencies.
 * All state transitions go through explicit methods; direct field mutation
 * is prohibited outside this class.
 */
@Getter
public class Payment {

    private final PaymentId            id;
    private final MerchantId           merchantId;
    private final Money                amount;
    private final MaskedCardNumber     maskedCard;   // ****-****-****-1234 only
    private       PaymentStatus        status;
    private       String               failureReason;
    private final Instant              createdAt;
    private       Instant              updatedAt;

    // Domain events raised during this session — not persisted
    private final List<Object>         domainEvents = new ArrayList<>();

    // ── Factory method (use instead of constructor) ───────────────────────────
    public static Payment create(
            PaymentId       id,
            MerchantId      merchantId,
            Money           amount,
            MaskedCardNumber maskedCard) {

        var payment = new Payment(id, merchantId, amount, maskedCard);
        payment.domainEvents.add(new PaymentAuthorized(id, amount, Instant.now()));
        return payment;
    }

    private Payment(PaymentId id, MerchantId merchantId, Money amount, MaskedCardNumber maskedCard) {
        // Invariant checks — throw DomainException, not IllegalArgumentException
        if (amount.isNegativeOrZero()) {
            throw new DomainException(ErrorCode.INVALID_AMOUNT,
                    "Payment amount must be positive, got: " + amount);
        }
        this.id         = id;
        this.merchantId = merchantId;
        this.amount     = amount;
        this.maskedCard = maskedCard;
        this.status     = PaymentStatus.PENDING;
        this.createdAt  = Instant.now();
        this.updatedAt  = createdAt;
    }

    // ── State transitions ─────────────────────────────────────────────────────

    public void authorize() {
        requireStatus(PaymentStatus.PENDING, "authorize");
        this.status    = PaymentStatus.AUTHORIZED;
        this.updatedAt = Instant.now();
    }

    public void capture() {
        requireStatus(PaymentStatus.AUTHORIZED, "capture");
        this.status    = PaymentStatus.CAPTURED;
        this.updatedAt = Instant.now();
    }

    public void refund(Money refundAmount) {
        requireStatus(PaymentStatus.CAPTURED, "refund");
        if (refundAmount.isGreaterThan(this.amount)) {
            throw new DomainException(ErrorCode.REFUND_EXCEEDS_ORIGINAL,
                    "Refund amount " + refundAmount + " exceeds captured amount " + this.amount);
        }
        this.status    = PaymentStatus.REFUNDED;
        this.updatedAt = Instant.now();
        this.domainEvents.add(new PaymentRefunded(id, refundAmount, Instant.now()));
    }

    public void fail(String reason) {
        if (this.status == PaymentStatus.CAPTURED) {
            throw new DomainException(ErrorCode.INVALID_STATE_TRANSITION,
                    "Cannot fail a captured payment. Initiate refund instead.");
        }
        this.status        = PaymentStatus.FAILED;
        this.failureReason = reason;
        this.updatedAt     = Instant.now();
    }

    // ── Domain events ─────────────────────────────────────────────────────────

    public List<Object> pullDomainEvents() {
        var events = Collections.unmodifiableList(new ArrayList<>(domainEvents));
        domainEvents.clear();
        return events;
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private void requireStatus(PaymentStatus required, String operation) {
        if (this.status != required) {
            throw new DomainException(ErrorCode.INVALID_STATE_TRANSITION,
                    String.format("Cannot %s payment in status %s (requires %s)",
                            operation, this.status, required));
        }
    }

    @Override
    public String toString() {
        // Safe toString — no card data, no sensitive fields
        return String.format("Payment{id=%s, merchant=%s, amount=%s, status=%s}",
                id, merchantId, amount, status);
    }
}
