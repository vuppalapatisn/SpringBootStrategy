# Domain Layer

Pure business logic — no Spring annotations, no framework dependencies.
Hexagonal core: domain knows nothing about HTTP, DB, or messaging.

## Model rules
- Entities: `@AggregateRoot` marker, ID is a typed value object (e.g. `PaymentId(UUID)`).
- Value objects: immutable records, validated in constructor, throw `DomainException` on violation.
- No JPA annotations on domain classes — that belongs in `infrastructure/persistence`.
- Money: always `BigDecimal` with explicit scale(2). Never `double` or `float`.

## Service rules
- One service class per aggregate. Name: `{Aggregate}Service`.
- Services take ports (interfaces), never concrete adapters — injected via constructor.
- All public service methods must be transactional — annotate at the use-case level.
- Side effects (events, emails, audit) via domain events, not direct calls.

## Domain events
- Extend `DomainEvent`. Fire via `ApplicationEventPublisher` — never call listeners directly.
- Event names past tense: `PaymentAuthorized`, `RefundIssued`, `FraudDetected`.

## Tests
- Pure unit tests — no Spring context, no Mockito for domain objects (use real instances).
- Use `@DisplayName` with business language: "should reject payment when card is expired".
- Test invariants directly on value objects and entities.
