# Infrastructure Layer

Adapters that connect the domain to the outside world.
Implements domain port interfaces — never imported by domain classes.

## Persistence (JPA)
- Entity classes suffixed `JpaEntity` — maps to DB, separate from domain model.
- Repositories extend `JpaRepository<XxxJpaEntity, UUID>`.
- Mapper class `XxxMapper` converts domain ↔ JPA entity. No logic in mapper.
- N+1 query prevention: use `@EntityGraph` or `JOIN FETCH` — check with `spring.jpa.show-sql=true` in tests.
- Flyway migrations only — never `spring.jpa.hibernate.ddl-auto=create` in any environment.

## Security
- JWT: RS256 algorithm, 15-min access token, 7-day refresh in `HttpOnly; Secure; SameSite=Strict` cookie.
- CORS: explicit allowlist — never `allowedOrigins("*")` in prod config.
- Secrets via `@Value("${...}")` backed by AWS Secrets Manager (Spring Cloud AWS).

## Messaging (Kafka)
- Producers: `PaymentEventProducer` — fire and forget with dead-letter on failure.
- Consumers: `@KafkaListener` — idempotent processing, store event ID to deduplicate.
- Topic naming: `payments.{aggregate}.{event}` e.g. `payments.payment.authorized`.

## Config
- Environment-specific config in `application-{env}.yml` — never hardcode env-specific values.
- Feature flags via Spring `@ConditionalOnProperty`.

## Tests
- Use `@DataJpaTest` for persistence tests — real H2 / Testcontainers Postgres.
- Use `EmbeddedKafka` for messaging tests.
- Integration tests in `src/test/java/.../integration/` — tagged `@Tag("integration")`.
