#!/usr/bin/env python3
"""
.claude/hooks/pre_bash_guard.py
PreToolUse hook — fires before every Bash tool call.

Exit codes:
  0  → allow the command to run
  2  → BLOCK the command; message on stdout is shown to Claude as the reason

Receives JSON on stdin:
  {
    "tool_name": "Bash",
    "tool_input": { "command": "...", "description": "..." }
  }

Claude sees stdout as context when exit code is 2.
"""
import json
import sys
import re
import os
from pathlib import Path
from datetime import datetime

payload   = json.load(sys.stdin)
command   = payload.get("tool_input", {}).get("command", "")
clean_cmd = " ".join(command.split())   # normalise whitespace

# ── AUDIT LOG ─────────────────────────────────────────────────────────────────
log_dir = Path(".claude/audit")
log_dir.mkdir(parents=True, exist_ok=True)
with open(log_dir / "bash_commands.log", "a") as f:
    f.write(json.dumps({
        "ts":      datetime.utcnow().isoformat(),
        "command": clean_cmd[:500],
        "action":  "pre_check"
    }) + "\n")

# ── BLOCK RULES ───────────────────────────────────────────────────────────────
BLOCKED_PATTERNS = [
    # Destructive filesystem operations
    (r'\brm\s+-rf\s+/', "Blocked: 'rm -rf /' would delete the root filesystem."),
    (r'\brm\s+-rf\s+~',  "Blocked: 'rm -rf ~' would delete the home directory."),
    (r'\bdd\b.*of=/dev/(sd|nvme|xvd)', "Blocked: direct disk write via dd."),

    # Credential exfiltration
    (r'curl\s+.*\|\s*(bash|sh)',  "Blocked: curl-pipe-to-shell pattern is a supply chain risk."),
    (r'wget\s+.*\|\s*(bash|sh)',  "Blocked: wget-pipe-to-shell pattern is a supply chain risk."),
    (r'aws\s+secretsmanager\s+.*get-secret-value.*>\s*\S+',
     "Blocked: redirecting AWS secrets to a file. Use env vars instead."),

    # Production environment guard
    (r'aws\s+.*--profile\s+prod\b',
     "Blocked: direct AWS CLI calls using the prod profile are not allowed from Claude. "
     "Deploy via the CI/CD pipeline."),
    (r'kubectl\s+.*--context\s+(prod|production)',
     "Blocked: kubectl commands against the production context must go through the deployment pipeline."),

    # Database guard
    (r'psql\s+.*prod',
     "Blocked: direct psql connections to production databases are not permitted."),
    (r'DROP\s+DATABASE\s+payments',
     "Blocked: DROP DATABASE on the payments database requires a manual DBA process."),

    # Git force-push guard
    (r'git\s+push\s+(--force|-f)\s+.*main',
     "Blocked: force-pushing to main is prohibited."),
    (r'git\s+push\s+(--force|-f)\s+.*release',
     "Blocked: force-pushing to release branches is prohibited."),
]

for pattern, reason in BLOCKED_PATTERNS:
    if re.search(pattern, clean_cmd, re.IGNORECASE):
        print(f"[pre_bash_guard] BLOCKED\n{reason}\nCommand attempted: {clean_cmd[:200]}")
        # Log the block
        with open(log_dir / "bash_commands.log", "a") as f:
            f.write(json.dumps({
                "ts":      datetime.utcnow().isoformat(),
                "command": clean_cmd[:500],
                "action":  "BLOCKED",
                "reason":  reason
            }) + "\n")
        sys.exit(2)

# ── WARN RULES (allow but inject context into Claude) ─────────────────────────
WARN_PATTERNS = [
    (r'\bmvn\s+clean\s+install\b',
     "Note: 'mvn clean install' will take ~3 minutes. Consider 'mvn test' if you only need test results."),
    (r'\bdocker\s+system\s+prune',
     "Note: docker system prune will remove all unused images, containers, and volumes."),
    (r'\bgit\s+reset\s+--hard',
     "Note: git reset --hard discards uncommitted changes permanently."),
]

warnings = []
for pattern, note in WARN_PATTERNS:
    if re.search(pattern, clean_cmd, re.IGNORECASE):
        warnings.append(note)

if warnings:
    # Exit 0 = allow, but stdout is fed to Claude as context
    for w in warnings:
        print(f"[pre_bash_guard] WARNING: {w}")

sys.exit(0)
