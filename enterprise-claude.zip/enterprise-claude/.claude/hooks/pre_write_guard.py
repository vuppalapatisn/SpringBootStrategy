#!/usr/bin/env python3
"""
.claude/hooks/pre_write_guard.py
PreToolUse hook — fires before Write and Edit tool calls.

Scans the content Claude is about to write for:
  - Hardcoded secrets / credentials
  - Real PII (card numbers, SSNs, email addresses in non-test files)
  - Writing to protected paths

Receives JSON on stdin:
  {
    "tool_name": "Write",
    "tool_input": { "path": "...", "content": "..." }
  }
  or for Edit:
  {
    "tool_name": "Edit",
    "tool_input": { "path": "...", "old_string": "...", "new_string": "..." }
  }
"""
import json
import sys
import re
from pathlib import Path
from datetime import datetime

payload    = json.load(sys.stdin)
tool_name  = payload.get("tool_name", "Write")
tool_input = payload.get("tool_input", {})

file_path  = tool_input.get("path", "")
# For Write: full content. For Edit: just check the new_string being inserted.
content    = tool_input.get("content", tool_input.get("new_string", ""))

is_test_file = any(x in file_path for x in [
    "test/", "Test.java", "Spec.java", "mock", "fixture", "fake", "__tests__"
])

BLOCKED = []

# ── PROTECTED PATHS ────────────────────────────────────────────────────────────
PROTECTED_PATHS = [
    ".github/workflows/deploy-prod.yml",
    "infra/parameters/prod.json",
    ".env.prod",
    "src/main/resources/application-prod.yml",
]
if any(file_path.endswith(p) or file_path == p for p in PROTECTED_PATHS):
    BLOCKED.append(
        f"Protected file: '{file_path}' is a production configuration file. "
        f"Changes must go through a reviewed PR — not direct file writes."
    )

# ── SECRET PATTERNS ────────────────────────────────────────────────────────────
SECRET_PATTERNS = [
    (r'(?i)(password|passwd|secret|api[_-]?key|access[_-]?key|private[_-]?key)\s*[=:]\s*["\']?[A-Za-z0-9+/]{16,}',
     "Hardcoded credential detected. Use AWS Secrets Manager or an env var reference instead."),
    (r'sk-[a-zA-Z0-9]{32,}',
     "Anthropic API key pattern detected. Never hardcode API keys."),
    (r'AKIA[0-9A-Z]{16}',
     "AWS Access Key ID pattern detected. Use IAM roles / OIDC — never hardcode access keys."),
    (r'(?i)jdbc:[a-z]+://[^/]+/[^\s"\']+password=[^\s"\']+',
     "JDBC connection string with inline password. Use Spring datasource properties with secrets."),
    (r'(?i)-----BEGIN (RSA |EC )?PRIVATE KEY-----',
     "Private key material in source code. Store in AWS Secrets Manager."),
]

for pattern, reason in SECRET_PATTERNS:
    if re.search(pattern, content):
        BLOCKED.append(reason)

# ── PII PATTERNS (skip in test files) ──────────────────────────────────────────
if not is_test_file:
    PII_PATTERNS = [
        (r'\b4[0-9]{15}\b|\b5[1-5][0-9]{14}\b|\b3[47][0-9]{13}\b',
         "Real-looking card number in non-test code. Use masked placeholder ****-****-****-1234."),
        (r'\b\d{3}-\d{2}-\d{4}\b',
         "SSN pattern detected in non-test code. Never store/log SSNs in application code."),
    ]
    for pattern, reason in PII_PATTERNS:
        if re.search(pattern, content):
            BLOCKED.append(reason)

# ── EMIT ───────────────────────────────────────────────────────────────────────
log_dir = Path(".claude/audit")
log_dir.mkdir(parents=True, exist_ok=True)

if BLOCKED:
    entry = {
        "ts":       datetime.utcnow().isoformat(),
        "tool":     tool_name,
        "path":     file_path,
        "action":   "BLOCKED",
        "reasons":  BLOCKED
    }
    with open(log_dir / "write_guard.log", "a") as f:
        f.write(json.dumps(entry) + "\n")

    print(f"[pre_write_guard] BLOCKED write to '{file_path}'")
    for reason in BLOCKED:
        print(f"  • {reason}")
    print("\nFix these issues before writing the file.")
    sys.exit(2)

# Allow — log the write
with open(log_dir / "write_guard.log", "a") as f:
    f.write(json.dumps({
        "ts":     datetime.utcnow().isoformat(),
        "tool":   tool_name,
        "path":   file_path,
        "action": "allowed"
    }) + "\n")

sys.exit(0)
