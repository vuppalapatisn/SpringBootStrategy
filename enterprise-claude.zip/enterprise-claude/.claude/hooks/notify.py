#!/usr/bin/env python3
"""
.claude/hooks/notify.py
Notification hook — fires on Claude Code session events.

Sends desktop notifications for long-running operations
and optionally posts to Slack for team awareness.

Set SLACK_WEBHOOK_URL env var to enable Slack notifications.
"""
import json
import sys
import os
import subprocess
from datetime import datetime

payload  = json.load(sys.stdin)
event    = os.environ.get("CLAUDE_NOTIFICATION", "")
hook_type = payload.get("hook_event_name", "Notification")

SLACK_WEBHOOK = os.environ.get("SLACK_WEBHOOK_URL", "")
SESSION_ID    = os.environ.get("CLAUDE_SESSION_ID", "unknown")

def desktop_notify(title: str, body: str):
    """Send OS desktop notification (Linux/macOS)."""
    try:
        # Linux
        subprocess.run(["notify-send", title, body], 
                      capture_output=True, timeout=5)
    except FileNotFoundError:
        try:
            # macOS
            subprocess.run([
                "osascript", "-e",
                f'display notification "{body}" with title "{title}"'
            ], capture_output=True, timeout=5)
        except FileNotFoundError:
            pass   # no notification tool available

def slack_notify(message: str):
    """Post to Slack via webhook (only if configured)."""
    if not SLACK_WEBHOOK:
        return
    try:
        import urllib.request
        data = json.dumps({"text": message}).encode()
        req  = urllib.request.Request(SLACK_WEBHOOK, data=data,
                                      headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass   # Slack notification failure is non-fatal

# ── EVENT ROUTING ──────────────────────────────────────────────────────────────
ts = datetime.utcnow().strftime("%H:%M:%S")

if "task complete" in event.lower() or "finished" in event.lower():
    desktop_notify("Claude Code ✅", f"Task complete at {ts}")

elif "waiting for input" in event.lower() or "need clarification" in event.lower():
    desktop_notify("Claude Code 💬", "Claude needs your input")

elif "error" in event.lower() or "failed" in event.lower():
    desktop_notify("Claude Code ❌", f"Error at {ts}: {event[:80]}")
    if SLACK_WEBHOOK:
        slack_notify(f"⚠️ Claude Code error in session `{SESSION_ID}`: {event[:200]}")

# Always log
log_dir = os.path.join(os.getcwd(), ".claude/audit")
os.makedirs(log_dir, exist_ok=True)
with open(os.path.join(log_dir, "notifications.log"), "a") as f:
    f.write(json.dumps({
        "ts":         datetime.utcnow().isoformat(),
        "session_id": SESSION_ID,
        "event":      event[:200],
        "hook_type":  hook_type
    }) + "\n")

sys.exit(0)
