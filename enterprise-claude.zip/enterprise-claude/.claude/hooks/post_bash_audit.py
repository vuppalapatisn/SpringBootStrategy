#!/usr/bin/env python3
"""
.claude/hooks/post_bash_audit.py
PostToolUse hook — fires after every Bash tool call completes.

Receives JSON on stdin:
  {
    "tool_name":   "Bash",
    "tool_input":  { "command": "..." },
    "tool_output": "... stdout ..."   (may be truncated)
  }

Responsibilities:
  1. Append a structured audit log entry.
  2. Scan output for accidentally leaked secrets and warn Claude.
  3. Detect test failures and format them clearly for Claude.

Exit 0 always — PostToolUse hooks inform, not block.
"""
import json
import sys
import re
from pathlib import Path
from datetime import datetime

payload    = json.load(sys.stdin)
tool_input = payload.get("tool_input", {})
output     = payload.get("tool_output", "")
command    = tool_input.get("command", "")

log_dir = Path(".claude/audit")
log_dir.mkdir(parents=True, exist_ok=True)

# ── AUDIT LOG ─────────────────────────────────────────────────────────────────
with open(log_dir / "bash_commands.log", "a") as f:
    f.write(json.dumps({
        "ts":      datetime.utcnow().isoformat(),
        "command": command[:500],
        "output":  output[:200],
        "action":  "completed"
    }) + "\n")

messages = []

# ── LEAKED SECRET SCAN on output ──────────────────────────────────────────────
SECRET_OUTPUT_PATTERNS = [
    (r'AKIA[0-9A-Z]{16}',          "AWS Access Key ID appeared in command output."),
    (r'sk-[a-zA-Z0-9]{32,}',       "API key pattern appeared in command output."),
    (r'(?i)password\s*[:=]\s*\S+', "Password value appeared in command output."),
]
for pattern, warning in SECRET_OUTPUT_PATTERNS:
    if re.search(pattern, output):
        messages.append(
            f"[post_bash_audit] ⚠️  SECRET LEAK WARNING: {warning}\n"
            f"  Do not log or display this value. Clear your terminal history."
        )

# ── TEST RESULT PARSER ────────────────────────────────────────────────────────
# Detect Maven Surefire or JUnit output and surface failures clearly
if "mvn" in command and ("test" in command or "verify" in command):
    failed_tests = re.findall(r'FAILED\s+([\w.]+)', output)
    error_tests  = re.findall(r'ERROR\s+([\w.]+)',  output)
    build_failed = "BUILD FAILURE" in output
    tests_run    = re.search(r'Tests run:\s*(\d+),\s*Failures:\s*(\d+),\s*Errors:\s*(\d+)', output)

    if build_failed:
        messages.append("[post_bash_audit] Maven BUILD FAILURE detected.")
        if tests_run:
            run, fails, errors = tests_run.groups()
            messages.append(f"  Tests run: {run}  Failures: {fails}  Errors: {errors}")
        if failed_tests:
            messages.append(f"  Failed tests: {', '.join(failed_tests[:5])}")
        if error_tests:
            messages.append(f"  Error tests:  {', '.join(error_tests[:5])}")

        # Extract the first meaningful error message from Surefire output
        cause = re.search(r'(java\.\w+Exception[^\n]+)', output)
        if cause:
            messages.append(f"  Root cause: {cause.group(1)}")

# ── EMIT ───────────────────────────────────────────────────────────────────────
if messages:
    print("\n".join(messages))

sys.exit(0)
