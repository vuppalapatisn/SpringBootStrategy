#!/usr/bin/env python3
"""
.claude/hooks/post_write_lint.py
PostToolUse hook — fires after every Write or Edit tool call.

Automatically runs the appropriate linter on the written file and
feeds the output back to Claude so it can self-correct immediately.

Exit code is always 0 — this hook informs, not blocks.
Stdout is injected into Claude's context window.
"""
import json
import sys
import subprocess
import os
from pathlib import Path
from datetime import datetime

payload   = json.load(sys.stdin)
tool_input = payload.get("tool_input", {})
file_path  = tool_input.get("path", "")

if not file_path or not Path(file_path).exists():
    sys.exit(0)

suffix = Path(file_path).suffix.lower()
output_lines = []
has_issues   = False

def run(cmd: list, cwd: str = None) -> tuple[int, str]:
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True,
            cwd=cwd or os.getcwd(), timeout=30
        )
        return result.returncode, (result.stdout + result.stderr).strip()
    except subprocess.TimeoutExpired:
        return 1, "Linter timed out after 30s"
    except FileNotFoundError:
        return 0, ""   # tool not installed — skip silently

# ── JAVA ───────────────────────────────────────────────────────────────────────
if suffix == ".java":
    # Google Java Format check (format-only, not style rules)
    rc, out = run(["google-java-format", "--dry-run", "--set-exit-if-changed", file_path])
    if rc != 0:
        has_issues = True
        output_lines.append(f"[post_write_lint] Google Java Format: file needs reformatting.")
        output_lines.append(f"  Run: google-java-format --replace {file_path}")

    # Checkstyle
    checkstyle_xml = "checkstyle.xml"
    if Path(checkstyle_xml).exists():
        rc, out = run(["java", "-jar", "tools/checkstyle.jar", "-c", checkstyle_xml, file_path])
        if rc != 0 and out:
            has_issues = True
            output_lines.append("[post_write_lint] Checkstyle violations:")
            for line in out.splitlines()[:20]:   # cap at 20 lines
                if "[WARN]" in line or "[ERROR]" in line:
                    output_lines.append(f"  {line}")

# ── YAML ───────────────────────────────────────────────────────────────────────
elif suffix in (".yml", ".yaml"):
    rc, out = run(["yamllint", "-f", "parsable", file_path])
    if rc != 0 and out:
        has_issues = True
        output_lines.append("[post_write_lint] yamllint issues:")
        for line in out.splitlines()[:15]:
            output_lines.append(f"  {line}")

    # CloudFormation lint
    if "cloudformation" in file_path or "infra/" in file_path:
        rc, out = run(["cfn-lint", file_path, "--format", "parseable"])
        if rc != 0 and out:
            has_issues = True
            output_lines.append("[post_write_lint] cfn-lint issues:")
            for line in out.splitlines()[:15]:
                output_lines.append(f"  {line}")

# ── JSON ───────────────────────────────────────────────────────────────────────
elif suffix == ".json":
    import json as jsonlib
    try:
        with open(file_path) as f:
            jsonlib.load(f)
    except jsonlib.JSONDecodeError as e:
        has_issues = True
        output_lines.append(f"[post_write_lint] JSON parse error in {file_path}: {e}")

# ── PYTHON ─────────────────────────────────────────────────────────────────────
elif suffix == ".py":
    rc, out = run(["ruff", "check", file_path])
    if rc != 0 and out:
        has_issues = True
        output_lines.append("[post_write_lint] ruff issues:")
        for line in out.splitlines()[:15]:
            output_lines.append(f"  {line}")

# ── MARKDOWN ───────────────────────────────────────────────────────────────────
elif suffix == ".md":
    rc, out = run(["markdownlint", file_path])
    if rc != 0 and out:
        has_issues = True
        output_lines.append("[post_write_lint] markdownlint issues:")
        for line in out.splitlines()[:10]:
            output_lines.append(f"  {line}")

# ── EMIT ───────────────────────────────────────────────────────────────────────
log_dir = Path(".claude/audit")
log_dir.mkdir(parents=True, exist_ok=True)
with open(log_dir / "lint_results.log", "a") as f:
    f.write(json.dumps({
        "ts":         datetime.utcnow().isoformat(),
        "file":       file_path,
        "has_issues": has_issues,
        "output":     "\n".join(output_lines)
    }) + "\n")

if output_lines:
    print("\n".join(output_lines))
    if has_issues:
        print(f"\n[post_write_lint] Please fix the above issues in {file_path}.")

sys.exit(0)   # PostToolUse hooks: 0 = inform, never block
