# /new-endpoint — scaffold a new payment API endpoint

Creates a complete vertical slice for a new endpoint following hexagonal architecture:
  - Controller (api layer)
  - Request/Response DTOs with validation
  - Service method (domain layer)
  - Repository method (infrastructure layer)
  - Unit tests for all three layers

## Usage
```
/new-endpoint POST /api/v1/payments/refund RefundPayment
```

## Arguments
$ENDPOINT_METHOD  - HTTP method (GET|POST|PUT|PATCH|DELETE)
$ENDPOINT_PATH    - URL path e.g. /api/v1/payments/refund
$USE_CASE_NAME    - PascalCase use case name e.g. RefundPayment

## What this command does

1. Creates `{UseCaseName}Request.java` and `{UseCaseName}Response.java` DTOs
2. Adds a controller method to the appropriate controller class
3. Adds a service method stub with the domain logic skeleton
4. Adds repository method if DB access is needed
5. Creates `{ControllerClass}Test.java` with the four standard test cases
6. Adds an OpenAPI `@Operation` annotation

## Rules applied
- Follow api/CLAUDE.md controller conventions
- Follow domain/CLAUDE.md service conventions
- ResponseEntity<ApiResponse<{UseCaseName}Response>> return type
- @PreAuthorize("hasRole('PAYMENT_OPERATOR')") unless stated otherwise
- @Valid on @RequestBody
- Log at INFO level on entry, DEBUG for payload (never log card data)
