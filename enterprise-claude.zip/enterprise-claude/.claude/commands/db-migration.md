# /db-migration — scaffold a new Flyway migration

Creates a correctly named, structured Flyway migration file.

## Usage
```
/db-migration add_retry_count_to_payments
/db-migration create_payment_methods_table
/db-migration add_idx_payments_status
```

## What this command does

1. Determines next version number: `V{YYYYMMDD}_{NNN}` based on existing files in `db/migrations/`
2. Creates `V{version}__{description}.sql`
3. Includes rollback comment block header
4. Adds transaction wrapper if DDL touches multiple tables
5. Adds `CREATE INDEX CONCURRENTLY` for any new indexes (avoids table lock)
6. Adds `IF NOT EXISTS` guards

## Rules applied (from db/CLAUDE.md)
- Never edit existing committed migrations
- Document estimated row count + duration in header
- Index for every FK added
- No DROP COLUMN — add DEPRECATED comment instead
- column defaults for NOT NULL additions

## Example output for `/db-migration add_retry_count_to_payments`

```sql
-- ============================================================
-- Migration: V20240601_001__add_retry_count_to_payments.sql
-- Description: Add retry_count and last_retry_at columns to
--              payments table for payment retry logic
-- Estimated rows: ~2M  |  Expected duration: <1s (metadata only)
-- Rollback: ALTER TABLE payments DROP COLUMN retry_count, last_retry_at;
-- ============================================================

ALTER TABLE payments
    ADD COLUMN IF NOT EXISTS retry_count     SMALLINT    NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS last_retry_at   TIMESTAMPTZ NULL;

COMMENT ON COLUMN payments.retry_count   IS 'Number of times payment processing has been retried';
COMMENT ON COLUMN payments.last_retry_at IS 'Timestamp of the most recent retry attempt';
```
