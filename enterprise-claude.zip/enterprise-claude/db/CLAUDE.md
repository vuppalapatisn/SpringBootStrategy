# Database Migrations (Flyway)

## File naming (mandatory)
`V{version}__{description}.sql`  — two underscores, description in snake_case.
Example: `V20240601_001__add_payment_status_index.sql`
Version: `YYYYMMDD_NNN` — date + daily sequence number.

## Rules
- **Never edit a committed migration.** Create a new one.
- **Never DROP COLUMN in prod.** Add `-- DEPRECATED: remove in sprint 47` and drop in a future release.
- **Every DDL change needs a rollback note** in a comment block at the top of the file.
- Multi-table changes: wrap in explicit transaction (`BEGIN; ... COMMIT;`).
- Add `IF NOT EXISTS` / `IF EXISTS` guards on all CREATE/DROP statements.
- Every FK gets a covering index — include `CREATE INDEX` in the same migration.
- Column defaults for new NOT NULL columns — never leave existing rows in invalid state.

## Performance
- Large table migrations: use `ALTER TABLE ... ADD COLUMN ... DEFAULT NULL` then backfill separately.
- Index creation: `CREATE INDEX CONCURRENTLY` to avoid table lock in prod.
- Document estimated row count + expected duration in migration header comment.

## Naming conventions
- Tables: `snake_case` plural nouns (`payments`, `payment_methods`).
- Columns: `snake_case`. PKs: `id`. FKs: `{table_singular}_id`.
- Indexes: `idx_{table}_{columns}`. Unique: `uq_{table}_{columns}`.
