-- ============================================================
-- Migration: V20240601_001__create_payments_table.sql
-- Description: Initial payments table with all core columns,
--              indexes, and FK relationships.
-- Estimated rows: 0 (new table)  |  Expected duration: <1s
-- Rollback: DROP TABLE IF EXISTS payments CASCADE;
-- Author: payments-team
-- ============================================================

BEGIN;

CREATE TABLE IF NOT EXISTS payments (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    merchant_id         UUID            NOT NULL,
    amount              NUMERIC(19, 4)  NOT NULL,
    currency            CHAR(3)         NOT NULL,
    status              VARCHAR(20)     NOT NULL DEFAULT 'PENDING',
    masked_card         VARCHAR(19)     NULL,           -- ****-****-****-1234 format only
    failure_reason      TEXT            NULL,
    idempotency_key     VARCHAR(255)    NOT NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    version             BIGINT          NOT NULL DEFAULT 0,  -- optimistic locking

    CONSTRAINT pk_payments PRIMARY KEY (id),
    CONSTRAINT uq_payments_idempotency_key UNIQUE (idempotency_key),
    CONSTRAINT chk_payments_amount CHECK (amount > 0),
    CONSTRAINT chk_payments_status CHECK (status IN (
        'PENDING', 'AUTHORIZED', 'CAPTURED', 'REFUNDED', 'FAILED', 'CANCELLED'
    )),
    CONSTRAINT chk_payments_currency CHECK (currency ~ '^[A-Z]{3}$')
);

-- ── Indexes ────────────────────────────────────────────────────────────────────
-- FK index (always add index for FK columns)
CREATE INDEX IF NOT EXISTS idx_payments_merchant_id
    ON payments (merchant_id);

-- Status queries (most common filter)
CREATE INDEX IF NOT EXISTS idx_payments_status
    ON payments (status) WHERE status IN ('PENDING', 'AUTHORIZED');

-- Time-range queries
CREATE INDEX IF NOT EXISTS idx_payments_created_at
    ON payments (created_at DESC);

-- Combined: merchant + status + time (dashboard queries)
CREATE INDEX IF NOT EXISTS idx_payments_merchant_status_created
    ON payments (merchant_id, status, created_at DESC);

-- ── Comments ───────────────────────────────────────────────────────────────────
COMMENT ON TABLE  payments                  IS 'Core payment records — one row per payment attempt';
COMMENT ON COLUMN payments.masked_card      IS 'Last-4 masked card number. Format: ****-****-****-NNNN. Never store full PAN.';
COMMENT ON COLUMN payments.idempotency_key  IS 'Client-supplied key preventing duplicate payment creation';
COMMENT ON COLUMN payments.version          IS 'Optimistic lock version — incremented on every update';

COMMIT;
