# Payments Platform — Claude Code Configuration

Java 21 + Spring Boot 3.x monorepo. Hexagonal architecture (ports & adapters).
Conventional commits: `feat|fix|chore|docs|refactor|test(scope): message`.
Branch naming: `feature/*`, `fix/*`, `release/*`, `hotfix/*`.

## Universal rules (apply in every file, every session)

- **Never log PII.** Mask card numbers as `****-****-****-1234`, emails as `u***@domain.com`.
- **No secrets in code.** Credentials, API keys, tokens → AWS Secrets Manager or env vars only.
- **Least-privilege IAM.** No `*` resources in prod policies. Scope to specific ARNs.
- **All public API inputs validated** before they touch the domain layer.
- Tests must pass before any commit. Never `@Disabled` without a linked JIRA ticket comment.

## Where specific rules live

| Area                  | File                              |
|-----------------------|-----------------------------------|
| API / controllers     | `src/main/java/com/payments/api/CLAUDE.md`       |
| Domain / services     | `src/main/java/com/payments/domain/CLAUDE.md`    |
| Infrastructure layer  | `src/main/java/com/payments/infrastructure/CLAUDE.md` |
| Database migrations   | `db/CLAUDE.md`                    |
| CloudFormation / AWS  | `infra/CLAUDE.md`                 |
| CI/CD pipeline        | `.github/CLAUDE.md`               |

## Quick reference — do not repeat in scoped files

```
Encoding:    UTF-8 everywhere
Line ending: LF (Unix)
Indent:      4 spaces (Java), 2 spaces (YAML/JSON)
Max line:    120 chars
```
