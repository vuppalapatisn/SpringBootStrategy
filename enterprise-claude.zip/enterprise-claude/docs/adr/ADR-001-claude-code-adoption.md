# ADR-001: Adopting Claude Code for AI-assisted development

**Status:** Accepted  
**Date:** 2024-06-01  
**Deciders:** Engineering Lead, Security Lead, Platform Team

## Context

The team evaluated AI coding assistants for the payments platform. The key
requirements were: audit logging of all AI actions, ability to enforce
security rules (PII masking, no hardcoded credentials), and integration with
our existing Java/Spring Boot stack.

## Decision

Adopt Claude Code with:
- Scoped CLAUDE.md files per architectural layer
- PreToolUse hooks for security enforcement
- PostToolUse hooks for automatic linting
- Audit log shipping to S3 for compliance

## Consequences

- All AI-assisted coding sessions are fully auditable
- PII and credential rules enforced at the hook level (not just model instruction)
- ~80% reduction in irrelevant context loaded per session vs monolithic CLAUDE.md
- Team must maintain CLAUDE.md files as architecture evolves
