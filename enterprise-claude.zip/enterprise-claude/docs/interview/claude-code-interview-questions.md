# Interview Questions — CLAUDE.md vs Rules vs Skills
# Claude Code configuration, agent hooks, and enterprise AI-assisted development

─────────────────────────────────────────────────────────────────────────────
SECTION 1: FOUNDATIONAL CONCEPTS
─────────────────────────────────────────────────────────────────────────────

Q1. What is CLAUDE.md and what is its primary purpose?

A: CLAUDE.md is a Markdown file that Claude Code reads at the start of every
   session to understand the project context, coding conventions, and team
   rules. Its primary purpose is to give Claude persistent, session-level
   instructions without repeating them in every prompt.

   It is NOT a system prompt — it's a project-level context file that Claude
   reads from the repository. The key distinction is that it is version-
   controlled alongside the code it describes.

──────────────────────────────────────────────────────────────────────────────

Q2. Where can CLAUDE.md files live, and how does Claude discover them?

A: Three locations, each with a different scope:

   1. ~/.claude/CLAUDE.md         → global (every project on this machine)
   2. {project-root}/CLAUDE.md    → project-wide (loaded for every session)
   3. {any-subdirectory}/CLAUDE.md → scoped (loaded only when Claude opens
                                       files in that directory or its children)

   Claude Code reads them hierarchically: global → root → subdirectory.
   Subdirectory files are only loaded when relevant — this is the key
   mechanism for keeping sessions lean.

──────────────────────────────────────────────────────────────────────────────

Q3. What is the single most important rule for writing CLAUDE.md?

A: Keep it concise. Anthropic explicitly advises this.

   A bloated CLAUDE.md that covers every scenario loads irrelevant rules into
   every session, increasing token usage and diluting the signal. The root
   file should contain only:
     • Project identity (tech stack, architecture style)
     • Universal non-negotiables (PII rules, security absolutes)
     • A table pointing to where scoped rules live

   Everything specific (database migration rules, frontend component rules,
   CloudFormation conventions) belongs in path-scoped CLAUDE.md files or in
   skills.

──────────────────────────────────────────────────────────────────────────────

Q4. What is a "skill" in the Claude Code context, and how does it differ from
    a CLAUDE.md file?

A: A skill is a reusable, task-specific instruction document (typically a
   SKILL.md file) that Claude reads on demand — not automatically loaded at
   session start.

   Key differences:

   CLAUDE.md:                          Skill:
   ─────────────────────────────────   ─────────────────────────────────────
   Loaded automatically by path        Read explicitly when task matches
   Describes standing conventions      Describes how to perform a specific task
   Persistent across the session       Consulted for that task, then done
   Example: "always use BigDecimal     Example: "how to create a Flyway
   for money"                          migration in this project"

   Skills encode procedural knowledge (steps, templates, gotchas for a
   specific task type). CLAUDE.md encodes declarative knowledge (what this
   project is and what the rules are).

──────────────────────────────────────────────────────────────────────────────

Q5. What is a Claude Code hook? Name the three hook types.

A: A hook is a shell command you register in .claude/settings.json that fires
   at specific points in Claude's agent lifecycle. The three types are:

   PreToolUse    → fires BEFORE Claude calls a tool (Bash, Write, Edit, etc.)
                   Can BLOCK the tool call by exiting with code 2.
                   Receives full tool input on stdin.

   PostToolUse   → fires AFTER a tool call completes.
                   Cannot block (exit 0 always).
                   Stdout is injected into Claude's context window.
                   Use for: auto-lint, audit logging, test result parsing.

   Notification  → fires on session lifecycle events (task complete, waiting
                   for input, errors).
                   Use for: desktop notifications, Slack alerts.

──────────────────────────────────────────────────────────────────────────────

─────────────────────────────────────────────────────────────────────────────
SECTION 2: DESIGN & ARCHITECTURE
─────────────────────────────────────────────────────────────────────────────

Q6. You have a Spring Boot monorepo with API, domain, infrastructure, and DB
    migration layers. How would you structure the CLAUDE.md files?

A: Four scoped files plus one lean root:

   CLAUDE.md                          → identity + universal rules (~30 lines)
   src/main/java/com/.../api/CLAUDE.md      → controller/DTO/validation rules
   src/main/java/com/.../domain/CLAUDE.md   → hexagonal domain rules
   src/main/java/com/.../infra/CLAUDE.md    → JPA, Kafka, security adapter rules
   db/CLAUDE.md                       → Flyway migration rules + naming

   Why: a session fixing a CSS bug loads only the root + ui scoped file.
   A session writing a DB migration loads root + db. Never more than needed.

──────────────────────────────────────────────────────────────────────────────

Q7. What is the difference between a PreToolUse hook exiting with code 0, 1,
    and 2?

A:
   Exit 0 → Allow. The tool call proceeds normally.
             Any stdout is added to Claude's context (useful for warnings).

   Exit 1 → Error in the hook itself. Claude sees this as a hook failure,
             not a blocked tool call. Tool call may still proceed.

   Exit 2 → BLOCK. The tool call is cancelled. Claude receives the hook's
             stdout as an explanation and must try a different approach.
             This is the correct exit code for intentional blocking.

   The distinction between 1 and 2 is critical: exit 1 signals "the guard
   script crashed", exit 2 signals "I intentionally blocked this".

──────────────────────────────────────────────────────────────────────────────

Q8. You want Claude to automatically fix linting errors after every file it
    writes. Which hook type do you use, and why not the other?

A: PostToolUse — specifically matched on "Write" and "Edit" tool names.

   Why not PreToolUse:
     PreToolUse fires before the write. The file doesn't exist yet when the
     hook runs, so you can't lint it. You also can't "pre-lint" content that
     hasn't been written.

   How it works:
     PostToolUse receives the path of the written file in tool_input.
     The hook runs the appropriate linter (checkstyle for .java, yamllint for
     .yaml, cfn-lint for CloudFormation).
     Linting output on stdout is injected into Claude's context.
     Claude then self-corrects in the next turn without being asked.

   Important: PostToolUse hooks should always exit 0. If they exit non-zero,
   the audit infrastructure breaks but the write is not reversed.

──────────────────────────────────────────────────────────────────────────────

Q9. What data does a PreToolUse hook receive on stdin? Give the exact JSON
    shape for a Bash call and a Write call.

A: Both receive the same envelope, but tool_input shape differs:

   Bash:
   {
     "tool_name": "Bash",
     "tool_input": {
       "command":     "mvn clean test",
       "description": "Run unit tests"
     }
   }

   Write:
   {
     "tool_name": "Write",
     "tool_input": {
       "path":    "src/main/java/com/payments/api/controllers/PaymentController.java",
       "content": "package com.payments.api; ..."
     }
   }

   Edit:
   {
     "tool_name": "Edit",
     "tool_input": {
       "path":       "src/.../PaymentController.java",
       "old_string": "// old code",
       "new_string": "// new code"
     }
   }

   The hook reads these via json.load(sys.stdin) and inspects the relevant
   field before deciding to block or allow.

──────────────────────────────────────────────────────────────────────────────

Q10. How would you prevent Claude from accidentally deploying to the production
     AWS environment directly from a local Claude Code session?

A: PreToolUse hook on Bash, blocking two patterns:

   1. AWS CLI with --profile prod:
      Pattern: r'aws\s+.*--profile\s+prod\b'
      Reason:  "Blocked: direct AWS CLI calls using the prod profile are not
                allowed from Claude. Deploy via the CI/CD pipeline."

   2. kubectl with production context:
      Pattern: r'kubectl\s+.*--context\s+(prod|production)'
      Reason:  "Blocked: kubectl commands against production context must go
                through the deployment pipeline."

   Additionally in infra/CLAUDE.md:
   "Never run aws cloudformation deploy directly for prod. Always commit
   to release/* and let the pipeline handle it."

   Belt-and-suspenders: the CLAUDE.md rule tells Claude's reasoning layer.
   The hook blocks even if Claude ignores the CLAUDE.md or is confused.

──────────────────────────────────────────────────────────────────────────────

─────────────────────────────────────────────────────────────────────────────
SECTION 3: SPRING BOOT + ENTERPRISE SPECIFICS
─────────────────────────────────────────────────────────────────────────────

Q11. Where in a Spring Boot hexagonal architecture should CLAUDE.md rules
     draw the sharpest boundary, and why?

A: Between the domain layer and the infrastructure layer.

   The hexagonal architecture rule is: domain classes must not import any
   framework or adapter classes. This means:
     • No @Entity on domain classes (that's a JPA annotation)
     • No @Service / @Component on domain model classes
     • No direct Kafka producer calls from domain services
     • Domain services receive port interfaces (injected) — never adapters

   In domain/CLAUDE.md:
   "No JPA annotations on domain classes — that belongs in
   infrastructure/persistence."
   "Services take ports (interfaces), never concrete adapters."

   Claude must know this rule exists in the domain layer context so it doesn't
   helpfully add @Entity to the Payment aggregate root.

──────────────────────────────────────────────────────────────────────────────

Q12. What CLAUDE.md rule prevents the most common PII logging mistake in
     Java payment applications?

A: "Never log PII. Mask card numbers as ****-****-****-1234, emails as
    u***@domain.com."

   The most common mistake Claude makes without this rule: logging the request
   DTO directly. For example:
     log.info("Processing payment request: {}", request);

   If the DTO has a cardNumber field, this logs the full PAN to CloudWatch.

   With the rule, Claude will:
     log.info("Processing payment: merchantId={} amount={} currency={}",
               request.getMerchantId(), request.getAmount(), request.getCurrency());

   The PreToolUse write guard reinforces this by scanning written content for
   real card number patterns (Luhn-valid 16-digit strings) before the file is
   created.

──────────────────────────────────────────────────────────────────────────────

Q13. A developer asks Claude to add a new column to the payments table. What
     should db/CLAUDE.md say to ensure Claude generates a correct migration?

A: The db/CLAUDE.md should specify:

   1. File naming: V{YYYYMMDD}_{NNN}__{description}.sql — two underscores
   2. Never edit a committed migration — create a new one
   3. Never DROP COLUMN in prod — add DEPRECATED comment
   4. Transaction wrapper for multi-table changes
   5. Add IF NOT EXISTS guards on all DDL
   6. Every FK must have a covering index in the same migration
   7. NOT NULL new columns need a DEFAULT to avoid failing existing rows
   8. CREATE INDEX CONCURRENTLY to avoid table locks

   Without rule 7, Claude will write:
     ADD COLUMN status VARCHAR(20) NOT NULL
   which fails on a non-empty table because existing rows have no value.

   With rule 7, Claude writes:
     ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'PENDING'

──────────────────────────────────────────────────────────────────────────────

─────────────────────────────────────────────────────────────────────────────
SECTION 4: ADVANCED / SCENARIO-BASED
─────────────────────────────────────────────────────────────────────────────

Q14. What is the difference between putting a rule in CLAUDE.md versus
     enforcing it in a hook?

A: CLAUDE.md works through Claude's reasoning — it instructs the model.
   Hooks work through code execution — they intercept regardless of model behaviour.

   CLAUDE.md rule:  Claude reads it and tries to comply. Can be forgotten if
                    the context window is long, if Claude misinterprets it, or
                    if a subtle case isn't covered.

   Hook:            Executes every time, unconditionally, without relying on
                    Claude's interpretation. Cannot be "forgotten."

   Best practice — use both in combination:
     • CLAUDE.md tells Claude WHY (so it understands the intent and applies
       it in edge cases the hook doesn't cover)
     • Hook enforces the WHAT (so violations are caught even when Claude's
       reasoning slips)

   Example: "Never hardcode AWS credentials" in CLAUDE.md teaches Claude the
   principle. The PreToolUse write guard scanning for AKIA[A-Z0-9]{16} catches
   the cases where Claude still does it anyway.

──────────────────────────────────────────────────────────────────────────────

Q15. A PostToolUse hook runs checkstyle and finds 12 violations. How does
     Claude receive this feedback, and what happens next?

A: The hook prints the violations to stdout and exits 0. Claude Code injects
   the stdout as a tool result into the conversation context — Claude sees it
   as feedback from the last action it took.

   Claude then reads the violations in its next reasoning step and will
   typically:
     1. Call the Edit tool to fix each violation
     2. Those edits trigger the PostToolUse hook again
     3. The loop continues until checkstyle exits 0 (no violations output)

   This creates a self-correction loop without any human involvement.

   Important consideration: cap the violations output (e.g. first 20 lines)
   to avoid flooding Claude's context with hundreds of checkstyle lines that
   push useful context out of the window.

──────────────────────────────────────────────────────────────────────────────

Q16. How would you use a custom slash command alongside CLAUDE.md to enforce
     a consistent "vertical slice" pattern when creating new endpoints?

A: Create .claude/commands/new-endpoint.md:

   The command documents the exact steps Claude must follow:
     1. Controller method with specific annotations (@Operation, @PreAuthorize)
     2. Request/Response DTOs with JSR-380 validation constraints
     3. Service method stub following domain rules
     4. Four standard test cases (happy, validation failure, 401, 403)

   Usage: /new-endpoint POST /api/v1/payments/refund RefundPayment

   The slash command is the right tool here (not CLAUDE.md) because:
     • It's procedural (a recipe for a specific task)
     • It's only relevant when creating endpoints — not every session
     • It can take arguments ($ENDPOINT_METHOD, $ENDPOINT_PATH, $USE_CASE_NAME)
     • It would be noise in CLAUDE.md since most sessions don't create endpoints

   Think of slash commands as "skills you invoke", CLAUDE.md as "rules that
   always apply."

──────────────────────────────────────────────────────────────────────────────

Q17. What three things should the root CLAUDE.md NEVER contain?

A:
   1. Tool-specific procedural instructions ("when creating a migration,
      first determine the version number by..."). Those belong in a skill
      or slash command — they're only relevant for that specific task.

   2. Layer-specific conventions that only apply to one part of the codebase
      ("JPA entities should be suffixed JpaEntity", "use @DataJpaTest for
      persistence tests"). Those belong in the infrastructure/ scoped file.

   3. Environment-specific values (URLs, account IDs, bucket names, feature
      flags). Those belong in config files, not instructions to Claude.

   The root CLAUDE.md is read in EVERY session. Anything in it that isn't
   universally relevant is just noise that wastes tokens and dilutes the rules
   that genuinely matter everywhere.

──────────────────────────────────────────────────────────────────────────────

Q18. How would you audit what Claude Code has done in a session? What hook
     makes this possible?

A: A PostToolUse hook on Bash + Write + Edit that appends to audit log files:

   .claude/audit/bash_commands.log  — every command with timestamp
   .claude/audit/write_guard.log    — every file write (allowed + blocked)
   .claude/audit/lint_results.log   — every lint run result

   Each entry is a JSON object: { "ts", "command/path", "action", ... }

   This gives you:
     • Full replay of what Claude did in a session
     • Blocked actions (shows what the guard caught)
     • Which files were written and when
     • Lint issue history

   For enterprise compliance this log can be shipped to a SIEM or S3 bucket
   by the Notification hook.

──────────────────────────────────────────────────────────────────────────────

Q19. Explain the token economy argument for scoped CLAUDE.md files.

A: Claude has a finite context window. Every token spent on irrelevant
   instructions is a token not available for the actual code Claude is
   reading and writing.

   Example monorepo with one 400-line CLAUDE.md:
     • Fixing a CSS bug: 400 lines loaded, ~380 lines irrelevant
     • Writing a DB migration: 400 lines loaded, ~350 lines irrelevant
     • Reviewing infrastructure: 400 lines loaded, ~300 lines irrelevant

   Same monorepo with scoped files (root: 30 lines, scoped: 60 lines each):
     • Fixing a CSS bug: 30 + 60 = 90 lines loaded, all relevant
     • Writing a DB migration: 30 + 60 = 90 lines loaded, all relevant

   The scoped approach uses ~77% fewer tokens for instructions, leaving
   more context window available for:
     • The actual code being modified
     • Test output
     • Error messages
     • Longer conversations without context degradation

──────────────────────────────────────────────────────────────────────────────

Q20. A new team member asks: "Can I just put everything in the global
     ~/.claude/CLAUDE.md so it applies everywhere?" What's your response?

A: Only for personal machine-level preferences that genuinely apply to every
   project you work on — things like:
     "I prefer verbose explanations over terse ones."
     "Always suggest tests alongside implementation."

   Do NOT put project-specific rules in the global file because:
     1. Those rules will bleed into unrelated projects (a payments PII rule
        appearing in a recipe app makes no sense)
     2. It can't be version-controlled alongside the project code
     3. Other team members won't benefit — everyone needs their own copy
     4. Rules that belong in the repo should be in the repo

   The global file is for personal workflow preferences. Project rules belong
   in the project. This mirrors the principle of keeping concerns in the right
   scope — the same reason we don't put database schema rules in the UI layer.
