# Infrastructure (CloudFormation + AWS)

## Templates
- One stack per bounded context: `payments-compute`, `payments-data`, `payments-network`.
- Parameters file per environment: `parameters/{env}.json`.
- All resources tagged: `Environment`, `Project=payments`, `ManagedBy=CloudFormation`, `CostCenter`.
- `DeletionPolicy: Retain` on all stateful resources (RDS, S3, DynamoDB).

## Security non-negotiables
- S3: `PublicAccessBlockConfiguration` all `true`. Bucket policy: deny non-SSL.
- RDS: `StorageEncrypted: true`, `DeletionProtection: !If [IsProd, true, false]`.
- Security groups: no `0.0.0.0/0` ingress except ALB on 443.
- KMS key rotation: `EnableKeyRotation: true` on every CMK.
- Secrets: `AWS::SecretsManager::Secret` — never `AWS::SSM::Parameter` type `String` for secrets.

## Naming
- Resources: `${ProjectName}-${Environment}-{resource-type}` e.g. `payments-prod-api-sg`.
- Exports: `${ProjectName}-${Environment}-{logical-name}` for cross-stack refs.

## Environments
- `dev`: auto-deploy on merge to develop.
- `test`: auto-deploy on merge to release/*.
- `prod`: manual approval gate, change set reviewed before execute.

## Validation
- `cfn-lint` runs in CI on every PR touching `infra/**`.
- `cfn-nag` runs for security policy violations.
