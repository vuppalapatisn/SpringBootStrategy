# CLAUDE.md

This repository manages an enterprise-grade AWS Transfer Family SFTP platform deployed via Azure DevOps.

## Project conventions

- Prefer CloudFormation over ad hoc AWS CLI resource creation.
- Never weaken security controls to make a pipeline pass.
- Preserve:
  - S3 audit bucket object lock governance configuration
  - CloudTrail logging
  - GuardDuty enablement
  - environment-specific retention requirements
- Validate before deployment:
  - YAML formatting
  - `cfn-lint`
  - AWS CloudFormation `validate-template`
  - custom bucket/service-connection validation
- Do not hardcode secrets.
- Azure DevOps should use variable groups and service connections.
- Bucket names must be globally unique.
- Development can use Claude MCP assistance on failure; production must not auto-remediate.
