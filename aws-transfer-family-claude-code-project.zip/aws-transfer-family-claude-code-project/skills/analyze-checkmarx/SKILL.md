---
name: analyze-checkmarx
summary: Summarize Checkmarx and IaC scan failures and produce remediation guidance.
---

# Analyze Checkmarx failure

## Output format

1. Failure category
2. Affected files/resources
3. Why it failed
4. Risk if ignored
5. Exact remediation suggestions
6. Whether the fix is safe for production
