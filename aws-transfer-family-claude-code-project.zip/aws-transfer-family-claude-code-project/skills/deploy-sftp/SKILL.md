---
name: deploy-sftp
summary: Validate and deploy the AWS Transfer Family SFTP CloudFormation stack via Azure DevOps or local CLI.
---

# Deploy SFTP stack

1. Confirm the target environment (`dev`, `test`, `prod`).
2. Validate parameter file and variable file.
3. Run YAML lint.
4. Run `cfn-lint`.
5. Run `aws cloudformation validate-template`.
6. Review object lock, CloudTrail, GuardDuty, and IAM changes.
7. Deploy and verify outputs.
