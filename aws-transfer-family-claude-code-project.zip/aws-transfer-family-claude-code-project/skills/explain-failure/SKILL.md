---
name: explain-failure
summary: Turn raw CI/CD failure logs into a short executive summary plus a detailed engineer remediation plan.
---

# Explain pipeline failure

Required sections:

- Executive summary
- Technical root cause
- File/resource impacted
- Immediate fix
- Preventive control to avoid recurrence
