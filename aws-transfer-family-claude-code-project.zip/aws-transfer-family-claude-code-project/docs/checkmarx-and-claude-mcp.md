# Checkmarx + Claude MCP Assistance

This repository supports a two-step dev failure workflow:

1. Checkmarx scan runs in CI.
2. If the scan fails in `dev`, the pipeline generates:
   - `failure-summary.md`
   - `claude-remediation.md`

## Required secrets

- `CHECKMARX_BASE_URI`
- `CHECKMARX_TENANT`
- `CHECKMARX_API_KEY`
- `ANTHROPIC_API_KEY`
- `ANTHROPIC_MODEL`
- `MCP_SERVER_URL`
- `MCP_SERVER_NAME`
- `MCP_AUTH_TOKEN` (optional)

## MCP expectations

The helper script assumes a remote HTTP/SSE MCP server that Claude can connect to.
Typical MCP tools could expose:

- repository search
- policy lookup
- remediation catalog lookup
- secure coding playbooks
