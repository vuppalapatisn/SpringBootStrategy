# Operations Runbook

## Transfer Family users deployed by default

| User | Capability |
|------|------------|
| `readonly` | list + get from own home prefix |
| `writeonly` | put/upload only to own home prefix |
| `readwrite` | list + get + put in own home prefix |
| `readwritedelete` | list + get + put + delete in own home prefix |

## Home directory mapping

Each user maps to:

```text
s3://<data-bucket>/home/<username>/
```

## Add SSH key for a user

```bash
aws transfer import-ssh-public-key   --server-id <server-id>   --user-name readwrite   --ssh-public-key-body "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAA.... user@host"
```

## Incident triage

If pipeline fails in `dev`:

1. Open pipeline artifacts
2. Read `failure-summary.md`
3. Read `claude-remediation.md`
4. Fix code/template
5. Rerun `dev`

If pipeline fails in `test` or `prod`:

1. Review raw artifacts
2. Fix manually
3. Do not auto-remediate in live environments
