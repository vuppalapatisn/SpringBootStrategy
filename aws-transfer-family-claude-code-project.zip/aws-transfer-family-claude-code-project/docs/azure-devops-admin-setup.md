# Azure DevOps Admin Setup Guide

## 1) Install required Azure DevOps extensions

Install these into your Azure DevOps organization:

1. AWS Toolkit for Azure DevOps
2. Checkmarx One (optional if you use CLI mode in this repo)

## 2) Create Azure DevOps environments

Create:

- `aws-dev`
- `aws-test`
- `aws-prod`

Recommended checks:

- `aws-test`: manual approval or business-owner approval
- `aws-prod`: mandatory manual approval + branch control + change window

## 3) Create AWS service connections

Create one AWS service connection per environment:

- `aws-dev-sc`
- `aws-test-sc`
- `aws-prod-sc`

Grant least privilege for:

- CloudFormation stack create/update
- S3 bucket create/policy/object-lock config
- IAM role creation and pass role
- CloudTrail creation
- GuardDuty detector creation
- Transfer Family server/user creation
- CloudWatch Logs create/write

## 4) Create variable groups

Create a variable group such as `transfer-family-shared-secrets` with:

- `CHECKMARX_BASE_URI`
- `CHECKMARX_TENANT`
- `CHECKMARX_API_KEY`
- `ANTHROPIC_API_KEY`
- `ANTHROPIC_MODEL`
- `MCP_SERVER_URL`
- `MCP_SERVER_NAME`
- `MCP_AUTH_TOKEN`

## 5) Create the pipeline

1. Pipelines -> New pipeline
2. Select repository
3. Choose existing YAML file
4. Select `/azure-pipelines.yml`
5. Save

## 6) First execution order

1. Run `dev`
2. Review artifacts and outputs
3. Import SSH keys for the 4 users
4. Test each permission profile
5. Run `test`
6. Run `prod` after approvals
