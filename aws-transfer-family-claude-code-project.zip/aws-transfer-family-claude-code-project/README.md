# AWS Transfer Family SFTP on S3 + Azure DevOps + Checkmarx + Claude MCP

This repository is a production-ready **foundation** for deploying an **AWS Transfer Family SFTP server backed by Amazon S3** using **Azure DevOps**, with:

- CloudFormation-based infrastructure
- Azure DevOps multi-environment pipeline (`dev`, `test`, `prod`)
- YAML + CloudFormation lint/validation
- Input validation for environment, bucket names, retention, and service connections
- Checkmarx security scan integration
- Dev-only failure assistance using Claude + MCP
- GuardDuty + CloudTrail enabled
- Separate immutable audit/log bucket with **Object Lock Governance**
- 4 service-managed SFTP user archetypes:
  - `readonly`
  - `writeonly`
  - `readwrite`
  - `readwritedelete`

> Bucket names must be globally unique. The deployment script converts `AUTO` values in the parameter files into names using your AWS account ID + environment.

## Repository structure

```text
.
├── CLAUDE.md
├── .claude/
│   └── rules/
├── skills/
├── azure-pipelines.yml
├── cloudformation/
│   ├── transfer-family-sftp.yml
│   └── parameters/
├── scripts/
├── docs/
├── cfn-guard/
├── .yamllint.yml
└── requirements-dev.txt
```

## What this deploys

- `AWS::Transfer::Server` (SFTP, S3 domain, service-managed users)
- 1 S3 data bucket for incoming/outgoing files
- 1 S3 immutable audit bucket for:
  - CloudTrail logs
  - S3 server access logs
  - transfer operational/audit artifacts
- GuardDuty detector (optional switch enabled by default)
- CloudWatch log groups for Transfer Family and CloudTrail
- IAM roles/policies for the 4 user permission archetypes
- 4 pre-created Transfer Family users (without SSH keys, by design)

## Quick start

1. Review and update parameter files under `cloudformation/parameters/`
2. Review `.azuredevops/variables/*.yml`
3. Install Azure DevOps extensions:
   - AWS Toolkit for Azure DevOps
   - Checkmarx One (optional if you use the CLI mode in this repo)
4. Create Azure DevOps variable groups and service connections
5. Create Azure DevOps environments: `aws-dev`, `aws-test`, `aws-prod`
6. Apply approvals/checks to `aws-test` and `aws-prod`
7. Run the pipeline with `environment=dev`

## After deployment

Import SSH public keys for each Transfer Family user:

```bash
aws transfer import-ssh-public-key   --server-id s-xxxxxxxxxxxx   --user-name readonly   --ssh-public-key-body "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAA... readonly@company"
```

Repeat for `writeonly`, `readwrite`, and `readwritedelete`.

## Guides

- Azure DevOps setup: `docs/azure-devops-admin-setup.md`
- Operations runbook: `docs/operations-runbook.md`
- Checkmarx + Claude MCP: `docs/checkmarx-and-claude-mcp.md`
