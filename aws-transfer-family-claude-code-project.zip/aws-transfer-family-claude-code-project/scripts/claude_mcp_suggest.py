#!/usr/bin/env python3
import json, os, sys
from pathlib import Path
import requests

if len(sys.argv) != 3:
    sys.stderr.write('Usage: claude_mcp_suggest.py <failure-markdown> <output-markdown>\n')
    sys.exit(1)

api_key = os.environ['ANTHROPIC_API_KEY']
model = os.environ.get('ANTHROPIC_MODEL', 'claude-opus-4-1')
api_url = os.environ.get('ANTHROPIC_API_URL', 'https://api.anthropic.com/v1/messages')
mcp_url = os.environ['MCP_SERVER_URL']
mcp_name = os.environ.get('MCP_SERVER_NAME', 'code-remediation')
mcp_auth = os.environ.get('MCP_AUTH_TOKEN')

failure_text = Path(sys.argv[1]).read_text(encoding='utf-8', errors='ignore')
output_file = Path(sys.argv[2])

mcp_server = {'type': 'url', 'url': mcp_url, 'name': mcp_name}
if mcp_auth:
    mcp_server['authorization_token'] = mcp_auth

payload = {
    'model': model,
    'max_tokens': 1600,
    'messages': [
        {
            'role': 'user',
            'content': (
                'You are helping an Azure DevOps team fix a pipeline failure for an AWS Transfer Family + CloudFormation + Checkmarx repository. '
                'Read the failure summary below, use any connected MCP tools if appropriate, and produce: '
                '1) root cause, 2) exact fix suggestions, 3) risk if ignored, 4) whether the fix is safe for production.\n\n' + failure_text
            )
        }
    ],
    'mcp_servers': [mcp_server],
    'tools': [{'type': 'mcp_toolset', 'mcp_server_name': mcp_name}]
}

headers = {
    'x-api-key': api_key,
    'anthropic-version': '2023-06-01',
    'anthropic-beta': 'mcp-client-2025-11-20',
    'content-type': 'application/json',
}

response = requests.post(api_url, headers=headers, json=payload, timeout=180)
response.raise_for_status()
data = response.json()
parts = [item.get('text', '') for item in data.get('content', []) if item.get('type') == 'text']
output = '\n\n'.join(parts).strip() or json.dumps(data, indent=2)
output_file.write_text(output, encoding='utf-8')
print(output_file)
