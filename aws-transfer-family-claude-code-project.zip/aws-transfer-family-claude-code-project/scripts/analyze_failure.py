#!/usr/bin/env python3
import sys
from pathlib import Path

if len(sys.argv) != 3:
    sys.stderr.write('Usage: analyze_failure.py <raw-log-file> <output-markdown>\n')
    sys.exit(1)

raw = Path(sys.argv[1]).read_text(encoding='utf-8', errors='ignore')
out = Path(sys.argv[2])
text = raw.lower()

if 'checkmarx' in text or 'cx scan' in text:
    category = 'Checkmarx security scan'
elif 'cfn-lint' in text:
    category = 'CloudFormation lint'
elif 'validate-template' in text:
    category = 'CloudFormation validation'
elif 'accessdenied' in text or 'access denied' in text:
    category = 'AWS permissions'
else:
    category = 'General pipeline failure'

lines = [ln for ln in raw.splitlines() if ln.strip()]
preview = '\n'.join(lines[-40:])
md = f"# Failure Analysis\n\n- **Category:** {category}\n- **Primary symptom:** pipeline step returned non-zero exit code or validation error.\n\n## Raw log excerpt\n\n```text\n{preview}\n```\n"
out.write_text(md, encoding='utf-8')
print(out)
