#!/usr/bin/env bash
set -euo pipefail

STACK_NAME="${1:?stack name required}"
REGION="${2:?region required}"

mkdir -p .artifacts
aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$REGION" > .artifacts/stack-description.json

SERVER_ID="$(python3 - <<'PY'
import json
with open('.artifacts/stack-description.json') as f:
    data = json.load(f)
for item in data['Stacks'][0].get('Outputs', []):
    if item['OutputKey'] == 'TransferServerId':
        print(item['OutputValue'])
        break
PY
)"

[ -n "$SERVER_ID" ] || { echo 'TransferServerId output not found'; exit 1; }
aws transfer describe-server --server-id "$SERVER_ID" --region "$REGION" > .artifacts/transfer-server.json
