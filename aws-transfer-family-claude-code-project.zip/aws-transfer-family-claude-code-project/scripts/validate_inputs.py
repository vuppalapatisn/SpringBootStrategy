#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
import yaml

BUCKET_RE = re.compile(r'^(AUTO|[a-z0-9][a-z0-9.-]{1,61}[a-z0-9])$')
ENVIRONMENTS = {'dev', 'test', 'prod'}
EXPECTED_SERVICE_CONNECTIONS = {
    'dev': 'aws-dev-sc',
    'test': 'aws-test-sc',
    'prod': 'aws-prod-sc',
}
MIN_RETENTION = {'dev': 10, 'test': 30, 'prod': 365}


def fail(msg):
    print(f'ERROR: {msg}', file=sys.stderr)
    sys.exit(1)


def load_params(path: Path):
    raw = json.loads(path.read_text())
    return {item['ParameterKey']: item['ParameterValue'] for item in raw}


def load_vars(path: Path):
    raw = yaml.safe_load(path.read_text())
    return raw.get('variables', {})


def validate_bucket(name: str, field: str):
    if not BUCKET_RE.match(name):
        fail(f"{field} value '{name}' is not a valid bucket name or AUTO")
    if '_' in name or '..' in name or '.-' in name or '-.' in name:
        fail(f"{field} value '{name}' contains invalid bucket naming patterns")


def main():
    if len(sys.argv) != 4:
        fail('Usage: validate_inputs.py <environment> <parameter-json> <variables-yaml>')
    env = sys.argv[1]
    params = load_params(Path(sys.argv[2]))
    vars_ = load_vars(Path(sys.argv[3]))

    if env not in ENVIRONMENTS:
        fail('Environment must be one of dev/test/prod')
    if params.get('EnvironmentName') != env:
        fail(f"Parameter EnvironmentName={params.get('EnvironmentName')} does not match requested environment={env}")

    validate_bucket(params.get('DataBucketName', ''), 'DataBucketName')
    validate_bucket(params.get('AuditBucketName', ''), 'AuditBucketName')

    retention = int(params.get('AuditRetentionDays', '0'))
    if retention < MIN_RETENTION[env]:
        fail(f'AuditRetentionDays={retention} is less than required minimum for {env} ({MIN_RETENTION[env]})')

    actual_sc = vars_.get('awsServiceConnection')
    expected_sc = EXPECTED_SERVICE_CONNECTIONS[env]
    if actual_sc != expected_sc:
        fail(f"Service connection mismatch for {env}: expected '{expected_sc}', found '{actual_sc}'")

    print('Input validation passed.')
    print(json.dumps({
        'environment': env,
        'awsServiceConnection': actual_sc,
        'retentionDays': retention,
    }, indent=2))


if __name__ == '__main__':
    main()
