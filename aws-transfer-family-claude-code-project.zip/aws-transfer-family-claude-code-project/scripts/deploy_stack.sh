#!/usr/bin/env bash
set -euo pipefail

ENVIRONMENT="${1:?environment required}"
STACK_NAME="${2:?stack name required}"
REGION="${3:?region required}"
PARAM_FILE="${4:?parameter file required}"
TEMPLATE_FILE="${5:-cloudformation/transfer-family-sftp.yml}"

ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
export AWS_ACCOUNT_ID="$ACCOUNT_ID"
mkdir -p .artifacts
python3 scripts/render_effective_params.py "$PARAM_FILE" "$ENVIRONMENT" .artifacts/effective-parameters.json >/dev/null

PARAM_OVERRIDES="$(python3 - <<'PY'
import json
params = json.load(open('.artifacts/effective-parameters.json'))
print(' '.join(f"{p['ParameterKey']}={p['ParameterValue']}" for p in params))
PY
)"

aws cloudformation deploy   --region "$REGION"   --template-file "$TEMPLATE_FILE"   --stack-name "$STACK_NAME"   --parameter-overrides $PARAM_OVERRIDES   --capabilities CAPABILITY_NAMED_IAM

aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$REGION" > .artifacts/stack-description.json
