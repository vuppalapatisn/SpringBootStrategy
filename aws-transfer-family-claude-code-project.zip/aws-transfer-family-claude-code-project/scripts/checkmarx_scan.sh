#!/usr/bin/env bash
set -euo pipefail

WORKDIR="${1:-.}"
mkdir -p .artifacts/checkmarx

if ! command -v cx >/dev/null 2>&1; then
  echo "Downloading Checkmarx CLI..."
  curl -fsSL https://github.com/Checkmarx/ast-cli/releases/latest/download/cx-linux64.tar.gz -o /tmp/cx-linux64.tar.gz
  tar -xzf /tmp/cx-linux64.tar.gz -C /tmp
  chmod +x /tmp/cx
  export PATH="/tmp:$PATH"
fi

export CX_BASE_URI="$CHECKMARX_BASE_URI"
export CX_TENANT="$CHECKMARX_TENANT"
export CX_APIKEY="$CHECKMARX_API_KEY"

PROJECT_NAME="${CHECKMARX_PROJECT_NAME:-transfer-family-sftp}"
BRANCH_NAME="${CHECKMARX_BRANCH_NAME:-local}"
FAIL_ON_RESULTS="${CHECKMARX_FAIL_ON_RESULTS:-true}"
EXTRA_ARGS="${CHECKMARX_ADDITIONAL_ARGS:---scan-types sast,sca,iac-security --report-format json --output-name .artifacts/checkmarx/checkmarx-result}"

set +e
cx scan create   --project-name "$PROJECT_NAME"   --branch "$BRANCH_NAME"   --source "$WORKDIR"   $EXTRA_ARGS   | tee .artifacts/checkmarx/checkmarx-console.log
STATUS=$?
set -e

if [ "$FAIL_ON_RESULTS" = "true" ] && [ "$STATUS" -ne 0 ]; then
  echo "Checkmarx scan failed with exit code $STATUS"
  exit "$STATUS"
fi
