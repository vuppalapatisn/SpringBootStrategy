#!/usr/bin/env python3
import json, os, sys
from pathlib import Path

if len(sys.argv) != 4:
    sys.stderr.write('Usage: render_effective_params.py <input.json> <environment> <output.json>\n')
    sys.exit(1)

input_file = Path(sys.argv[1])
environment = sys.argv[2]
output_file = Path(sys.argv[3])
params = json.loads(input_file.read_text())
account_id = os.environ.get('AWS_ACCOUNT_ID', '000000000000')
project_name = 'transfer-family'

for item in params:
    if item['ParameterKey'] == 'DataBucketName' and item['ParameterValue'] == 'AUTO':
        item['ParameterValue'] = f'{project_name}-{environment}-{account_id}-data'.lower()[:63].rstrip('-')
    if item['ParameterKey'] == 'AuditBucketName' and item['ParameterValue'] == 'AUTO':
        item['ParameterValue'] = f'{project_name}-{environment}-{account_id}-audit'.lower()[:63].rstrip('-')

output_file.write_text(json.dumps(params, indent=2))
print(output_file)
