---
description: Global repository rules
alwaysApply: true
---

- Use concise change sets.
- Explain root cause, impact, and proposed remediation when editing CI/CD or IaC files.
- Never remove audit logging, CloudTrail, GuardDuty, or retention controls unless explicitly requested.
- When changing user permissions, document the impact on all four user archetypes.
