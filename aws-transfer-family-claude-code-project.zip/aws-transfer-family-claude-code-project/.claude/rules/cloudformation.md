---
description: Rules for CloudFormation and IAM changes
globs:
  - cloudformation/**/*.yml
  - cloudformation/**/*.yaml
  - cfn-guard/**/*.guard
alwaysApply: false
---

- Keep templates idempotent and parameterized.
- Favor `DeletionPolicy: Retain` for immutable/audit resources.
- Model encryption, versioning, access logging, and public access blocks for all buckets.
- IAM policies should be least privilege and environment-safe.
