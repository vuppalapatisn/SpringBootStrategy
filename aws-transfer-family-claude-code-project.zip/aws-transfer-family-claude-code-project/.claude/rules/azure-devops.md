---
description: Rules for Azure DevOps YAML and deployment scripts
globs:
  - azure-pipelines.yml
  - .azuredevops/**/*.yml
  - scripts/**/*.sh
  - scripts/**/*.py
alwaysApply: false
---

- Pipelines must fail fast for validation/security gates.
- Development can invoke AI assistance on failure, but production must not auto-remediate.
- Always publish failure artifacts so humans can diagnose issues.
- Never echo secrets to logs.
- Keep service connection selection environment-specific and validated.
