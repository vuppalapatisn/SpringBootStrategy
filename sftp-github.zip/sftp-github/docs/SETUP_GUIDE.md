# GitHub Actions Setup Guide — AWS Transfer Family SFTP
# Complete step-by-step for DevOps administrators
# ═══════════════════════════════════════════════════════════════════════════════

## Prerequisites
- GitHub repository (admin access)
- AWS accounts: dev, test, prod (separate accounts recommended)
- Checkmarx account (CxOne or CxSAST)
- Anthropic API key: https://console.anthropic.com/

# ═══════════════════════════════════════════════════════════════════════════════
# PART 1: AWS IAM SETUP (repeat for each environment account)
# ═══════════════════════════════════════════════════════════════════════════════

## 1.1 Create IAM user for GitHub Actions (in each AWS account)

Go to: AWS Console → IAM → Users → Create user
  Name:        github-actions-sftp-deploy
  Access type: Programmatic access

Attach this policy (save as github-actions-policy.json and use AWS CLI):

aws iam create-policy \
  --policy-name GitHubActionsSftpDeploy \
  --policy-document file://docs/iam-policy.json

# The policy is in docs/iam-policy.json in this project.
# Attach it: IAM → Users → github-actions-sftp-deploy → Add permissions → Attach policies directly

## 1.2 Save the credentials
After creating the user, note:
  AWS_ACCESS_KEY_ID:     AKIAIOSFODNN7EXAMPLE
  AWS_SECRET_ACCESS_KEY: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY

You will need these for Step 2 below.

## 1.3 Option: Use OIDC instead of long-lived keys (recommended for production)

aws iam create-open-id-connect-provider \
  --url https://token.actions.githubusercontent.com \
  --client-id-list sts.amazonaws.com \
  --thumbprint-list 6938fd4d98bab03faadb97b34396831e3780aea1

Then create a role with trust policy:
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": { "Federated": "arn:aws:iam::ACCOUNT_ID:oidc-provider/token.actions.githubusercontent.com" },
    "Action": "sts:AssumeRoleWithWebIdentity",
    "Condition": {
      "StringEquals": {
        "token.actions.githubusercontent.com:aud": "sts.amazonaws.com"
      },
      "StringLike": {
        "token.actions.githubusercontent.com:sub": "repo:YOUR_ORG/YOUR_REPO:*"
      }
    }
  }]
}

# ═══════════════════════════════════════════════════════════════════════════════
# PART 2: GITHUB SECRETS SETUP
# ═══════════════════════════════════════════════════════════════════════════════

## 2.1 Navigate to: GitHub → Your Repo → Settings → Secrets and variables → Actions

## 2.2 Create Repository Secrets (click "New repository secret" for each)

### AWS Credentials — DEV account
Name:  AWS_ACCESS_KEY_ID_DEV
Value: (access key ID from Step 1.2 for DEV account)

Name:  AWS_SECRET_ACCESS_KEY_DEV
Value: (secret access key from Step 1.2 for DEV account)

### AWS Credentials — TEST account
Name:  AWS_ACCESS_KEY_ID_TEST
Value: (access key ID for TEST account)

Name:  AWS_SECRET_ACCESS_KEY_TEST
Value: (secret access key for TEST account)

### AWS Credentials — PROD account
Name:  AWS_ACCESS_KEY_ID_PROD
Value: (access key ID for PROD account)

Name:  AWS_SECRET_ACCESS_KEY_PROD
Value: (secret access key for PROD account)

### Checkmarx
Name:  CX_BASE_URI
Value: https://your-tenant.checkmarx.net   ← change this

Name:  CX_CLIENT_ID
Value: (from Checkmarx → Settings → API Keys)

Name:  CX_CLIENT_SECRET
Value: (from Checkmarx → Settings → API Keys)

Name:  CX_TENANT
Value: your-tenant-name

### Claude MCP Agent
Name:  CLAUDE_API_KEY
Value: sk-ant-YOUR_KEY_HERE   ← from https://console.anthropic.com/

## 2.3 Verify secrets are set
GitHub → Settings → Secrets → You should see 9 secrets listed.

# ═══════════════════════════════════════════════════════════════════════════════
# PART 3: GITHUB ENVIRONMENTS (for deployment approvals)
# ═══════════════════════════════════════════════════════════════════════════════

## 3.1 Create environments
GitHub → Your Repo → Settings → Environments → New environment

### dev environment
  Name: dev
  Protection rules: (none — auto-deploy)
  ✓ Save

### test environment
  Name: test
  Protection rules: (none — auto-deploy on release/* branch)
  ✓ Save

### prod environment
  Name: prod
  Protection rules:
    ✓ Required reviewers → Add your security/ops team members
    ✓ Restrict pushes that create matching branches
    Wait timer: 0 (or set 5 min for extra safety)
  ✓ Save

## 3.2 Verify
When a prod deployment is triggered, GitHub will pause and email the
reviewers. They click "Review deployments" → "Approve" in the GitHub UI.

# ═══════════════════════════════════════════════════════════════════════════════
# PART 4: UPDATE PARAMETER FILES
# ═══════════════════════════════════════════════════════════════════════════════

## 4.1 Edit cloudformation/parameters/dev.json
Replace every REPLACE_* placeholder:

  vpc-REPLACE_DEV_VPC     → vpc-0a1b2c3d4e5f67890  (your dev VPC ID)
  subnet-REPLACE_1        → subnet-0a1b2c3d4e5f6789  (subnet IDs)
  subnet-REPLACE_2        → subnet-1b2c3d4e5f678901
  devops-dev@example.com  → your real email

## 4.2 Same for test.json and prod.json

## 4.3 Validate locally before pushing
pip install cfn-lint
cfn-lint cloudformation/templates/sftp-main.yaml
python3 scripts/validate/validate_parameters.py \
  --params-file cloudformation/parameters/dev.json \
  --template-file cloudformation/templates/sftp-main.yaml \
  --environment dev

# ═══════════════════════════════════════════════════════════════════════════════
# PART 5: BRANCH STRATEGY
# ═══════════════════════════════════════════════════════════════════════════════

## The pipeline maps branches to environments:
##
##   Branch          → Environment  → Auto-deploy?
##   ─────────────────────────────────────────────
##   develop         → dev          → Yes
##   release/*       → test         → Yes
##   main            → prod         → After manual approval
##   feature/*       → (PR only)    → Validate only, no deploy
##   Pull requests   → (any base)   → Validate only, no deploy

## 5.1 Set up branch protection
GitHub → Settings → Branches → Add rule

  Branch name pattern: main
  ✓ Require a pull request before merging
  ✓ Require status checks to pass:
      → Add: "Validate CloudFormation"
      → Add: "Checkmarx SAST Scan"
  ✓ Require branches to be up to date before merging
  ✓ Restrict who can push to matching branches

  Branch name pattern: develop
  ✓ Require a pull request before merging
  ✓ Require status checks: "Validate CloudFormation"

# ═══════════════════════════════════════════════════════════════════════════════
# PART 6: FIRST DEPLOYMENT
# ═══════════════════════════════════════════════════════════════════════════════

## 6.1 Push to develop branch (auto-deploys to dev)
git checkout -b develop
git add .
git commit -m "feat: initial SFTP infrastructure"
git push origin develop

## 6.2 Monitor the pipeline
GitHub → Actions → SFTP Infrastructure Pipeline
You should see jobs: set-environment → validate → security-scan → plan → deploy

## 6.3 Verify SFTP server
After pipeline succeeds, go to:
  GitHub → Actions → Latest run → deploy job → "Deployment summary"
  You'll see the SFTP endpoint, bucket names, and connection command.

Test connection:
  sftp -i ~/.ssh/your-key sftp-rw-user01@{SftpEndpoint}

## 6.4 Deploy to test
git checkout -b release/1.0.0
git push origin release/1.0.0
→ Pipeline auto-deploys to test

## 6.5 Deploy to prod
git checkout main
git merge release/1.0.0
git push origin main
→ Pipeline runs validate + scan + plan → PAUSES for approval
→ Reviewers receive email notification
→ They visit GitHub → Actions → Review deployments → Approve
→ Deploy job executes

# ═══════════════════════════════════════════════════════════════════════════════
# PART 7: UNDERSTANDING CHECKMARX FAILURE + CLAUDE AGENT
# ═══════════════════════════════════════════════════════════════════════════════

## What happens when Checkmarx fails:
##
## 1. security-scan job: cx-scan step fails
##    → gate step sets scan-passed=false
##    → SARIF uploaded to GitHub Security tab
##
## 2. claude-remediation job triggers (because scan-passed=false)
##    → Downloads SARIF report
##    → Runs .github/actions/claude-agent/run_agent.py
##    → For each finding, calls Claude API:
##        - What is wrong (plain English explanation)
##        - What the impact is
##        - How to fix it (step-by-step with CloudFormation examples)
##        - Fixed code (if auto-patchable)
##    → If patches exist, creates branch: agent/cx-fix-{env}-{run_id}
##    → Opens PR with all findings, explanations, and fixes
##    → Writes GitHub Actions step summary with full report
##
## 3. Pipeline FAILS (exits 1) — blocks deployment
##
## 4. Developer sees:
##    a) Actions tab: claude-remediation job summary with all errors
##    b) Pull Requests tab: new PR "fix(security): Claude agent..."
##       Each finding has:
##         - What is wrong
##         - Impact
##         - How to fix
##         - Auto-applied patch (if applicable)
##    c) Security tab: SARIF findings highlighted in code
##
## 5. Developer reviews PR, applies manual fixes if needed, merges
## 6. Merging the fix PR triggers the pipeline again
## 7. Checkmarx re-scans — if passes, deployment continues

## Common findings and what Claude says about them:
##
## INSECURE_BUCKET_POLICY:
##   What:   S3 bucket does not enforce HTTPS — data can be transmitted unencrypted
##   Fix:    Add bucket policy with Deny on aws:SecureTransport=false
##
## MISSING_ENCRYPTION:
##   What:   S3 bucket has no server-side encryption configured
##   Fix:    Add BucketEncryption with aws:kms and specify KMSMasterKeyID
##
## OVERLY_PERMISSIVE_IAM:
##   What:   IAM policy uses wildcard resource (*) — violates least privilege
##   Fix:    Scope Resource to specific ARNs
##
## UNRESTRICTED_PORT_22:
##   What:   Security group allows port 22 from 0.0.0.0/0
##   Fix:    Change CidrIp to specific allowed CIDR ranges
##
## PUBLIC_BUCKET_ACCESS:
##   What:   PublicAccessBlockConfiguration is missing or incomplete
##   Fix:    Add all four BlockPublic* settings set to true

# ═══════════════════════════════════════════════════════════════════════════════
# PART 8: ADDING SFTP USERS
# ═══════════════════════════════════════════════════════════════════════════════

## User types summary:
##   readwrite:       Can list, download, upload (cannot delete)
##   readwritedelete: Can list, download, upload, delete
##   writeonly:       Can upload only (cannot list or download)
##   readonly:        Can list and download only

## To add a new user:
## 1. Generate SSH key pair:
ssh-keygen -t ed25519 -f sftp-newuser -C "sftp-newuser@yourcompany.com"

## 2. Add to cloudformation/templates/sftp-main.yaml:
##    Copy an existing user block (e.g. SftpUserReadWrite) and change:
##      LogicalResourceId: SftpUserReadWrite02
##      UserName:          sftp-rw-user02
##      HomeDirectoryMappings Target: /${SftpBucketName}/readwrite/sftp-rw-user02

## 3. Add SshPublicKeys to the user resource:
##      SshPublicKeys:
##        - "ssh-ed25519 AAAAC3Nza... sftp-newuser@company.com"

## 4. Commit and push — pipeline deploys the new user

## 5. Send the PRIVATE key to the user via secure channel (not email)

## SFTP connection:
sftp -i ~/.ssh/sftp-newuser sftp-rw-user02@{SftpEndpoint}

# ═══════════════════════════════════════════════════════════════════════════════
# PART 9: TROUBLESHOOTING
# ═══════════════════════════════════════════════════════════════════════════════

## Pipeline fails on "Validate AWS credentials config"
→ Check: secret names match exactly (AWS_ACCESS_KEY_ID_DEV not AWS_ACCESS_KEY_ID)
→ Check: IAM user has the required permissions (see docs/iam-policy.json)
→ Test locally: export AWS_ACCESS_KEY_ID=... && aws sts get-caller-identity

## cfn-lint fails with W3045
→ This is a warning about Transfer Family log destinations. Add to cfn-lint config:
   echo "ignore_checks: [W3045]" > .cfnlintrc.yaml

## Checkmarx scan times out
→ Increase the timeout in the workflow: add timeout-minutes: 60 to cx-scan step
→ Check Checkmarx server health at your CX_BASE_URI

## Claude agent PR not created
→ Verify CLAUDE_API_KEY is set correctly in GitHub secrets
→ Check: Actions → claude-remediation job → logs for "Claude API error"
→ The fix PR still fails the pipeline even without Claude — check Security tab

## Stack creation fails on LogsBucket
→ S3 Object Lock requires versioning. Both are enabled — check if bucket already
   exists without Object Lock (cannot add retroactively — delete and recreate)

## GuardDuty already enabled error
→ Add a condition to skip GuardDuty if already enabled, or import existing detector:
   aws guardduty list-detectors → note the ID → use cfn import
