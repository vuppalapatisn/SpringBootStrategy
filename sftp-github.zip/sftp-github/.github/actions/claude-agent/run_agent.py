#!/usr/bin/env python3
"""
.github/actions/claude-agent/run_agent.py

Claude MCP Security Fix Agent for GitHub Actions.
Reads Checkmarx SARIF → calls Anthropic API → creates fix PR.

Outputs:
  reports/claude-remediation.json  — full structured report
  GitHub PR with fix branch         — opened via GitHub REST API
"""
import argparse
import json
import os
import sys
import re
import base64
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime


# ── CONFIG ─────────────────────────────────────────────────────────────────────
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
MODEL         = "claude-sonnet-4-6"
GITHUB_API    = "https://api.github.com"

CLAUDE_API_KEY = os.environ.get("CLAUDE_API_KEY", "")
GITHUB_TOKEN   = os.environ.get("GITHUB_TOKEN", "")
REPO           = os.environ.get("REPO", "")
BASE_BRANCH    = os.environ.get("BASE_BRANCH", "main")
RUN_ID         = os.environ.get("RUN_ID", "0")
ENVIRONMENT    = os.environ.get("ENVIRONMENT", "dev")

AUTO_FIX_RULES = {
    "INSECURE_BUCKET_POLICY", "MISSING_ENCRYPTION", "PUBLIC_BUCKET_ACCESS",
    "HARDCODED_CREDENTIALS", "OVERLY_PERMISSIVE_IAM", "MISSING_MFA_DELETE",
    "MISSING_VERSIONING", "UNRESTRICTED_PORT_22", "MISSING_SSL_ENFORCEMENT",
    "MISSING_KMS_ENCRYPTION", "LOG_INJECTION", "PATH_TRAVERSAL",
    "SQL_INJECTION", "REFLECTED_XSS", "MISSING_OBJECT_LOCK",
    "CLOUDTRAIL_NOT_ENABLED", "GUARDDUTY_NOT_ENABLED",
}


# ── SARIF PARSER ───────────────────────────────────────────────────────────────
def parse_sarif_dir(sarif_dir: str) -> list:
    findings = []
    for f in Path(sarif_dir).glob("**/*.sarif"):
        try:
            data = json.loads(f.read_text())
            for run in data.get("runs", []):
                rules = {
                    r["id"]: r
                    for r in run.get("tool", {}).get("driver", {}).get("rules", [])
                }
                for result in run.get("results", []):
                    rule_id  = result.get("ruleId", "UNKNOWN")
                    rule_def = rules.get(rule_id, {})
                    message  = result.get("message", {}).get("text", "")
                    level    = result.get("level", "warning")
                    severity = {"error": "high", "warning": "medium", "note": "low"}.get(level, "medium")

                    for loc in result.get("locations", []):
                        phys = loc.get("physicalLocation", {})
                        findings.append({
                            "rule_id":    rule_id,
                            "rule_name":  rule_def.get("name", rule_id),
                            "severity":   severity,
                            "message":    message,
                            "file_path":  phys.get("artifactLocation", {}).get("uri", "unknown"),
                            "line":       phys.get("region", {}).get("startLine", 0),
                            "help_uri":   rule_def.get("helpUri", ""),
                        })
        except Exception as e:
            print(f"[agent] Warning: could not parse {f}: {e}")
    return findings


# ── CLAUDE API ─────────────────────────────────────────────────────────────────
def ask_claude(finding: dict, source_code: str) -> dict:
    rule_id   = finding["rule_id"]
    severity  = finding["severity"]
    file_path = finding["file_path"]
    line      = finding["line"]
    message   = finding["message"]

    source_section = ""
    if source_code:
        lines    = source_code.splitlines()
        start    = max(0, line - 15)
        end      = min(len(lines), line + 15)
        snippet  = "\n".join(
            f"{i+1:4d} {'>>>' if i + 1 == line else '   '} {l}"
            for i, l in enumerate(lines[start:end], start=start)
        )
        source_section = f"\n\nAffected code (line {line} flagged with >>>) :\n```yaml\n{snippet}\n```\n\nFull file:\n```yaml\n{source_code[:6000]}\n```"

    prompt = f"""Checkmarx SAST found a security vulnerability. Provide a complete analysis and fix.

## Vulnerability
- Rule:        {rule_id}
- Severity:    {severity.upper()}
- File:        {file_path}
- Line:        {line}
- Environment: {ENVIRONMENT}
- Message:     {message}
{source_section}

Return ONLY this JSON (no markdown fences, no preamble, no trailing text):
{{
  "what_is_wrong": "Plain-English explanation of the vulnerability and why it is a security risk",
  "impact": "What an attacker could do if this is exploited",
  "how_to_fix": "Step-by-step remediation with specific CloudFormation YAML examples",
  "fixed_code": "Complete corrected file content if source was provided, else empty string",
  "auto_fixable": true or false,
  "severity_explanation": "Why this severity level was assigned",
  "references": ["https://docs.aws.amazon.com/...", "https://cwe.mitre.org/..."]
}}"""

    payload = json.dumps({
        "model":      MODEL,
        "max_tokens": 4096,
        "system": (
            "You are a senior AWS security engineer specialising in CloudFormation IaC security. "
            "Return only valid JSON. No markdown. No explanations outside the JSON."
        ),
        "messages": [{"role": "user", "content": prompt}]
    }).encode()

    req = urllib.request.Request(
        ANTHROPIC_URL,
        data=payload,
        headers={
            "x-api-key":         CLAUDE_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type":      "application/json",
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read())
            text = data["content"][0]["text"].strip()
            # Strip accidental fences
            if text.startswith("```"):
                text = re.sub(r"^```[a-z]*\n?", "", text)
                text = re.sub(r"\n?```$",        "", text)
            return json.loads(text)
    except Exception as e:
        return {
            "what_is_wrong":        f"Checkmarx flagged {rule_id}: {message}",
            "impact":               "See Checkmarx report for impact details",
            "how_to_fix":           f"Claude was unavailable ({e}). Review the SARIF manually.",
            "fixed_code":           "",
            "auto_fixable":         False,
            "severity_explanation": "See Checkmarx report",
            "references":           ["https://docs.aws.amazon.com/securityhub/latest/userguide/"],
            "error":                str(e),
        }


# ── GITHUB API ─────────────────────────────────────────────────────────────────
def github_request(method: str, path: str, body: dict = None) -> dict:
    url     = f"{GITHUB_API}/{path}"
    data    = json.dumps(body).encode() if body else None
    req     = urllib.request.Request(
        url, data=data, method=method,
        headers={
            "Authorization": f"Bearer {GITHUB_TOKEN}",
            "Accept":        "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "Content-Type":  "application/json",
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read()) if resp.status != 204 else {}
    except urllib.error.HTTPError as e:
        print(f"[github] HTTP {e.code} on {method} {url}: {e.read().decode()[:300]}")
        return {}


def get_file_content(file_path: str) -> str:
    resp = github_request("GET",
        f"repos/{REPO}/contents/{file_path}?ref={BASE_BRANCH}")
    if resp and "content" in resp:
        try:
            return base64.b64decode(resp["content"]).decode("utf-8")
        except Exception:
            pass
    return ""


def create_fix_pr(patches: list, fix_report: list) -> str:
    if not patches or not REPO or not GITHUB_TOKEN:
        return ""

    fix_branch = f"agent/cx-fix-{ENVIRONMENT}-{RUN_ID}"

    # Get base branch SHA
    ref_resp = github_request("GET", f"repos/{REPO}/git/ref/heads/{BASE_BRANCH}")
    base_sha = ref_resp.get("object", {}).get("sha", "")
    if not base_sha:
        print("[github] Could not get base branch SHA")
        return ""

    # Create fix branch
    github_request("POST", f"repos/{REPO}/git/refs", {
        "ref": f"refs/heads/{fix_branch}",
        "sha": base_sha
    })

    # Commit each patch
    for patch in patches:
        existing = github_request("GET",
            f"repos/{REPO}/contents/{patch['file_path']}?ref={fix_branch}")
        file_sha = existing.get("sha", "")

        content_b64 = base64.b64encode(patch["fixed_code"].encode()).decode()
        body = {
            "message": f"fix(security): auto-remediate {patch['rule_id']} [{ENVIRONMENT}] run {RUN_ID}",
            "content": content_b64,
            "branch":  fix_branch,
        }
        if file_sha:
            body["sha"] = file_sha

        github_request("PUT", f"repos/{REPO}/contents/{patch['file_path']}", body)

    # Build PR description
    pr_body = _build_pr_body(fix_report)

    pr_resp = github_request("POST", f"repos/{REPO}/pulls", {
        "title": f"fix(security): Claude agent — Checkmarx fixes [{ENVIRONMENT}] run {RUN_ID}",
        "body":  pr_body,
        "head":  fix_branch,
        "base":  BASE_BRANCH,
        "labels": ["security-autofix", "claude-agent"],
    })
    return pr_resp.get("html_url", "")


def _build_pr_body(fix_report: list) -> str:
    lines = [
        f"## Claude MCP Security Fix Agent — Run {RUN_ID} ({ENVIRONMENT})",
        "",
        "Checkmarx SAST found security vulnerabilities. This PR contains Claude-generated fixes.",
        "**Review carefully before merging. Re-run the pipeline on this branch to verify.**",
        "",
        "---",
        "",
    ]
    for i, item in enumerate(fix_report, 1):
        f = item.get("finding", {})
        lines += [
            f"### Finding {i} — `{f.get('rule_id','?')}` ({f.get('severity','?').upper()})",
            f"**File:** `{item.get('file_path','?')}` | **Line:** {item.get('line','?')}",
            "",
            "#### What is wrong",
            item.get("what_is_wrong", "_Not available_"),
            "",
            "#### Impact",
            item.get("impact", "_Not available_"),
            "",
            "#### How to fix",
            item.get("how_to_fix", "_Not available_"),
            "",
            f"**Auto-applied:** {'✅ Yes' if item.get('auto_fixable') else '❌ No — manual review required'}",
            "",
            "---",
            "",
        ]
    return "\n".join(lines)


# ── MAIN ───────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sarif-dir",    required=True)
    parser.add_argument("--template-dir", required=True)
    parser.add_argument("--environment",  required=True)
    parser.add_argument("--output-file",  default="reports/claude-remediation.json")
    args = parser.parse_args()

    print(f"\n{'═'*55}")
    print(f"  Claude MCP Security Fix Agent")
    print(f"  Environment: {args.environment} | Run: {RUN_ID}")
    print(f"{'═'*55}\n")

    # Parse SARIF
    findings = parse_sarif_dir(args.sarif_dir)
    print(f"  Parsed {len(findings)} finding(s) from SARIF reports")

    if not findings:
        print("  No findings — nothing to fix")
        result = {"total": 0, "auto_fixed": 0, "report": [], "pr_url": ""}
        Path(args.output_file).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output_file).write_text(json.dumps(result, indent=2))
        return

    patches    = []
    fix_report = []

    for finding in findings:
        print(f"\n  → Analysing: {finding['rule_id']} ({finding['severity']}) in {finding['file_path']}")

        # Try to get source
        source = get_file_content(finding["file_path"])
        if not source and Path(finding["file_path"]).exists():
            source = Path(finding["file_path"]).read_text()

        suggestion = ask_claude(finding, source)

        item = {
            "finding":              finding,
            "file_path":            finding["file_path"],
            "line":                 finding["line"],
            "what_is_wrong":        suggestion.get("what_is_wrong", ""),
            "impact":               suggestion.get("impact", ""),
            "how_to_fix":           suggestion.get("how_to_fix", ""),
            "severity_explanation": suggestion.get("severity_explanation", ""),
            "references":           suggestion.get("references", []),
            "auto_fixable":         suggestion.get("auto_fixable", False),
            "fixed_code":           suggestion.get("fixed_code", ""),
        }
        fix_report.append(item)

        if suggestion.get("auto_fixable") and suggestion.get("fixed_code"):
            patches.append({
                "file_path":  finding["file_path"],
                "fixed_code": suggestion["fixed_code"],
                "rule_id":    finding["rule_id"],
            })
            print(f"    ✅ Auto-fix generated")
        else:
            print(f"    ⚠️  Manual review required")

    # Open fix PR
    pr_url = ""
    if patches:
        print(f"\n  Creating fix PR with {len(patches)} patch(es)...")
        pr_url = create_fix_pr(patches, fix_report)
        if pr_url:
            print(f"  ✅ Fix PR: {pr_url}")
        else:
            print(f"  ⚠️  Could not create PR — apply patches manually")

    # Write report
    report = {
        "timestamp":   datetime.utcnow().isoformat(),
        "environment": args.environment,
        "run_id":      RUN_ID,
        "total":       len(findings),
        "auto_fixed":  len(patches),
        "manual_needed": len(findings) - len(patches),
        "pr_url":      pr_url,
        "report":      fix_report,
        "summary": (
            f"Checkmarx found {len(findings)} issue(s). "
            f"{len(patches)} auto-patched, {len(findings)-len(patches)} need manual review."
        )
    }
    Path(args.output_file).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output_file).write_text(json.dumps(report, indent=2))
    print(f"\n  📄 Report: {args.output_file}")
    print(f"{'═'*55}\n")


if __name__ == "__main__":
    main()
