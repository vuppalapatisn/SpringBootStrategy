# AWS Transfer Family SFTP — GitHub Actions Project

Production-ready SFTP server backed by S3, deployed via GitHub Actions with
Checkmarx security scanning and Claude MCP agent auto-remediation.

## Pipeline flow

```
Push / PR
    │
    ▼
set-environment ──► Resolve env from branch (develop→dev, release/*→test, main→prod)
    │
    ▼
validate ──────────► cfn-lint + cfn-nag + parameter validation + bucket checks + AWS config
    │
    ▼
security-scan ─────► Checkmarx SAST ──[FAIL]──► SARIF to GitHub Security tab
    │                                                        │
    │  [PASS]                                                ▼
    ▼                                           claude-remediation
plan ──────────────► CloudFormation change set      │
    │               (shows what will change)        ├─ Parse SARIF
    ▼                                               ├─ Call Claude API per finding:
deploy ─────────────► Execute change set               │  • What is wrong
    │               → Wait for completion             │  • Impact
    ▼               → Post-deploy verify              │  • How to fix
Summary                                              │  • Fixed code
                                                     ├─ Create fix PR in GitHub
                                                     └─ Write Actions step summary
```

## SFTP User Types

| Type | Read | Write | Delete | Home directory |
|---|---|---|---|---|
| `readwrite` | ✅ | ✅ | ❌ | `/bucket/readwrite/username/` |
| `readwritedelete` | ✅ | ✅ | ✅ | `/bucket/readwritedelete/username/` |
| `writeonly` | ❌ | ✅ | ❌ | `/bucket/writeonly/username/` |
| `readonly` | ✅ | ❌ | ❌ | `/bucket/readonly/username/` |

## Log retention (Object Lock GOVERNANCE mode)

| Environment | Retention |
|---|---|
| prod | 365 days |
| test | 30 days |
| dev | 10 days |

## Security features
- S3: KMS encryption, versioning, public access blocked, SSL-only bucket policy
- SFTP: VPC endpoint only, security group scoped to allowed CIDRs
- IAM: least-privilege per user type, logical home directory mapping
- GuardDuty: S3 + CloudTrail data sources enabled, env-appropriate finding frequency
- CloudTrail: all S3 data events, log file validation, multi-region on prod
- Logs bucket: separate from data, Object Lock GOVERNANCE, KMS encrypted
- CloudWatch alarm: SFTP auth failure rate (5 in prod, 20 in dev)

## Project structure

```
.
├── .github/
│   ├── workflows/
│   │   └── sftp-pipeline.yml        # Main CI/CD pipeline
│   └── actions/claude-agent/
│       ├── run_agent.py             # Claude MCP agent
│       └── post_summary.py          # GitHub Actions step summary
├── cloudformation/
│   ├── templates/sftp-main.yaml     # Main CloudFormation template
│   └── parameters/
│       ├── dev.json
│       ├── test.json
│       └── prod.json
├── scripts/
│   ├── validate/
│   │   ├── validate_parameters.py
│   │   ├── validate_buckets.py
│   │   └── validate_aws_config.py
│   └── deploy/
│       ├── describe_changeset.py
│       ├── post_deploy_verify.py
│       └── deployment_summary.py
└── docs/
    ├── SETUP_GUIDE.md               # Complete admin setup guide
    └── iam-policy.json              # IAM policy for GitHub Actions user
```

## Quick start

1. Read `docs/SETUP_GUIDE.md` completely
2. Replace all `REPLACE_*` values in `cloudformation/parameters/*.json`
3. Add 9 GitHub secrets (AWS keys × 3 envs + Checkmarx × 4 + Claude × 1)
4. Create `dev`, `test`, `prod` environments in GitHub Settings
5. Set branch protection rules on `main`
6. Push to `develop` → pipeline auto-deploys to dev
