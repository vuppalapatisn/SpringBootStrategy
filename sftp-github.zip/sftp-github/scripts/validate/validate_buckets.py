#!/usr/bin/env python3
"""validate_buckets.py — validates S3 bucket naming and separation rules."""
import argparse, json, re, sys
from pathlib import Path

BUCKET_RE = re.compile(r'^[a-z0-9][a-z0-9\-]{1,61}[a-z0-9]$')
ERRORS = []; WARNS = []

def err(m):  ERRORS.append(m); print(f"  ❌  {m}")
def warn(m): WARNS.append(m);  print(f"  ⚠️   {m}")
def ok(m):                      print(f"  ✅  {m}")

def check(name, key, env, project):
    print(f"\n  {key}: '{name}'")
    if not name or "REPLACE" in name:
        err(f"{key} is a placeholder — replace with a real bucket name"); return
    if not BUCKET_RE.match(name):
        err(f"{key}='{name}' violates S3 naming rules (3-63 chars, lowercase, hyphens)")
    else: ok("Format valid")
    if env not in name:
        err(f"{key} must contain environment '{env}' to prevent cross-env accidents")
    else: ok(f"Environment '{env}' in name")
    if project and project not in name:
        warn(f"{key} does not contain project '{project}' — recommended for clarity")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--params-file"); ap.add_argument("--environment")
    args = ap.parse_args()
    raw = json.loads(Path(args.params_file).read_text())
    p   = {x["ParameterKey"]: x["ParameterValue"] for x in raw}
    project = p.get("ProjectName","")

    print(f"\n{'═'*50}\n  Bucket Validation — {args.environment}\n{'═'*50}")

    sftp = p.get("SftpBucketName",""); logs = p.get("LogsBucketName","")
    check(sftp, "SftpBucketName", args.environment, project)
    check(logs, "LogsBucketName", args.environment, project)

    if sftp and logs:
        print(f"\n  Bucket separation check:")
        if sftp == logs:
            err("SftpBucketName and LogsBucketName MUST be different buckets")
        else:
            ok("Data and logs use separate buckets")

    print(f"\n{'═'*50}")
    if ERRORS:
        print(f"  ❌ {len(ERRORS)} error(s)"); sys.exit(1)
    print(f"  ✅ All bucket validations passed")

if __name__ == "__main__": main()
