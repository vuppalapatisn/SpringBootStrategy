#!/usr/bin/env python3
"""validate_parameters.py — validates CFN parameter files with JUnit output."""
import argparse, json, re, sys, os
from pathlib import Path
from datetime import datetime
import xml.etree.ElementTree as ET

REQUIRED = [
    "Environment","ProjectName","SftpBucketName","LogsBucketName",
    "VpcId","SubnetIds","AllowedCidrBlocks","NotificationEmail",
    "EnableGuardDuty","EnableCloudTrail",
]
PROD_REQUIRED = ["SftpCustomHostname","HostedZoneId"]
RESULTS = []

def ok(name, msg):
    RESULTS.append({"name": name, "passed": True, "msg": msg})
    print(f"  ✅  {name}: {msg}")

def fail(name, msg, detail=""):
    RESULTS.append({"name": name, "passed": False, "msg": msg, "detail": detail})
    print(f"  ❌  {name}: {msg}")
    if detail: print(f"       {detail}")

def load(path):
    raw = json.loads(Path(path).read_text())
    return {p["ParameterKey"]: p["ParameterValue"] for p in raw}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--params-file");   ap.add_argument("--template-file")
    ap.add_argument("--environment");   ap.add_argument("--project", default="")
    args = ap.parse_args()

    print(f"\n{'═'*50}\n  Parameter Validation — {args.environment}\n{'═'*50}")
    p = load(args.params_file)

    # Required params
    for k in REQUIRED:
        if not p.get(k):
            fail(f"required/{k}", f"Missing or empty")
        else:
            ok(f"required/{k}", p[k][:40])

    # Prod-only params
    if args.environment == "prod":
        for k in PROD_REQUIRED:
            v = p.get(k, "")
            if not v or "REPLACE" in v:
                fail(f"prod_required/{k}", f"Required for prod, got: '{v}'")
            else:
                ok(f"prod_required/{k}", v[:40])

    # Environment consistency
    env_p = p.get("Environment","")
    if env_p != args.environment:
        fail("env/match", f"Mismatch: param='{env_p}' arg='{args.environment}'")
    else:
        ok("env/match", env_p)

    # VPC ID format
    vpc = p.get("VpcId","")
    if "REPLACE" in vpc:
        fail("network/vpc", f"Placeholder not replaced: {vpc}")
    elif not re.match(r'^vpc-[a-f0-9]{8,17}$', vpc):
        fail("network/vpc", f"Invalid format: {vpc}", "Expected: vpc-[hex8-17]")
    else:
        ok("network/vpc", vpc)

    # Email
    email = p.get("NotificationEmail","")
    if not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$', email):
        fail("email/notification", f"Invalid: {email}")
    else:
        ok("email/notification", email)

    # Booleans
    for k in ["EnableGuardDuty","EnableCloudTrail"]:
        v = p.get(k,"")
        if v not in ("true","false"):
            fail(f"bool/{k}", f"Must be true/false, got: {v}")
        else:
            ok(f"bool/{k}", v)

    # Write JUnit
    os.makedirs("reports", exist_ok=True)
    suite = ET.Element("testsuite", name="ParameterValidation",
        tests=str(len(RESULTS)),
        failures=str(sum(1 for r in RESULTS if not r["passed"])),
        timestamp=datetime.utcnow().isoformat())
    for r in RESULTS:
        c = ET.SubElement(suite, "testcase", name=r["name"], classname="validate_parameters")
        if not r["passed"]:
            f = ET.SubElement(c, "failure", message=r["msg"])
            f.text = r.get("detail","")
    ET.ElementTree(suite).write("reports/test-results.xml", encoding="utf-8", xml_declaration=True)

    failures = sum(1 for r in RESULTS if not r["passed"])
    print(f"\n{'═'*50}\n  {len(RESULTS)-failures}/{len(RESULTS)} passed\n{'═'*50}")
    sys.exit(1 if failures else 0)

if __name__ == "__main__": main()
