#!/usr/bin/env python3
"""validate_aws_config.py — checks AWS credentials are reachable before deploy."""
import argparse, subprocess, sys, json

VALID_REGIONS = {
    "us-east-1","us-east-2","us-west-1","us-west-2",
    "eu-west-1","eu-west-2","eu-central-1",
    "ap-southeast-1","ap-southeast-2","ap-northeast-1",
    "ca-central-1",
}

def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode, r.stdout.strip(), r.stderr.strip()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--environment"); ap.add_argument("--region")
    args = ap.parse_args()

    print(f"\n{'═'*50}\n  AWS Config Validation — {args.environment}\n{'═'*50}")
    errors = []

    # Region check
    if args.region not in VALID_REGIONS:
        print(f"  ⚠️  Region '{args.region}' not in known list — verify Transfer Family availability")
    else:
        print(f"  ✅  Region: {args.region}")

    # Caller identity
    rc, out, err = run(["aws", "sts", "get-caller-identity", "--output", "json"])
    if rc != 0:
        errors.append(f"AWS credentials invalid or not configured: {err}")
        print(f"  ❌  STS call failed: {err}")
    else:
        identity = json.loads(out)
        account  = identity.get("Account","?")
        arn      = identity.get("Arn","?")
        print(f"  ✅  AWS identity: {arn}")
        print(f"  ✅  Account: {account}")

        # Prod guard: warn if the arn looks like a dev/test principal
        if args.environment == "prod":
            if any(x in arn.lower() for x in ["dev","test","sandbox"]):
                errors.append(
                    f"CRITICAL: deploying to PROD but IAM principal looks like non-prod: {arn}"
                )

    print(f"\n{'═'*50}")
    if errors:
        for e in errors: print(f"  ❌  {e}")
        sys.exit(1)
    print("  ✅  AWS config valid")

if __name__ == "__main__": main()
