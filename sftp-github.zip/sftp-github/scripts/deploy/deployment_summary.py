#!/usr/bin/env python3
"""deployment_summary.py — prints stack outputs and SFTP endpoint to Actions summary."""
import argparse, boto3, os, sys

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stack-name"); ap.add_argument("--region")
    args = ap.parse_args()

    cfn = boto3.client("cloudformation", region_name=args.region)
    try:
        stack   = cfn.describe_stacks(StackName=args.stack_name)["Stacks"][0]
        outputs = {o["OutputKey"]:o["OutputValue"] for o in stack.get("Outputs",[])}
    except Exception as e:
        print(f"Cannot get stack outputs: {e}"); sys.exit(0)

    summary_file = os.environ.get("GITHUB_STEP_SUMMARY", "/dev/stdout")
    endpoint     = outputs.get("SftpEndpoint","N/A")
    server_id    = outputs.get("SftpServerId","N/A")

    lines = [
        f"# Deployment Complete: {args.stack_name}",
        "",
        "## SFTP Connection Details",
        f"| Item | Value |",
        f"|------|-------|",
        f"| Endpoint | `{endpoint}` |",
        f"| Server ID | `{server_id}` |",
        f"| Data Bucket | `{outputs.get('SftpDataBucketArn','N/A').split(':::')[-1]}` |",
        f"| Logs Bucket | `{outputs.get('LogsBucketArn','N/A').split(':::')[-1]}` |",
        "",
        "## SFTP Connection Command",
        f"```bash",
        f"sftp -i ~/.ssh/your-private-key.pem sftp-rw-user01@{endpoint}",
        f"```",
        "",
        "## User Types",
        "| Type | Read | Write | Delete | Home Path |",
        "|------|------|-------|--------|-----------|",
        "| readwrite | ✅ | ✅ | ❌ | `/bucket/readwrite/username/` |",
        "| readwritedelete | ✅ | ✅ | ✅ | `/bucket/readwritedelete/username/` |",
        "| writeonly | ❌ | ✅ | ❌ | `/bucket/writeonly/username/` |",
        "| readonly | ✅ | ❌ | ❌ | `/bucket/readonly/username/` |",
    ]
    with open(summary_file,"w") as f:
        f.write("\n".join(lines))
    print("✅ Deployment summary written")
    print(f"\n  SFTP endpoint: {endpoint}")

if __name__ == "__main__": main()
