#!/usr/bin/env python3
"""post_deploy_verify.py — checks stack outputs and SFTP server state after deploy."""
import argparse, boto3, json, os, sys
from datetime import datetime

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stack-name"); ap.add_argument("--environment")
    ap.add_argument("--region");     ap.add_argument("--output-file", default="reports/post-deploy.json")
    args = ap.parse_args()

    os.makedirs("reports", exist_ok=True)
    errors = {}; results = {}

    cfn  = boto3.client("cloudformation", region_name=args.region)
    s3   = boto3.client("s3",             region_name=args.region)
    xfer = boto3.client("transfer",       region_name=args.region)

    print(f"\n{'═'*50}\n  Post-Deploy Verification: {args.stack_name}\n{'═'*50}")

    # Stack status
    try:
        stack   = cfn.describe_stacks(StackName=args.stack_name)["Stacks"][0]
        status  = stack["StackStatus"]
        outputs = {o["OutputKey"]:o["OutputValue"] for o in stack.get("Outputs",[])}
        results["stack_status"] = status
        results["outputs"]      = outputs
        if status.endswith("_COMPLETE"):
            print(f"  ✅  Stack: {status}")
        else:
            errors["stack"] = f"Status is {status}"
            print(f"  ❌  Stack: {status}")
    except Exception as e:
        errors["stack"] = str(e); outputs = {}
        print(f"  ❌  Cannot describe stack: {e}")

    # SFTP server
    server_id = outputs.get("SftpServerId","")
    if server_id:
        try:
            state = xfer.describe_server(ServerId=server_id)["Server"]["State"]
            results["sftp_state"] = state
            if state == "ONLINE":
                print(f"  ✅  SFTP server {server_id}: ONLINE")
            else:
                errors["sftp"] = f"Server state: {state}"
                print(f"  ⚠️   SFTP server state: {state}")
        except Exception as e:
            errors["sftp"] = str(e); print(f"  ❌  SFTP check: {e}")

    # Buckets
    for key in ["SftpDataBucketArn","LogsBucketArn"]:
        arn = outputs.get(key,"")
        if arn:
            bucket = arn.split(":::")[-1]
            try:
                s3.head_bucket(Bucket=bucket)
                print(f"  ✅  Bucket '{bucket}' accessible")
                results[key] = "ok"
            except Exception as e:
                errors[key] = str(e); print(f"  ❌  Bucket '{bucket}': {e}")

    report = {"stack":args.stack_name,"env":args.environment,
              "timestamp":datetime.utcnow().isoformat(),
              "errors":errors,"results":results}
    with open(args.output_file,"w") as f:
        json.dump(report, f, indent=2)

    print(f"\n{'═'*50}")
    if errors:
        print(f"  ❌ {len(errors)} check(s) failed"); sys.exit(1)
    print("  ✅  All post-deploy checks passed")

if __name__ == "__main__": main()
