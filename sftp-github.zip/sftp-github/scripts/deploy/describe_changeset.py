#!/usr/bin/env python3
"""describe_changeset.py — waits for change set and prints readable summary."""
import argparse, boto3, json, os, sys, time
from datetime import datetime

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stack-name"); ap.add_argument("--changeset")
    ap.add_argument("--region");     ap.add_argument("--output-file", default="reports/changeset.json")
    args = ap.parse_args()

    cfn = boto3.client("cloudformation", region_name=args.region)
    os.makedirs("reports", exist_ok=True)

    for _ in range(30):
        cs = cfn.describe_change_set(StackName=args.stack_name, ChangeSetName=args.changeset)
        if cs["Status"] in ("CREATE_COMPLETE","FAILED"): break
        print(f"  Status: {cs['Status']} — waiting…"); time.sleep(10)

    changes = cs.get("Changes",[])
    print(f"\n  Change set: {args.changeset}")
    print(f"  Status:  {cs['Status']}")
    print(f"  Changes: {len(changes)}")
    for c in changes:
        rc = c.get("ResourceChange",{})
        print(f"    {rc.get('Action','?'):10s}  {rc.get('ResourceType','?'):45s}  {rc.get('LogicalResourceId','?')}")

    with open(args.output_file,"w") as f:
        json.dump({"stack":args.stack_name,"changeset":args.changeset,
                   "status":cs["Status"],"changes":changes,
                   "timestamp":datetime.utcnow().isoformat()}, f, indent=2, default=str)

    if cs["Status"] == "FAILED":
        print(f"  ❌  Change set FAILED: {cs.get('StatusReason','')}")
        sys.exit(1)

if __name__ == "__main__": main()
